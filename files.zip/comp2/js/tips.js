var navWrap = $('#imageTips1'),
    nav = $('.tips2'),
    startPosition = navWrap.offset().top,
    stopPosition = $('#graphContainer1').offset().top - nav.outerHeight();

$(document).scroll(function () {
    //stick nav to top of page
    var y = $(this).scrollTop()

    if (y > startPosition) {
        nav.addClass('sticky');
        if (y > stopPosition) {
            nav.css('top', stopPosition - y);
        } else {
            nav.css('top', 0);
        }
    } else {
        nav.removeClass('sticky');
    }
});
