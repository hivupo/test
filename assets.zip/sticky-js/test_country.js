! function(t) {
    var n = {};

    function e(i) {
        if (n[i]) return n[i].exports;
        var o = n[i] = {
            i: i,
            l: !1,
            exports: {}
        };
        return t[i].call(o.exports, o, o.exports, e), o.l = !0, o.exports
    }
    e.m = t, e.c = n, e.d = function(t, n, i) {
        e.o(t, n) || Object.defineProperty(t, n, {
            enumerable: !0,
            get: i
        })
    }, e.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, e.t = function(t, n) {
        if (1 & n && (t = e(t)), 8 & n) return t;
        if (4 & n && "object" == typeof t && t && t.__esModule) return t;
        var i = Object.create(null);
        if (e.r(i), Object.defineProperty(i, "default", {
                enumerable: !0,
                value: t
            }), 2 & n && "string" != typeof t)
            for (var o in t) e.d(i, o, function(n) {
                return t[n]
            }.bind(null, o));
        return i
    }, e.n = function(t) {
        var n = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return e.d(n, "a", n), n
    }, e.o = function(t, n) {
        return Object.prototype.hasOwnProperty.call(t, n)
    }, e.p = "", e(e.s = 15)
}({
    0: function(t, n) {
        var e;
        e = function() {
            return this
        }();
        try {
            e = e || Function("return this")() || (0, eval)("this")
        } catch (t) {
            "object" == typeof window && (e = window)
        }
        t.exports = e
    },
    15: function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e(2),
            o = e.n(i),
            r = {
                android: function() {
                    return navigator.userAgent.match(/Android/i)
                },
                blackberry: function() {
                    return navigator.userAgent.match(/BlackBerry/i)
                },
                ios: function() {
                    return navigator.userAgent.match(/iPhone|iPad|iPod/i)
                },
                opera: function() {
                    return navigator.userAgent.match(/Opera Mini/i)
                },
                windows: function() {
                    return navigator.userAgent.match(/IEMobile/i)
                },
                any: function() {
                    return r.android() || r.blackberry() || r.ios() || r.opera() || r.windows()
                }
            },
            a = r,
            s = "http://www.w3.org/1999/xhtml",
            c = {
                svg: "http://www.w3.org/2000/svg",
                xhtml: s,
                xlink: "http://www.w3.org/1999/xlink",
                xml: "http://www.w3.org/XML/1998/namespace",
                xmlns: "http://www.w3.org/2000/xmlns/"
            },
            h = function(t) {
                var n = t += "",
                    e = n.indexOf(":");
                return e >= 0 && "xmlns" !== (n = t.slice(0, e)) && (t = t.slice(e + 1)), c.hasOwnProperty(n) ? {
                    space: c[n],
                    local: t
                } : t
            };
        var u = function(t) {
                var n = h(t);
                return (n.local ? function(t) {
                    return function() {
                        return this.ownerDocument.createElementNS(t.space, t.local)
                    }
                } : function(t) {
                    return function() {
                        var n = this.ownerDocument,
                            e = this.namespaceURI;
                        return e === s && n.documentElement.namespaceURI === s ? n.createElement(t) : n.createElementNS(e, t)
                    }
                })(n)
            },
            l = 0;

        function f() {
            this._ = "@" + (++l).toString(36)
        }
        f.prototype = function() {
            return new f
        }.prototype = {
            constructor: f,
            get: function(t) {
                for (var n = this._; !(n in t);)
                    if (!(t = t.parentNode)) return;
                return t[n]
            },
            set: function(t, n) {
                return t[this._] = n
            },
            remove: function(t) {
                return this._ in t && delete t[this._]
            },
            toString: function() {
                return this._
            }
        };
        var d = function(t) {
            return function() {
                return this.matches(t)
            }
        };
        if ("undefined" != typeof document) {
            var p = document.documentElement;
            if (!p.matches) {
                var _ = p.webkitMatchesSelector || p.msMatchesSelector || p.mozMatchesSelector || p.oMatchesSelector;
                d = function(t) {
                    return function() {
                        return _.call(this, t)
                    }
                }
            }
        }
        var y = d,
            v = {},
            x = null;
        "undefined" != typeof document && ("onmouseenter" in document.documentElement || (v = {
            mouseenter: "mouseover",
            mouseleave: "mouseout"
        }));

        function g(t, n, e) {
            return t = m(t, n, e),
                function(n) {
                    var e = n.relatedTarget;
                    e && (e === this || 8 & e.compareDocumentPosition(this)) || t.call(this, n)
                }
        }

        function m(t, n, e) {
            return function(i) {
                var o = x;
                x = i;
                try {
                    t.call(this, this.__data__, n, e)
                } finally {
                    x = o
                }
            }
        }

        function b(t) {
            return function() {
                var n = this.__on;
                if (n) {
                    for (var e, i = 0, o = -1, r = n.length; i < r; ++i) e = n[i], t.type && e.type !== t.type || e.name !== t.name ? n[++o] = e : this.removeEventListener(e.type, e.listener, e.capture);
                    ++o ? n.length = o : delete this.__on
                }
            }
        }

        function w(t, n, e) {
            var i = v.hasOwnProperty(t.type) ? g : m;
            return function(o, r, a) {
                var s, c = this.__on,
                    h = i(n, r, a);
                if (c)
                    for (var u = 0, l = c.length; u < l; ++u)
                        if ((s = c[u]).type === t.type && s.name === t.name) return this.removeEventListener(s.type, s.listener, s.capture), this.addEventListener(s.type, s.listener = h, s.capture = e), void(s.value = n);
                this.addEventListener(t.type, h, e), s = {
                    type: t.type,
                    name: t.name,
                    value: n,
                    listener: h,
                    capture: e
                }, c ? c.push(s) : this.__on = [s]
            }
        }

        function M(t, n, e, i) {
            var o = x;
            t.sourceEvent = x, x = t;
            try {
                return n.apply(e, i)
            } finally {
                x = o
            }
        }
        var k = function() {
                for (var t, n = x; t = n.sourceEvent;) n = t;
                return n
            },
            T = function(t, n) {
                var e = t.ownerSVGElement || t;
                if (e.createSVGPoint) {
                    var i = e.createSVGPoint();
                    return i.x = n.clientX, i.y = n.clientY, [(i = i.matrixTransform(t.getScreenCTM().inverse())).x, i.y]
                }
                var o = t.getBoundingClientRect();
                return [n.clientX - o.left - t.clientLeft, n.clientY - o.top - t.clientTop]
            },
            S = function(t) {
                var n = k();
                return n.changedTouches && (n = n.changedTouches[0]), T(t, n)
            };

        function j() {}
        var N = function(t) {
            return null == t ? j : function() {
                return this.querySelector(t)
            }
        };

        function O() {
            return []
        }
        var A = function(t) {
            return new Array(t.length)
        };

        function E(t, n) {
            this.ownerDocument = t.ownerDocument, this.namespaceURI = t.namespaceURI, this._next = null, this._parent = t, this.__data__ = n
        }
        E.prototype = {
            constructor: E,
            appendChild: function(t) {
                return this._parent.insertBefore(t, this._next)
            },
            insertBefore: function(t, n) {
                return this._parent.insertBefore(t, n)
            },
            querySelector: function(t) {
                return this._parent.querySelector(t)
            },
            querySelectorAll: function(t) {
                return this._parent.querySelectorAll(t)
            }
        };
        var P = "$";

        function C(t, n, e, i, o, r) {
            for (var a, s = 0, c = n.length, h = r.length; s < h; ++s)(a = n[s]) ? (a.__data__ = r[s], i[s] = a) : e[s] = new E(t, r[s]);
            for (; s < c; ++s)(a = n[s]) && (o[s] = a)
        }

        function R(t, n, e, i, o, r, a) {
            var s, c, h, u = {},
                l = n.length,
                f = r.length,
                d = new Array(l);
            for (s = 0; s < l; ++s)(c = n[s]) && (d[s] = h = P + a.call(c, c.__data__, s, n), h in u ? o[s] = c : u[h] = c);
            for (s = 0; s < f; ++s)(c = u[h = P + a.call(t, r[s], s, r)]) ? (i[s] = c, c.__data__ = r[s], u[h] = null) : e[s] = new E(t, r[s]);
            for (s = 0; s < l; ++s)(c = n[s]) && u[d[s]] === c && (o[s] = c)
        }

        function L(t, n) {
            return t < n ? -1 : t > n ? 1 : t >= n ? 0 : NaN
        }
        var W = function(t) {
            return t.ownerDocument && t.ownerDocument.defaultView || t.document && t || t.defaultView
        };

        function q(t) {
            return t.trim().split(/^|\s+/)
        }

        function B(t) {
            return t.classList || new I(t)
        }

        function I(t) {
            this._node = t, this._names = q(t.getAttribute("class") || "")
        }

        function D(t, n) {
            for (var e = B(t), i = -1, o = n.length; ++i < o;) e.add(n[i])
        }

        function H(t, n) {
            for (var e = B(t), i = -1, o = n.length; ++i < o;) e.remove(n[i])
        }
        I.prototype = {
            add: function(t) {
                this._names.indexOf(t) < 0 && (this._names.push(t), this._node.setAttribute("class", this._names.join(" ")))
            },
            remove: function(t) {
                var n = this._names.indexOf(t);
                n >= 0 && (this._names.splice(n, 1), this._node.setAttribute("class", this._names.join(" ")))
            },
            contains: function(t) {
                return this._names.indexOf(t) >= 0
            }
        };

        function z() {
            this.textContent = ""
        }

        function Y() {
            this.innerHTML = ""
        }

        function F() {
            this.nextSibling && this.parentNode.appendChild(this)
        }

        function X() {
            this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild)
        }

        function G() {
            return null
        }

        function J() {
            var t = this.parentNode;
            t && t.removeChild(this)
        }

        function V(t, n, e) {
            var i = W(t),
                o = i.CustomEvent;
            o ? o = new o(n, e) : (o = i.document.createEvent("Event"), e ? (o.initEvent(n, e.bubbles, e.cancelable), o.detail = e.detail) : o.initEvent(n, !1, !1)), t.dispatchEvent(o)
        }
        var U = [null];

        function $(t, n) {
            this._groups = t, this._parents = n
        }

        function K() {
            return new $([
                [document.documentElement]
            ], U)
        }
        $.prototype = K.prototype = {
            constructor: $,
            select: function(t) {
                "function" != typeof t && (t = N(t));
                for (var n = this._groups, e = n.length, i = new Array(e), o = 0; o < e; ++o)
                    for (var r, a, s = n[o], c = s.length, h = i[o] = new Array(c), u = 0; u < c; ++u)(r = s[u]) && (a = t.call(r, r.__data__, u, s)) && ("__data__" in r && (a.__data__ = r.__data__), h[u] = a);
                return new $(i, this._parents)
            },
            selectAll: function(t) {
                "function" != typeof t && (t = function(t) {
                    return null == t ? O : function() {
                        return this.querySelectorAll(t)
                    }
                }(t));
                for (var n = this._groups, e = n.length, i = [], o = [], r = 0; r < e; ++r)
                    for (var a, s = n[r], c = s.length, h = 0; h < c; ++h)(a = s[h]) && (i.push(t.call(a, a.__data__, h, s)), o.push(a));
                return new $(i, o)
            },
            filter: function(t) {
                "function" != typeof t && (t = y(t));
                for (var n = this._groups, e = n.length, i = new Array(e), o = 0; o < e; ++o)
                    for (var r, a = n[o], s = a.length, c = i[o] = [], h = 0; h < s; ++h)(r = a[h]) && t.call(r, r.__data__, h, a) && c.push(r);
                return new $(i, this._parents)
            },
            data: function(t, n) {
                if (!t) return d = new Array(this.size()), h = -1, this.each(function(t) {
                    d[++h] = t
                }), d;
                var e = n ? R : C,
                    i = this._parents,
                    o = this._groups;
                "function" != typeof t && (t = function(t) {
                    return function() {
                        return t
                    }
                }(t));
                for (var r = o.length, a = new Array(r), s = new Array(r), c = new Array(r), h = 0; h < r; ++h) {
                    var u = i[h],
                        l = o[h],
                        f = l.length,
                        d = t.call(u, u && u.__data__, h, i),
                        p = d.length,
                        _ = s[h] = new Array(p),
                        y = a[h] = new Array(p);
                    e(u, l, _, y, c[h] = new Array(f), d, n);
                    for (var v, x, g = 0, m = 0; g < p; ++g)
                        if (v = _[g]) {
                            for (g >= m && (m = g + 1); !(x = y[m]) && ++m < p;);
                            v._next = x || null
                        }
                }
                return (a = new $(a, i))._enter = s, a._exit = c, a
            },
            enter: function() {
                return new $(this._enter || this._groups.map(A), this._parents)
            },
            exit: function() {
                return new $(this._exit || this._groups.map(A), this._parents)
            },
            merge: function(t) {
                for (var n = this._groups, e = t._groups, i = n.length, o = e.length, r = Math.min(i, o), a = new Array(i), s = 0; s < r; ++s)
                    for (var c, h = n[s], u = e[s], l = h.length, f = a[s] = new Array(l), d = 0; d < l; ++d)(c = h[d] || u[d]) && (f[d] = c);
                for (; s < i; ++s) a[s] = n[s];
                return new $(a, this._parents)
            },
            order: function() {
                for (var t = this._groups, n = -1, e = t.length; ++n < e;)
                    for (var i, o = t[n], r = o.length - 1, a = o[r]; --r >= 0;)(i = o[r]) && (a && a !== i.nextSibling && a.parentNode.insertBefore(i, a), a = i);
                return this
            },
            sort: function(t) {
                function n(n, e) {
                    return n && e ? t(n.__data__, e.__data__) : !n - !e
                }
                t || (t = L);
                for (var e = this._groups, i = e.length, o = new Array(i), r = 0; r < i; ++r) {
                    for (var a, s = e[r], c = s.length, h = o[r] = new Array(c), u = 0; u < c; ++u)(a = s[u]) && (h[u] = a);
                    h.sort(n)
                }
                return new $(o, this._parents).order()
            },
            call: function() {
                var t = arguments[0];
                return arguments[0] = this, t.apply(null, arguments), this
            },
            nodes: function() {
                var t = new Array(this.size()),
                    n = -1;
                return this.each(function() {
                    t[++n] = this
                }), t
            },
            node: function() {
                for (var t = this._groups, n = 0, e = t.length; n < e; ++n)
                    for (var i = t[n], o = 0, r = i.length; o < r; ++o) {
                        var a = i[o];
                        if (a) return a
                    }
                return null
            },
            size: function() {
                var t = 0;
                return this.each(function() {
                    ++t
                }), t
            },
            empty: function() {
                return !this.node()
            },
            each: function(t) {
                for (var n = this._groups, e = 0, i = n.length; e < i; ++e)
                    for (var o, r = n[e], a = 0, s = r.length; a < s; ++a)(o = r[a]) && t.call(o, o.__data__, a, r);
                return this
            },
            attr: function(t, n) {
                var e = h(t);
                if (arguments.length < 2) {
                    var i = this.node();
                    return e.local ? i.getAttributeNS(e.space, e.local) : i.getAttribute(e)
                }
                return this.each((null == n ? e.local ? function(t) {
                    return function() {
                        this.removeAttributeNS(t.space, t.local)
                    }
                } : function(t) {
                    return function() {
                        this.removeAttribute(t)
                    }
                } : "function" == typeof n ? e.local ? function(t, n) {
                    return function() {
                        var e = n.apply(this, arguments);
                        null == e ? this.removeAttributeNS(t.space, t.local) : this.setAttributeNS(t.space, t.local, e)
                    }
                } : function(t, n) {
                    return function() {
                        var e = n.apply(this, arguments);
                        null == e ? this.removeAttribute(t) : this.setAttribute(t, e)
                    }
                } : e.local ? function(t, n) {
                    return function() {
                        this.setAttributeNS(t.space, t.local, n)
                    }
                } : function(t, n) {
                    return function() {
                        this.setAttribute(t, n)
                    }
                })(e, n))
            },
            style: function(t, n, e) {
                var i;
                return arguments.length > 1 ? this.each((null == n ? function(t) {
                    return function() {
                        this.style.removeProperty(t)
                    }
                } : "function" == typeof n ? function(t, n, e) {
                    return function() {
                        var i = n.apply(this, arguments);
                        null == i ? this.style.removeProperty(t) : this.style.setProperty(t, i, e)
                    }
                } : function(t, n, e) {
                    return function() {
                        this.style.setProperty(t, n, e)
                    }
                })(t, n, null == e ? "" : e)) : W(i = this.node()).getComputedStyle(i, null).getPropertyValue(t)
            },
            property: function(t, n) {
                return arguments.length > 1 ? this.each((null == n ? function(t) {
                    return function() {
                        delete this[t]
                    }
                } : "function" == typeof n ? function(t, n) {
                    return function() {
                        var e = n.apply(this, arguments);
                        null == e ? delete this[t] : this[t] = e
                    }
                } : function(t, n) {
                    return function() {
                        this[t] = n
                    }
                })(t, n)) : this.node()[t]
            },
            classed: function(t, n) {
                var e = q(t + "");
                if (arguments.length < 2) {
                    for (var i = B(this.node()), o = -1, r = e.length; ++o < r;)
                        if (!i.contains(e[o])) return !1;
                    return !0
                }
                return this.each(("function" == typeof n ? function(t, n) {
                    return function() {
                        (n.apply(this, arguments) ? D : H)(this, t)
                    }
                } : n ? function(t) {
                    return function() {
                        D(this, t)
                    }
                } : function(t) {
                    return function() {
                        H(this, t)
                    }
                })(e, n))
            },
            text: function(t) {
                return arguments.length ? this.each(null == t ? z : ("function" == typeof t ? function(t) {
                    return function() {
                        var n = t.apply(this, arguments);
                        this.textContent = null == n ? "" : n
                    }
                } : function(t) {
                    return function() {
                        this.textContent = t
                    }
                })(t)) : this.node().textContent
            },
            html: function(t) {
                return arguments.length ? this.each(null == t ? Y : ("function" == typeof t ? function(t) {
                    return function() {
                        var n = t.apply(this, arguments);
                        this.innerHTML = null == n ? "" : n
                    }
                } : function(t) {
                    return function() {
                        this.innerHTML = t
                    }
                })(t)) : this.node().innerHTML
            },
            raise: function() {
                return this.each(F)
            },
            lower: function() {
                return this.each(X)
            },
            append: function(t) {
                var n = "function" == typeof t ? t : u(t);
                return this.select(function() {
                    return this.appendChild(n.apply(this, arguments))
                })
            },
            insert: function(t, n) {
                var e = "function" == typeof t ? t : u(t),
                    i = null == n ? G : "function" == typeof n ? n : N(n);
                return this.select(function() {
                    return this.insertBefore(e.apply(this, arguments), i.apply(this, arguments) || null)
                })
            },
            remove: function() {
                return this.each(J)
            },
            datum: function(t) {
                return arguments.length ? this.property("__data__", t) : this.node().__data__
            },
            on: function(t, n, e) {
                var i, o, r = function(t) {
                        return t.trim().split(/^|\s+/).map(function(t) {
                            var n = "",
                                e = t.indexOf(".");
                            return e >= 0 && (n = t.slice(e + 1), t = t.slice(0, e)), {
                                type: t,
                                name: n
                            }
                        })
                    }(t + ""),
                    a = r.length;
                if (!(arguments.length < 2)) {
                    for (s = n ? w : b, null == e && (e = !1), i = 0; i < a; ++i) this.each(s(r[i], n, e));
                    return this
                }
                var s = this.node().__on;
                if (s)
                    for (var c, h = 0, u = s.length; h < u; ++h)
                        for (i = 0, c = s[h]; i < a; ++i)
                            if ((o = r[i]).type === c.type && o.name === c.name) return c.value
            },
            dispatch: function(t, n) {
                return this.each(("function" == typeof n ? function(t, n) {
                    return function() {
                        return V(this, t, n.apply(this, arguments))
                    }
                } : function(t, n) {
                    return function() {
                        return V(this, t, n)
                    }
                })(t, n))
            }
        };
        var Z = function(t) {
                return "string" == typeof t ? new $([
                    [document.querySelector(t)]
                ], [document.documentElement]) : new $([
                    [t]
                ], U)
            },
            Q = function(t, n, e) {
                arguments.length < 3 && (e = n, n = k().changedTouches);
                for (var i, o = 0, r = n ? n.length : 0; o < r; ++o)
                    if ((i = n[o]).identifier === e) return T(t, i);
                return null
            },
            tt = {
                value: function() {}
            };

        function nt() {
            for (var t, n = 0, e = arguments.length, i = {}; n < e; ++n) {
                if (!(t = arguments[n] + "") || t in i) throw new Error("illegal type: " + t);
                i[t] = []
            }
            return new et(i)
        }

        function et(t) {
            this._ = t
        }

        function it(t, n) {
            for (var e, i = 0, o = t.length; i < o; ++i)
                if ((e = t[i]).name === n) return e.value
        }

        function ot(t, n, e) {
            for (var i = 0, o = t.length; i < o; ++i)
                if (t[i].name === n) {
                    t[i] = tt, t = t.slice(0, i).concat(t.slice(i + 1));
                    break
                }
            return null != e && t.push({
                name: n,
                value: e
            }), t
        }
        et.prototype = nt.prototype = {
            constructor: et,
            on: function(t, n) {
                var e, i = this._,
                    o = function(t, n) {
                        return t.trim().split(/^|\s+/).map(function(t) {
                            var e = "",
                                i = t.indexOf(".");
                            if (i >= 0 && (e = t.slice(i + 1), t = t.slice(0, i)), t && !n.hasOwnProperty(t)) throw new Error("unknown type: " + t);
                            return {
                                type: t,
                                name: e
                            }
                        })
                    }(t + "", i),
                    r = -1,
                    a = o.length;
                if (!(arguments.length < 2)) {
                    if (null != n && "function" != typeof n) throw new Error("invalid callback: " + n);
                    for (; ++r < a;)
                        if (e = (t = o[r]).type) i[e] = ot(i[e], t.name, n);
                        else if (null == n)
                        for (e in i) i[e] = ot(i[e], t.name, null);
                    return this
                }
                for (; ++r < a;)
                    if ((e = (t = o[r]).type) && (e = it(i[e], t.name))) return e
            },
            copy: function() {
                var t = {},
                    n = this._;
                for (var e in n) t[e] = n[e].slice();
                return new et(t)
            },
            call: function(t, n) {
                if ((e = arguments.length - 2) > 0)
                    for (var e, i, o = new Array(e), r = 0; r < e; ++r) o[r] = arguments[r + 2];
                if (!this._.hasOwnProperty(t)) throw new Error("unknown type: " + t);
                for (r = 0, e = (i = this._[t]).length; r < e; ++r) i[r].value.apply(n, o)
            },
            apply: function(t, n, e) {
                if (!this._.hasOwnProperty(t)) throw new Error("unknown type: " + t);
                for (var i = this._[t], o = 0, r = i.length; o < r; ++o) i[o].value.apply(n, e)
            }
        };
        var rt = nt;

        function at() {
            x.stopImmediatePropagation()
        }
        var st = function() {
                x.preventDefault(), x.stopImmediatePropagation()
            },
            ct = function(t) {
                var n = t.document.documentElement,
                    e = Z(t).on("dragstart.drag", st, !0);
                "onselectstart" in n ? e.on("selectstart.drag", st, !0) : (n.__noselect = n.style.MozUserSelect, n.style.MozUserSelect = "none")
            };
        var ht = function(t) {
            return function() {
                return t
            }
        };

        function ut(t, n, e, i, o, r, a, s, c, h) {
            this.target = t, this.type = n, this.subject = e, this.identifier = i, this.active = o, this.x = r, this.y = a, this.dx = s, this.dy = c, this._ = h
        }

        function lt() {
            return !x.button
        }

        function ft() {
            return this.parentNode
        }

        function dt(t) {
            return null == t ? {
                x: x.x,
                y: x.y
            } : t
        }
        ut.prototype.on = function() {
            var t = this._.on.apply(this._, arguments);
            return t === this._ ? this : t
        };
        var pt = function() {
                var t, n, e = lt,
                    i = ft,
                    o = dt,
                    r = {},
                    a = rt("start", "drag", "end"),
                    s = 0;

                function c(t) {
                    t.on("mousedown.drag", h).on("touchstart.drag", f).on("touchmove.drag", d).on("touchend.drag touchcancel.drag", p).style("-webkit-tap-highlight-color", "rgba(0,0,0,0)")
                }

                function h() {
                    if (!n && e.apply(this, arguments)) {
                        var o = _("mouse", i.apply(this, arguments), S, this, arguments);
                        o && (Z(x.view).on("mousemove.drag", u, !0).on("mouseup.drag", l, !0), ct(x.view), at(), t = !1, o("start"))
                    }
                }

                function u() {
                    st(), t = !0, r.mouse("drag")
                }

                function l() {
                    Z(x.view).on("mousemove.drag mouseup.drag", null),
                        function(t, n) {
                            var e = t.document.documentElement,
                                i = Z(t).on("dragstart.drag", null);
                            n && (i.on("click.drag", st, !0), setTimeout(function() {
                                i.on("click.drag", null)
                            }, 0)), "onselectstart" in e ? i.on("selectstart.drag", null) : (e.style.MozUserSelect = e.__noselect, delete e.__noselect)
                        }(x.view, t), st(), r.mouse("end")
                }

                function f() {
                    if (e.apply(this, arguments)) {
                        var t, n, o = x.changedTouches,
                            r = i.apply(this, arguments),
                            a = o.length;
                        for (t = 0; t < a; ++t)(n = _(o[t].identifier, r, Q, this, arguments)) && (at(), n("start"))
                    }
                }

                function d() {
                    var t, n, e = x.changedTouches,
                        i = e.length;
                    for (t = 0; t < i; ++t)(n = r[e[t].identifier]) && (st(), n("drag"))
                }

                function p() {
                    var t, e, i = x.changedTouches,
                        o = i.length;
                    for (n && clearTimeout(n), n = setTimeout(function() {
                            n = null
                        }, 500), t = 0; t < o; ++t)(e = r[i[t].identifier]) && (at(), e("end"))
                }

                function _(t, n, e, i, h) {
                    var u, l, f, d = e(n, t),
                        p = a.copy();
                    if (M(new ut(c, "beforestart", u, t, s, d[0], d[1], 0, 0, p), function() {
                            return null != (x.subject = u = o.apply(i, h)) && (l = u.x - d[0] || 0, f = u.y - d[1] || 0, !0)
                        })) return function o(a) {
                        var _, y = d;
                        switch (a) {
                            case "start":
                                r[t] = o, _ = s++;
                                break;
                            case "end":
                                delete r[t], --s;
                            case "drag":
                                d = e(n, t), _ = s
                        }
                        M(new ut(c, a, u, t, _, d[0] + l, d[1] + f, d[0] - y[0], d[1] - y[1], p), p.apply, p, [a, i, h])
                    }
                }
                return c.filter = function(t) {
                    return arguments.length ? (e = "function" == typeof t ? t : ht(!!t), c) : e
                }, c.container = function(t) {
                    return arguments.length ? (i = "function" == typeof t ? t : ht(t), c) : i
                }, c.subject = function(t) {
                    return arguments.length ? (o = "function" == typeof t ? t : ht(t), c) : o
                }, c.on = function() {
                    var t = a.on.apply(a, arguments);
                    return t === a ? c : t
                }, c
            },
            _t = Math.PI,
            yt = 2 * _t,
            vt = yt - 1e-6;

        function xt() {
            this._x0 = this._y0 = this._x1 = this._y1 = null, this._ = ""
        }

        function gt() {
            return new xt
        }
        xt.prototype = gt.prototype = {
            constructor: xt,
            moveTo: function(t, n) {
                this._ += "M" + (this._x0 = this._x1 = +t) + "," + (this._y0 = this._y1 = +n)
            },
            closePath: function() {
                null !== this._x1 && (this._x1 = this._x0, this._y1 = this._y0, this._ += "Z")
            },
            lineTo: function(t, n) {
                this._ += "L" + (this._x1 = +t) + "," + (this._y1 = +n)
            },
            quadraticCurveTo: function(t, n, e, i) {
                this._ += "Q" + +t + "," + +n + "," + (this._x1 = +e) + "," + (this._y1 = +i)
            },
            bezierCurveTo: function(t, n, e, i, o, r) {
                this._ += "C" + +t + "," + +n + "," + +e + "," + +i + "," + (this._x1 = +o) + "," + (this._y1 = +r)
            },
            arcTo: function(t, n, e, i, o) {
                t = +t, n = +n, e = +e, i = +i, o = +o;
                var r = this._x1,
                    a = this._y1,
                    s = e - t,
                    c = i - n,
                    h = r - t,
                    u = a - n,
                    l = h * h + u * u;
                if (o < 0) throw new Error("negative radius: " + o);
                if (null === this._x1) this._ += "M" + (this._x1 = t) + "," + (this._y1 = n);
                else if (l > 1e-6)
                    if (Math.abs(u * s - c * h) > 1e-6 && o) {
                        var f = e - r,
                            d = i - a,
                            p = s * s + c * c,
                            _ = f * f + d * d,
                            y = Math.sqrt(p),
                            v = Math.sqrt(l),
                            x = o * Math.tan((_t - Math.acos((p + l - _) / (2 * y * v))) / 2),
                            g = x / v,
                            m = x / y;
                        Math.abs(g - 1) > 1e-6 && (this._ += "L" + (t + g * h) + "," + (n + g * u)), this._ += "A" + o + "," + o + ",0,0," + +(u * f > h * d) + "," + (this._x1 = t + m * s) + "," + (this._y1 = n + m * c)
                    } else this._ += "L" + (this._x1 = t) + "," + (this._y1 = n);
                else;
            },
            arc: function(t, n, e, i, o, r) {
                t = +t, n = +n;
                var a = (e = +e) * Math.cos(i),
                    s = e * Math.sin(i),
                    c = t + a,
                    h = n + s,
                    u = 1 ^ r,
                    l = r ? i - o : o - i;
                if (e < 0) throw new Error("negative radius: " + e);
                null === this._x1 ? this._ += "M" + c + "," + h : (Math.abs(this._x1 - c) > 1e-6 || Math.abs(this._y1 - h) > 1e-6) && (this._ += "L" + c + "," + h), e && (l < 0 && (l = l % yt + yt), l > vt ? this._ += "A" + e + "," + e + ",0,1," + u + "," + (t - a) + "," + (n - s) + "A" + e + "," + e + ",0,1," + u + "," + (this._x1 = c) + "," + (this._y1 = h) : l > 1e-6 && (this._ += "A" + e + "," + e + ",0," + +(l >= _t) + "," + u + "," + (this._x1 = t + e * Math.cos(o)) + "," + (this._y1 = n + e * Math.sin(o))))
            },
            rect: function(t, n, e, i) {
                this._ += "M" + (this._x0 = this._x1 = +t) + "," + (this._y0 = this._y1 = +n) + "h" + +e + "v" + +i + "h" + -e + "Z"
            },
            toString: function() {
                return this._
            }
        };
        var mt = gt,
            bt = function(t) {
                return function() {
                    return t
                }
            },
            wt = 1e-12,
            Mt = Math.PI,
            kt = Mt / 2,
            Tt = 2 * Mt;

        function St(t) {
            return t.innerRadius
        }

        function jt(t) {
            return t.outerRadius
        }

        function Nt(t) {
            return t.startAngle
        }

        function Ot(t) {
            return t.endAngle
        }

        function At(t) {
            return t && t.padAngle
        }

        function Et(t) {
            return t >= 1 ? kt : t <= -1 ? -kt : Math.asin(t)
        }

        function Pt(t, n, e, i, o, r, a) {
            var s = t - e,
                c = n - i,
                h = (a ? r : -r) / Math.sqrt(s * s + c * c),
                u = h * c,
                l = -h * s,
                f = t + u,
                d = n + l,
                p = e + u,
                _ = i + l,
                y = (f + p) / 2,
                v = (d + _) / 2,
                x = p - f,
                g = _ - d,
                m = x * x + g * g,
                b = o - r,
                w = f * _ - p * d,
                M = (g < 0 ? -1 : 1) * Math.sqrt(Math.max(0, b * b * m - w * w)),
                k = (w * g - x * M) / m,
                T = (-w * x - g * M) / m,
                S = (w * g + x * M) / m,
                j = (-w * x + g * M) / m,
                N = k - y,
                O = T - v,
                A = S - y,
                E = j - v;
            return N * N + O * O > A * A + E * E && (k = S, T = j), {
                cx: k,
                cy: T,
                x01: -u,
                y01: -l,
                x11: k * (o / b - 1),
                y11: T * (o / b - 1)
            }
        }

        function Ct(t) {
            this._context = t
        }
        Ct.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._point = 0
            },
            lineEnd: function() {
                (this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
            },
            point: function(t, n) {
                switch (t = +t, n = +n, this._point) {
                    case 0:
                        this._point = 1, this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                        break;
                    case 1:
                        this._point = 2;
                    default:
                        this._context.lineTo(t, n)
                }
            }
        };
        var Rt = function(t) {
            return new Ct(t)
        };

        function Lt(t) {
            return t[0]
        }

        function Wt(t) {
            return t[1]
        }
        var qt = function() {
            var t = Lt,
                n = Wt,
                e = bt(!0),
                i = null,
                o = Rt,
                r = null;

            function a(a) {
                var s, c, h, u = a.length,
                    l = !1;
                for (null == i && (r = o(h = mt())), s = 0; s <= u; ++s) !(s < u && e(c = a[s], s, a)) === l && ((l = !l) ? r.lineStart() : r.lineEnd()), l && r.point(+t(c, s, a), +n(c, s, a));
                if (h) return r = null, h + "" || null
            }
            return a.x = function(n) {
                return arguments.length ? (t = "function" == typeof n ? n : bt(+n), a) : t
            }, a.y = function(t) {
                return arguments.length ? (n = "function" == typeof t ? t : bt(+t), a) : n
            }, a.defined = function(t) {
                return arguments.length ? (e = "function" == typeof t ? t : bt(!!t), a) : e
            }, a.curve = function(t) {
                return arguments.length ? (o = t, null != i && (r = o(i)), a) : o
            }, a.context = function(t) {
                return arguments.length ? (null == t ? i = r = null : r = o(i = t), a) : i
            }, a
        };
        It(Rt);

        function Bt(t) {
            this._curve = t
        }

        function It(t) {
            function n(n) {
                return new Bt(t(n))
            }
            return n._curve = t, n
        }
        Bt.prototype = {
            areaStart: function() {
                this._curve.areaStart()
            },
            areaEnd: function() {
                this._curve.areaEnd()
            },
            lineStart: function() {
                this._curve.lineStart()
            },
            lineEnd: function() {
                this._curve.lineEnd()
            },
            point: function(t, n) {
                this._curve.point(n * Math.sin(t), n * -Math.cos(t))
            }
        };
        Math.sqrt(1 / 3);
        var Dt = Math.sin(Mt / 10) / Math.sin(7 * Mt / 10),
            Ht = (Math.sin(Tt / 10), Math.cos(Tt / 10), Math.sqrt(3), Math.sqrt(3), Math.sqrt(12), function() {});

        function zt(t, n, e) {
            t._context.bezierCurveTo((2 * t._x0 + t._x1) / 3, (2 * t._y0 + t._y1) / 3, (t._x0 + 2 * t._x1) / 3, (t._y0 + 2 * t._y1) / 3, (t._x0 + 4 * t._x1 + n) / 6, (t._y0 + 4 * t._y1 + e) / 6)
        }

        function Yt(t) {
            this._context = t
        }
        Yt.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0
            },
            lineEnd: function() {
                switch (this._point) {
                    case 3:
                        zt(this, this._x1, this._y1);
                    case 2:
                        this._context.lineTo(this._x1, this._y1)
                }(this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
            },
            point: function(t, n) {
                switch (t = +t, n = +n, this._point) {
                    case 0:
                        this._point = 1, this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                        break;
                    case 1:
                        this._point = 2;
                        break;
                    case 2:
                        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
                    default:
                        zt(this, t, n)
                }
                this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = n
            }
        };

        function Ft(t) {
            this._context = t
        }
        Ft.prototype = {
            areaStart: Ht,
            areaEnd: Ht,
            lineStart: function() {
                this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0
            },
            lineEnd: function() {
                switch (this._point) {
                    case 1:
                        this._context.moveTo(this._x2, this._y2), this._context.closePath();
                        break;
                    case 2:
                        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
                        break;
                    case 3:
                        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4)
                }
            },
            point: function(t, n) {
                switch (t = +t, n = +n, this._point) {
                    case 0:
                        this._point = 1, this._x2 = t, this._y2 = n;
                        break;
                    case 1:
                        this._point = 2, this._x3 = t, this._y3 = n;
                        break;
                    case 2:
                        this._point = 3, this._x4 = t, this._y4 = n, this._context.moveTo((this._x0 + 4 * this._x1 + t) / 6, (this._y0 + 4 * this._y1 + n) / 6);
                        break;
                    default:
                        zt(this, t, n)
                }
                this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = n
            }
        };

        function Xt(t) {
            this._context = t
        }
        Xt.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0
            },
            lineEnd: function() {
                (this._line || 0 !== this._line && 3 === this._point) && this._context.closePath(), this._line = 1 - this._line
            },
            point: function(t, n) {
                switch (t = +t, n = +n, this._point) {
                    case 0:
                        this._point = 1;
                        break;
                    case 1:
                        this._point = 2;
                        break;
                    case 2:
                        this._point = 3;
                        var e = (this._x0 + 4 * this._x1 + t) / 6,
                            i = (this._y0 + 4 * this._y1 + n) / 6;
                        this._line ? this._context.lineTo(e, i) : this._context.moveTo(e, i);
                        break;
                    case 3:
                        this._point = 4;
                    default:
                        zt(this, t, n)
                }
                this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = n
            }
        };

        function Gt(t, n) {
            this._basis = new Yt(t), this._beta = n
        }
        Gt.prototype = {
            lineStart: function() {
                this._x = [], this._y = [], this._basis.lineStart()
            },
            lineEnd: function() {
                var t = this._x,
                    n = this._y,
                    e = t.length - 1;
                if (e > 0)
                    for (var i, o = t[0], r = n[0], a = t[e] - o, s = n[e] - r, c = -1; ++c <= e;) i = c / e, this._basis.point(this._beta * t[c] + (1 - this._beta) * (o + i * a), this._beta * n[c] + (1 - this._beta) * (r + i * s));
                this._x = this._y = null, this._basis.lineEnd()
            },
            point: function(t, n) {
                this._x.push(+t), this._y.push(+n)
            }
        };
        (function t(n) {
            function e(t) {
                return 1 === n ? new Yt(t) : new Gt(t, n)
            }
            return e.beta = function(n) {
                return t(+n)
            }, e
        })(.85);

        function Jt(t, n, e) {
            t._context.bezierCurveTo(t._x1 + t._k * (t._x2 - t._x0), t._y1 + t._k * (t._y2 - t._y0), t._x2 + t._k * (t._x1 - n), t._y2 + t._k * (t._y1 - e), t._x2, t._y2)
        }

        function Vt(t, n) {
            this._context = t, this._k = (1 - n) / 6
        }
        Vt.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0
            },
            lineEnd: function() {
                switch (this._point) {
                    case 2:
                        this._context.lineTo(this._x2, this._y2);
                        break;
                    case 3:
                        Jt(this, this._x1, this._y1)
                }(this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
            },
            point: function(t, n) {
                switch (t = +t, n = +n, this._point) {
                    case 0:
                        this._point = 1, this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                        break;
                    case 1:
                        this._point = 2, this._x1 = t, this._y1 = n;
                        break;
                    case 2:
                        this._point = 3;
                    default:
                        Jt(this, t, n)
                }
                this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = n
            }
        };
        (function t(n) {
            function e(t) {
                return new Vt(t, n)
            }
            return e.tension = function(n) {
                return t(+n)
            }, e
        })(0);

        function Ut(t, n) {
            this._context = t, this._k = (1 - n) / 6
        }
        Ut.prototype = {
            areaStart: Ht,
            areaEnd: Ht,
            lineStart: function() {
                this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0
            },
            lineEnd: function() {
                switch (this._point) {
                    case 1:
                        this._context.moveTo(this._x3, this._y3), this._context.closePath();
                        break;
                    case 2:
                        this._context.lineTo(this._x3, this._y3), this._context.closePath();
                        break;
                    case 3:
                        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5)
                }
            },
            point: function(t, n) {
                switch (t = +t, n = +n, this._point) {
                    case 0:
                        this._point = 1, this._x3 = t, this._y3 = n;
                        break;
                    case 1:
                        this._point = 2, this._context.moveTo(this._x4 = t, this._y4 = n);
                        break;
                    case 2:
                        this._point = 3, this._x5 = t, this._y5 = n;
                        break;
                    default:
                        Jt(this, t, n)
                }
                this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = n
            }
        };
        (function t(n) {
            function e(t) {
                return new Ut(t, n)
            }
            return e.tension = function(n) {
                return t(+n)
            }, e
        })(0);

        function $t(t, n) {
            this._context = t, this._k = (1 - n) / 6
        }
        $t.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0
            },
            lineEnd: function() {
                (this._line || 0 !== this._line && 3 === this._point) && this._context.closePath(), this._line = 1 - this._line
            },
            point: function(t, n) {
                switch (t = +t, n = +n, this._point) {
                    case 0:
                        this._point = 1;
                        break;
                    case 1:
                        this._point = 2;
                        break;
                    case 2:
                        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
                        break;
                    case 3:
                        this._point = 4;
                    default:
                        Jt(this, t, n)
                }
                this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = n
            }
        };
        (function t(n) {
            function e(t) {
                return new $t(t, n)
            }
            return e.tension = function(n) {
                return t(+n)
            }, e
        })(0);

        function Kt(t, n, e) {
            var i = t._x1,
                o = t._y1,
                r = t._x2,
                a = t._y2;
            if (t._l01_a > wt) {
                var s = 2 * t._l01_2a + 3 * t._l01_a * t._l12_a + t._l12_2a,
                    c = 3 * t._l01_a * (t._l01_a + t._l12_a);
                i = (i * s - t._x0 * t._l12_2a + t._x2 * t._l01_2a) / c, o = (o * s - t._y0 * t._l12_2a + t._y2 * t._l01_2a) / c
            }
            if (t._l23_a > wt) {
                var h = 2 * t._l23_2a + 3 * t._l23_a * t._l12_a + t._l12_2a,
                    u = 3 * t._l23_a * (t._l23_a + t._l12_a);
                r = (r * h + t._x1 * t._l23_2a - n * t._l12_2a) / u, a = (a * h + t._y1 * t._l23_2a - e * t._l12_2a) / u
            }
            t._context.bezierCurveTo(i, o, r, a, t._x2, t._y2)
        }

        function Zt(t, n) {
            this._context = t, this._alpha = n
        }
        Zt.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0
            },
            lineEnd: function() {
                switch (this._point) {
                    case 2:
                        this._context.lineTo(this._x2, this._y2);
                        break;
                    case 3:
                        this.point(this._x2, this._y2)
                }(this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
            },
            point: function(t, n) {
                if (t = +t, n = +n, this._point) {
                    var e = this._x2 - t,
                        i = this._y2 - n;
                    this._l23_a = Math.sqrt(this._l23_2a = Math.pow(e * e + i * i, this._alpha))
                }
                switch (this._point) {
                    case 0:
                        this._point = 1, this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                        break;
                    case 1:
                        this._point = 2;
                        break;
                    case 2:
                        this._point = 3;
                    default:
                        Kt(this, t, n)
                }
                this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = n
            }
        };
        var Qt = function t(n) {
            function e(t) {
                return n ? new Zt(t, n) : new Vt(t, 0)
            }
            return e.alpha = function(n) {
                return t(+n)
            }, e
        }(.5);

        function tn(t, n) {
            this._context = t, this._alpha = n
        }
        tn.prototype = {
            areaStart: Ht,
            areaEnd: Ht,
            lineStart: function() {
                this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0
            },
            lineEnd: function() {
                switch (this._point) {
                    case 1:
                        this._context.moveTo(this._x3, this._y3), this._context.closePath();
                        break;
                    case 2:
                        this._context.lineTo(this._x3, this._y3), this._context.closePath();
                        break;
                    case 3:
                        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5)
                }
            },
            point: function(t, n) {
                if (t = +t, n = +n, this._point) {
                    var e = this._x2 - t,
                        i = this._y2 - n;
                    this._l23_a = Math.sqrt(this._l23_2a = Math.pow(e * e + i * i, this._alpha))
                }
                switch (this._point) {
                    case 0:
                        this._point = 1, this._x3 = t, this._y3 = n;
                        break;
                    case 1:
                        this._point = 2, this._context.moveTo(this._x4 = t, this._y4 = n);
                        break;
                    case 2:
                        this._point = 3, this._x5 = t, this._y5 = n;
                        break;
                    default:
                        Kt(this, t, n)
                }
                this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = n
            }
        };
        (function t(n) {
            function e(t) {
                return n ? new tn(t, n) : new Ut(t, 0)
            }
            return e.alpha = function(n) {
                return t(+n)
            }, e
        })(.5);

        function nn(t, n) {
            this._context = t, this._alpha = n
        }
        nn.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0
            },
            lineEnd: function() {
                (this._line || 0 !== this._line && 3 === this._point) && this._context.closePath(), this._line = 1 - this._line
            },
            point: function(t, n) {
                if (t = +t, n = +n, this._point) {
                    var e = this._x2 - t,
                        i = this._y2 - n;
                    this._l23_a = Math.sqrt(this._l23_2a = Math.pow(e * e + i * i, this._alpha))
                }
                switch (this._point) {
                    case 0:
                        this._point = 1;
                        break;
                    case 1:
                        this._point = 2;
                        break;
                    case 2:
                        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
                        break;
                    case 3:
                        this._point = 4;
                    default:
                        Kt(this, t, n)
                }
                this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = n
            }
        };
        (function t(n) {
            function e(t) {
                return n ? new nn(t, n) : new $t(t, 0)
            }
            return e.alpha = function(n) {
                return t(+n)
            }, e
        })(.5);

        function en(t) {
            this._context = t
        }
        en.prototype = {
            areaStart: Ht,
            areaEnd: Ht,
            lineStart: function() {
                this._point = 0
            },
            lineEnd: function() {
                this._point && this._context.closePath()
            },
            point: function(t, n) {
                t = +t, n = +n, this._point ? this._context.lineTo(t, n) : (this._point = 1, this._context.moveTo(t, n))
            }
        };

        function on(t) {
            return t < 0 ? -1 : 1
        }

        function rn(t, n, e) {
            var i = t._x1 - t._x0,
                o = n - t._x1,
                r = (t._y1 - t._y0) / (i || o < 0 && -0),
                a = (e - t._y1) / (o || i < 0 && -0),
                s = (r * o + a * i) / (i + o);
            return (on(r) + on(a)) * Math.min(Math.abs(r), Math.abs(a), .5 * Math.abs(s)) || 0
        }

        function an(t, n) {
            var e = t._x1 - t._x0;
            return e ? (3 * (t._y1 - t._y0) / e - n) / 2 : n
        }

        function sn(t, n, e) {
            var i = t._x0,
                o = t._y0,
                r = t._x1,
                a = t._y1,
                s = (r - i) / 3;
            t._context.bezierCurveTo(i + s, o + s * n, r - s, a - s * e, r, a)
        }

        function cn(t) {
            this._context = t
        }

        function hn(t) {
            this._context = new un(t)
        }

        function un(t) {
            this._context = t
        }

        function ln(t) {
            this._context = t
        }

        function fn(t) {
            var n, e, i = t.length - 1,
                o = new Array(i),
                r = new Array(i),
                a = new Array(i);
            for (o[0] = 0, r[0] = 2, a[0] = t[0] + 2 * t[1], n = 1; n < i - 1; ++n) o[n] = 1, r[n] = 4, a[n] = 4 * t[n] + 2 * t[n + 1];
            for (o[i - 1] = 2, r[i - 1] = 7, a[i - 1] = 8 * t[i - 1] + t[i], n = 1; n < i; ++n) e = o[n] / r[n - 1], r[n] -= e, a[n] -= e * a[n - 1];
            for (o[i - 1] = a[i - 1] / r[i - 1], n = i - 2; n >= 0; --n) o[n] = (a[n] - o[n + 1]) / r[n];
            for (r[i - 1] = (t[i] + o[i - 1]) / 2, n = 0; n < i - 1; ++n) r[n] = 2 * t[n + 1] - o[n + 1];
            return [o, r]
        }
        cn.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0
            },
            lineEnd: function() {
                switch (this._point) {
                    case 2:
                        this._context.lineTo(this._x1, this._y1);
                        break;
                    case 3:
                        sn(this, this._t0, an(this, this._t0))
                }(this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
            },
            point: function(t, n) {
                var e = NaN;
                if (n = +n, (t = +t) !== this._x1 || n !== this._y1) {
                    switch (this._point) {
                        case 0:
                            this._point = 1, this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                            break;
                        case 1:
                            this._point = 2;
                            break;
                        case 2:
                            this._point = 3, sn(this, an(this, e = rn(this, t, n)), e);
                            break;
                        default:
                            sn(this, this._t0, e = rn(this, t, n))
                    }
                    this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = n, this._t0 = e
                }
            }
        }, (hn.prototype = Object.create(cn.prototype)).point = function(t, n) {
            cn.prototype.point.call(this, n, t)
        }, un.prototype = {
            moveTo: function(t, n) {
                this._context.moveTo(n, t)
            },
            closePath: function() {
                this._context.closePath()
            },
            lineTo: function(t, n) {
                this._context.lineTo(n, t)
            },
            bezierCurveTo: function(t, n, e, i, o, r) {
                this._context.bezierCurveTo(n, t, i, e, r, o)
            }
        }, ln.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._x = [], this._y = []
            },
            lineEnd: function() {
                var t = this._x,
                    n = this._y,
                    e = t.length;
                if (e)
                    if (this._line ? this._context.lineTo(t[0], n[0]) : this._context.moveTo(t[0], n[0]), 2 === e) this._context.lineTo(t[1], n[1]);
                    else
                        for (var i = fn(t), o = fn(n), r = 0, a = 1; a < e; ++r, ++a) this._context.bezierCurveTo(i[0][r], o[0][r], i[1][r], o[1][r], t[a], n[a]);
                    (this._line || 0 !== this._line && 1 === e) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null
            },
            point: function(t, n) {
                this._x.push(+t), this._y.push(+n)
            }
        };

        function dn(t, n) {
            this._context = t, this._t = n
        }
        dn.prototype = {
            areaStart: function() {
                this._line = 0
            },
            areaEnd: function() {
                this._line = NaN
            },
            lineStart: function() {
                this._x = this._y = NaN, this._point = 0
            },
            lineEnd: function() {
                0 < this._t && this._t < 1 && 2 === this._point && this._context.lineTo(this._x, this._y), (this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line)
            },
            point: function(t, n) {
                switch (t = +t, n = +n, this._point) {
                    case 0:
                        this._point = 1, this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                        break;
                    case 1:
                        this._point = 2;
                    default:
                        if (this._t <= 0) this._context.lineTo(this._x, n), this._context.lineTo(t, n);
                        else {
                            var e = this._x * (1 - this._t) + t * this._t;
                            this._context.lineTo(e, this._y), this._context.lineTo(e, n)
                        }
                }
                this._x = t, this._y = n
            }
        };
        Array.prototype.slice;
        var pn = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                return typeof t
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
            },
            _n = function(t, n) {
                if (!(t instanceof n)) throw new TypeError("Cannot call a class as a function")
            },
            yn = function() {
                function t(t, n) {
                    for (var e = 0; e < n.length; e++) {
                        var i = n[e];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
                    }
                }
                return function(n, e, i) {
                    return e && t(n.prototype, e), i && t(n, i), n
                }
            }(),
            vn = Object.assign || function(t) {
                for (var n = 1; n < arguments.length; n++) {
                    var e = arguments[n];
                    for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i])
                }
                return t
            },
            xn = function t(n, e, i) {
                null === n && (n = Function.prototype);
                var o = Object.getOwnPropertyDescriptor(n, e);
                if (void 0 === o) {
                    var r = Object.getPrototypeOf(n);
                    return null === r ? void 0 : t(r, e, i)
                }
                if ("value" in o) return o.value;
                var a = o.get;
                return void 0 !== a ? a.call(i) : void 0
            },
            gn = function(t, n) {
                if ("function" != typeof n && null !== n) throw new TypeError("Super expression must either be null or a function, not " + typeof n);
                t.prototype = Object.create(n && n.prototype, {
                    constructor: {
                        value: t,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0
                    }
                }), n && (Object.setPrototypeOf ? Object.setPrototypeOf(t, n) : t.__proto__ = n)
            },
            mn = function(t, n) {
                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !n || "object" != typeof n && "function" != typeof n ? t : n
            },
            bn = function() {
                function t(n) {
                    var e = n.x,
                        i = void 0 === e ? 0 : e,
                        o = n.y,
                        r = void 0 === o ? 0 : o,
                        a = n.nx,
                        s = n.ny,
                        c = n.dy,
                        h = void 0 === c ? 0 : c,
                        u = n.dx,
                        l = void 0 === u ? 0 : u,
                        f = n.color,
                        d = void 0 === f ? "grey" : f,
                        p = n.data,
                        _ = n.type,
                        y = n.subject,
                        v = n.connector,
                        x = n.note,
                        g = n.disable,
                        m = n.id,
                        b = n.className;
                    _n(this, t), this._dx = void 0 !== a ? a - i : l, this._dy = void 0 !== s ? s - r : h, this._x = i, this._y = r, this._color = d, this.id = m, this._className = b || "", this._type = _ || "", this.data = p, this.note = x || {}, this.connector = v || {}, this.subject = y || {}, this.disable = g || []
                }
                return yn(t, [{
                    key: "updatePosition",
                    value: function() {
                        this.type.setPosition && (this.type.setPosition(), this.type.subject && 0 !== this.type.subject.selectAll(":not(.handle)").nodes().length && this.type.redrawSubject())
                    }
                }, {
                    key: "clearComponents",
                    value: function() {
                        this.type.clearComponents && this.type.clearComponents()
                    }
                }, {
                    key: "updateOffset",
                    value: function() {
                        this.type.setOffset && (this.type.setOffset(), 0 !== this.type.connector.selectAll(":not(.handle)").nodes().length && this.type.redrawConnector(), this.type.redrawNote())
                    }
                }, {
                    key: "className",
                    get: function() {
                        return this._className
                    },
                    set: function(t) {
                        this._className = t, this.type.setClassName && this.type.setClassName()
                    }
                }, {
                    key: "type",
                    get: function() {
                        return this._type
                    },
                    set: function(t) {
                        this._type = t, this.clearComponents()
                    }
                }, {
                    key: "x",
                    get: function() {
                        return this._x
                    },
                    set: function(t) {
                        this._x = t, this.updatePosition()
                    }
                }, {
                    key: "y",
                    get: function() {
                        return this._y
                    },
                    set: function(t) {
                        this._y = t, this.updatePosition()
                    }
                }, {
                    key: "color",
                    get: function() {
                        return this._color
                    },
                    set: function(t) {
                        this._color = t, this.updatePosition()
                    }
                }, {
                    key: "dx",
                    get: function() {
                        return this._dx
                    },
                    set: function(t) {
                        this._dx = t, this.updateOffset()
                    }
                }, {
                    key: "dy",
                    get: function() {
                        return this._dy
                    },
                    set: function(t) {
                        this._dy = t, this.updateOffset()
                    }
                }, {
                    key: "nx",
                    set: function(t) {
                        this._dx = t - this._x, this.updateOffset()
                    }
                }, {
                    key: "ny",
                    set: function(t) {
                        this._dy = t - this._y, this.updateOffset()
                    }
                }, {
                    key: "offset",
                    get: function() {
                        return {
                            x: this._dx,
                            y: this._dy
                        }
                    },
                    set: function(t) {
                        var n = t.x,
                            e = t.y;
                        this._dx = n, this._dy = e, this.updateOffset()
                    }
                }, {
                    key: "position",
                    get: function() {
                        return {
                            x: this._x,
                            y: this._y
                        }
                    },
                    set: function(t) {
                        var n = t.x,
                            e = t.y;
                        this._x = n, this._y = e, this.updatePosition()
                    }
                }, {
                    key: "translation",
                    get: function() {
                        return {
                            x: this._x + this._dx,
                            y: this._y + this._dy
                        }
                    }
                }, {
                    key: "json",
                    get: function() {
                        var t = {
                            x: this._x,
                            y: this._y,
                            dx: this._dx,
                            dy: this._dy
                        };
                        return this.data && Object.keys(this.data).length > 0 && (t.data = this.data), this.type && (t.type = this.type), this._className && (t.className = this._className), Object.keys(this.connector).length > 0 && (t.connector = this.connector), Object.keys(this.subject).length > 0 && (t.subject = this.subject), Object.keys(this.note).length > 0 && (t.note = this.note), t
                    }
                }]), t
            }(),
            wn = function() {
                function t(n) {
                    var e = n.annotations,
                        i = n.accessors,
                        o = n.accessorsInverse;
                    _n(this, t), this.accessors = i, this.accessorsInverse = o, this.annotations = e
                }
                return yn(t, [{
                    key: "clearTypes",
                    value: function(t) {
                        this.annotations.forEach(function(n) {
                            n.type = void 0, n.subject = t && t.subject || n.subject, n.connector = t && t.connector || n.connector, n.note = t && t.note || n.note
                        })
                    }
                }, {
                    key: "setPositionWithAccessors",
                    value: function() {
                        var t = this;
                        this.annotations.forEach(function(n) {
                            n.type.setPositionWithAccessors(t.accessors)
                        })
                    }
                }, {
                    key: "editMode",
                    value: function(t) {
                        this.annotations.forEach(function(n) {
                            n.type && (n.type.editMode = t, n.type.updateEditMode())
                        })
                    }
                }, {
                    key: "updateDisable",
                    value: function(t) {
                        this.annotations.forEach(function(n) {
                            n.disable = t, n.type && t.forEach(function(t) {
                                n.type[t] && (n.type[t].remove && n.type[t].remove(), n.type[t] = void 0)
                            })
                        })
                    }
                }, {
                    key: "updateTextWrap",
                    value: function(t) {
                        this.annotations.forEach(function(n) {
                            n.type && n.type.updateTextWrap && n.type.updateTextWrap(t)
                        })
                    }
                }, {
                    key: "updateText",
                    value: function() {
                        this.annotations.forEach(function(t) {
                            t.type && t.type.drawText && t.type.drawText()
                        })
                    }
                }, {
                    key: "updateNotePadding",
                    value: function(t) {
                        this.annotations.forEach(function(n) {
                            n.type && (n.type.notePadding = t)
                        })
                    }
                }, {
                    key: "json",
                    get: function() {
                        var t = this;
                        return this.annotations.map(function(n) {
                            var e = n.json;
                            return t.accessorsInverse && n.data && (e.data = {}, Object.keys(t.accessorsInverse).forEach(function(i) {
                                e.data[i] = t.accessorsInverse[i]({
                                    x: n.x,
                                    y: n.y
                                })
                            })), e
                        })
                    }
                }, {
                    key: "noteNodes",
                    get: function() {
                        return this.annotations.map(function(t) {
                            return vn({}, t.type.getNoteBBoxOffset(), {
                                positionX: t.x,
                                positionY: t.y
                            })
                        })
                    }
                }]), t
            }(),
            Mn = function(t, n) {
                return "dynamic" !== t && "left" !== t && "right" !== t || (t = n < 0 ? "top" : "bottom"), t
            },
            kn = function(t, n) {
                return "dynamic" !== t && "top" !== t && "bottom" !== t || (t = n < 0 ? "right" : "left"), t
            },
            Tn = ["topBottom", "top", "bottom"],
            Sn = ["leftRight", "left", "right"],
            jn = function(t) {
                var n = t.data,
                    e = t.curve,
                    i = void 0 === e ? Rt : e,
                    o = t.canvasContext,
                    r = t.className,
                    a = t.classID,
                    s = qt().curve(i),
                    c = {
                        type: "path",
                        className: r,
                        classID: a,
                        data: n
                    };
                return o ? (s.context(o), c.pathMethods = s) : c.attrs = {
                    d: s(n)
                }, c
            },
            Nn = function(t) {
                var n = t.data,
                    e = t.canvasContext,
                    i = {
                        type: "path",
                        className: t.className,
                        classID: t.classID,
                        data: n
                    },
                    o = function() {
                        var t = St,
                            n = jt,
                            e = bt(0),
                            i = null,
                            o = Nt,
                            r = Ot,
                            a = At,
                            s = null;

                        function c() {
                            var c, h, u = +t.apply(this, arguments),
                                l = +n.apply(this, arguments),
                                f = o.apply(this, arguments) - kt,
                                d = r.apply(this, arguments) - kt,
                                p = Math.abs(d - f),
                                _ = d > f;
                            if (s || (s = c = mt()), l < u && (h = l, l = u, u = h), l > wt)
                                if (p > Tt - wt) s.moveTo(l * Math.cos(f), l * Math.sin(f)), s.arc(0, 0, l, f, d, !_), u > wt && (s.moveTo(u * Math.cos(d), u * Math.sin(d)), s.arc(0, 0, u, d, f, _));
                                else {
                                    var y, v, x = f,
                                        g = d,
                                        m = f,
                                        b = d,
                                        w = p,
                                        M = p,
                                        k = a.apply(this, arguments) / 2,
                                        T = k > wt && (i ? +i.apply(this, arguments) : Math.sqrt(u * u + l * l)),
                                        S = Math.min(Math.abs(l - u) / 2, +e.apply(this, arguments)),
                                        j = S,
                                        N = S;
                                    if (T > wt) {
                                        var O = Et(T / u * Math.sin(k)),
                                            A = Et(T / l * Math.sin(k));
                                        (w -= 2 * O) > wt ? (m += O *= _ ? 1 : -1, b -= O) : (w = 0, m = b = (f + d) / 2), (M -= 2 * A) > wt ? (x += A *= _ ? 1 : -1, g -= A) : (M = 0, x = g = (f + d) / 2)
                                    }
                                    var E = l * Math.cos(x),
                                        P = l * Math.sin(x),
                                        C = u * Math.cos(b),
                                        R = u * Math.sin(b);
                                    if (S > wt) {
                                        var L = l * Math.cos(g),
                                            W = l * Math.sin(g),
                                            q = u * Math.cos(m),
                                            B = u * Math.sin(m);
                                        if (p < Mt) {
                                            var I = w > wt ? function(t, n, e, i, o, r, a, s) {
                                                    var c = e - t,
                                                        h = i - n,
                                                        u = a - o,
                                                        l = s - r,
                                                        f = (u * (n - r) - l * (t - o)) / (l * c - u * h);
                                                    return [t + f * c, n + f * h]
                                                }(E, P, q, B, L, W, C, R) : [C, R],
                                                D = E - I[0],
                                                H = P - I[1],
                                                z = L - I[0],
                                                Y = W - I[1],
                                                F = 1 / Math.sin(Math.acos((D * z + H * Y) / (Math.sqrt(D * D + H * H) * Math.sqrt(z * z + Y * Y))) / 2),
                                                X = Math.sqrt(I[0] * I[0] + I[1] * I[1]);
                                            j = Math.min(S, (u - X) / (F - 1)), N = Math.min(S, (l - X) / (F + 1))
                                        }
                                    }
                                    M > wt ? N > wt ? (y = Pt(q, B, E, P, l, N, _), v = Pt(L, W, C, R, l, N, _), s.moveTo(y.cx + y.x01, y.cy + y.y01), N < S ? s.arc(y.cx, y.cy, N, Math.atan2(y.y01, y.x01), Math.atan2(v.y01, v.x01), !_) : (s.arc(y.cx, y.cy, N, Math.atan2(y.y01, y.x01), Math.atan2(y.y11, y.x11), !_), s.arc(0, 0, l, Math.atan2(y.cy + y.y11, y.cx + y.x11), Math.atan2(v.cy + v.y11, v.cx + v.x11), !_), s.arc(v.cx, v.cy, N, Math.atan2(v.y11, v.x11), Math.atan2(v.y01, v.x01), !_))) : (s.moveTo(E, P), s.arc(0, 0, l, x, g, !_)) : s.moveTo(E, P), u > wt && w > wt ? j > wt ? (y = Pt(C, R, L, W, u, -j, _), v = Pt(E, P, q, B, u, -j, _), s.lineTo(y.cx + y.x01, y.cy + y.y01), j < S ? s.arc(y.cx, y.cy, j, Math.atan2(y.y01, y.x01), Math.atan2(v.y01, v.x01), !_) : (s.arc(y.cx, y.cy, j, Math.atan2(y.y01, y.x01), Math.atan2(y.y11, y.x11), !_), s.arc(0, 0, u, Math.atan2(y.cy + y.y11, y.cx + y.x11), Math.atan2(v.cy + v.y11, v.cx + v.x11), _), s.arc(v.cx, v.cy, j, Math.atan2(v.y11, v.x11), Math.atan2(v.y01, v.x01), !_))) : s.arc(0, 0, u, b, m, _) : s.lineTo(C, R)
                                } else s.moveTo(0, 0);
                            if (s.closePath(), c) return s = null, c + "" || null
                        }
                        return c.centroid = function() {
                            var e = (+t.apply(this, arguments) + +n.apply(this, arguments)) / 2,
                                i = (+o.apply(this, arguments) + +r.apply(this, arguments)) / 2 - Mt / 2;
                            return [Math.cos(i) * e, Math.sin(i) * e]
                        }, c.innerRadius = function(n) {
                            return arguments.length ? (t = "function" == typeof n ? n : bt(+n), c) : t
                        }, c.outerRadius = function(t) {
                            return arguments.length ? (n = "function" == typeof t ? t : bt(+t), c) : n
                        }, c.cornerRadius = function(t) {
                            return arguments.length ? (e = "function" == typeof t ? t : bt(+t), c) : e
                        }, c.padRadius = function(t) {
                            return arguments.length ? (i = null == t ? null : "function" == typeof t ? t : bt(+t), c) : i
                        }, c.startAngle = function(t) {
                            return arguments.length ? (o = "function" == typeof t ? t : bt(+t), c) : o
                        }, c.endAngle = function(t) {
                            return arguments.length ? (r = "function" == typeof t ? t : bt(+t), c) : r
                        }, c.padAngle = function(t) {
                            return arguments.length ? (a = "function" == typeof t ? t : bt(+t), c) : a
                        }, c.context = function(t) {
                            return arguments.length ? (s = null == t ? null : t, c) : s
                        }, c
                    }().innerRadius(n.innerRadius || 0).outerRadius(n.outerRadius || n.radius || 2).startAngle(n.startAngle || 0).endAngle(n.endAngle || 2 * Math.PI);
                return e ? (o.context(e), i.pathMethods = lineGen) : i.attrs = {
                    d: o()
                }, i
            },
            On = function(t) {
                var n = t.type,
                    e = t.subjectType,
                    i = n.annotation,
                    o = i.position,
                    r = i.x - o.x,
                    a = r + i.dx,
                    s = i.y - o.y,
                    c = s + i.dy,
                    h = i.subject;
                if ("circle" === e && (h.outerRadius || h.radius)) {
                    var u = Math.sqrt((r - a) * (r - a) + (s - c) * (s - c)),
                        l = Math.asin(-c / u),
                        f = h.outerRadius || h.radius + (h.radiusPadding || 0);
                    r = Math.abs(Math.cos(l) * f) * (a < 0 ? -1 : 1), s = Math.abs(Math.sin(l) * f) * (c < 0 ? -1 : 1)
                }
                if ("rect" === e) {
                    var d = h.width,
                        p = h.height;
                    (d > 0 && i.dx > 0 || d < 0 && i.dx < 0) && (r = Math.abs(d) > Math.abs(i.dx) ? d / 2 : d), (p > 0 && i.dy > 0 || p < 0 && i.dy < 0) && (s = Math.abs(p) > Math.abs(i.dy) ? p / 2 : p), r === d / 2 && s === p / 2 && (r = a, s = c)
                }
                return [
                    [r, s],
                    [a, c]
                ]
            },
            An = function(t) {
                var n = t.type,
                    e = t.connectorData,
                    i = t.subjectType;
                e || (e = {}), e.points && "number" != typeof e.points || (e.points = En(n.annotation.offset, e.points)), e.curve || (e.curve = Qt);
                var o = [];
                if (n.editMode) {
                    var r = e.points.map(function(t, n) {
                        return vn({}, function(t) {
                            var n = t.cx,
                                e = void 0 === n ? 0 : n,
                                i = t.cy;
                            return {
                                move: {
                                    x: e,
                                    y: void 0 === i ? 0 : i
                                }
                            }
                        }({
                            cx: t[0],
                            cy: t[1]
                        }), {
                            index: n
                        })
                    });
                    o = n.mapHandles(r.map(function(t) {
                        return vn({}, t.move, {
                            drag: function(t) {
                                e.points[t][0] += x.dx, e.points[t][1] += x.dy, n.redrawConnector()
                            }.bind(n, t.index)
                        })
                    }))
                }
                var a = On({
                    type: n,
                    subjectType: i
                });
                return a = [a[0]].concat(function(t) {
                    if (Array.isArray(t)) {
                        for (var n = 0, e = Array(t.length); n < t.length; n++) e[n] = t[n];
                        return e
                    }
                    return Array.from(t)
                }(e.points), [a[1]]), {
                    components: [jn({
                        data: a,
                        curve: e.curve,
                        className: "connector"
                    })],
                    handles: o
                }
            },
            En = function(t) {
                for (var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2, e = t.x / (n + 1), i = t.y / (n + 1), o = [], r = 1; r <= n; r++) o.push([e * r + r % 2 * 20, i * r - r % 2 * 20]);
                return o
            },
            Pn = function(t) {
                var n = t.subjectData,
                    e = t.type;
                n.radius || n.outerRadius || (n.radius = 20);
                var i = [],
                    o = Nn({
                        data: n,
                        className: "subject"
                    });
                if (e.editMode) {
                    var r = function(t) {
                            var n = t.cx,
                                e = void 0 === n ? 0 : n,
                                i = t.cy,
                                o = void 0 === i ? 0 : i,
                                r = t.r1,
                                a = t.r2,
                                s = t.padding,
                                c = {
                                    move: {
                                        x: e,
                                        y: o
                                    }
                                };
                            return void 0 !== r && (c.r1 = {
                                x: e + r / Math.sqrt(2),
                                y: o + r / Math.sqrt(2)
                            }), void 0 !== a && (c.r2 = {
                                x: e + a / Math.sqrt(2),
                                y: o + a / Math.sqrt(2)
                            }), void 0 !== s && (c.padding = {
                                x: e + r + s,
                                y: o
                            }), c
                        }({
                            r1: o.data.outerRadius || o.data.radius,
                            r2: o.data.innerRadius,
                            padding: n.radiusPadding
                        }),
                        a = function(t) {
                            var i = n[t] + x.dx * Math.sqrt(2);
                            n[t] = i, e.redrawSubject(), e.redrawConnector()
                        },
                        s = [vn({}, r.r1, {
                            drag: a.bind(e, void 0 !== n.outerRadius ? "outerRadius" : "radius")
                        })];
                    n.innerRadius && s.push(vn({}, r.r2, {
                        drag: a.bind(e, "innerRadius")
                    })), i = e.mapHandles(s)
                }
                return o.attrs["fill-opacity"] = 0, {
                    components: [o],
                    handles: i
                }
            },
            Cn = function() {
                function t(n) {
                    var e = n.a,
                        i = n.annotation,
                        o = n.editMode,
                        r = n.dispatcher,
                        a = n.notePadding,
                        s = n.accessors;
                    if (_n(this, t), this.a = e, this.note = -1 === i.disable.indexOf("note") && e.select("g.annotation-note"), this.noteContent = this.note && e.select("g.annotation-note-content"), this.connector = -1 === i.disable.indexOf("connector") && e.select("g.annotation-connector"), this.subject = -1 === i.disable.indexOf("subject") && e.select("g.annotation-subject"), this.dispatcher = r, r) {
                        var c = Dn.bind(null, r, i);
                        c({
                            component: this.note,
                            name: "note"
                        }), c({
                            component: this.connector,
                            name: "connector"
                        }), c({
                            component: this.subject,
                            name: "subject"
                        })
                    }
                    this.annotation = i, this.editMode = i.editMode || o, this.notePadding = void 0 !== a ? a : 3, this.offsetCornerX = 0, this.offsetCornerY = 0, s && i.data && this.init(s)
                }
                return yn(t, [{
                    key: "init",
                    value: function(t) {
                        this.annotation.x || this.mapX(t), this.annotation.y || this.mapY(t)
                    }
                }, {
                    key: "mapY",
                    value: function(t) {
                        t.y && (this.annotation.y = t.y(this.annotation.data))
                    }
                }, {
                    key: "mapX",
                    value: function(t) {
                        t.x && (this.annotation.x = t.x(this.annotation.data))
                    }
                }, {
                    key: "updateEditMode",
                    value: function() {
                        this.a.selectAll("circle.handle").remove()
                    }
                }, {
                    key: "drawOnSVG",
                    value: function(t, n) {
                        var e = this;
                        Array.isArray(n) || (n = [n]), n.filter(function(t) {
                            return t
                        }).forEach(function(n) {
                            var i = n.type,
                                o = n.className,
                                r = n.attrs,
                                a = n.handles,
                                s = n.classID;
                            if ("handle" === i) ! function(t) {
                                var n = t.group,
                                    e = t.handles,
                                    i = t.r,
                                    o = void 0 === i ? 10 : i,
                                    r = n.selectAll("circle.handle").data(e);
                                r.enter().append("circle").attr("class", "handle").attr("fill", "grey").attr("fill-opacity", .1).attr("cursor", "move").attr("stroke-dasharray", 5).attr("stroke", "grey").call(pt().container(Z("g.annotations").node()).on("start", function(t) {
                                    return t.start && t.start(t)
                                }).on("drag", function(t) {
                                    return t.drag && t.drag(t)
                                }).on("end", function(t) {
                                    return t.end && t.end(t)
                                })), n.selectAll("circle.handle").attr("cx", function(t) {
                                    return t.x
                                }).attr("cy", function(t) {
                                    return t.y
                                }).attr("r", function(t) {
                                    return t.r || o
                                }).attr("class", function(t) {
                                    return "handle " + (t.className || "")
                                }), r.exit().remove()
                            }({
                                group: t,
                                r: r && r.r,
                                handles: a
                            });
                            else {
                                In(t, [e.annotation], i, o, s);
                                for (var c = t.select(i + "." + (s || o)), h = Object.keys(r), u = [], l = c.node().attributes, f = l.length - 1; f >= 0; f--) {
                                    var d = l[f].name; - 1 === h.indexOf(d) && "class" !== d && u.push(d)
                                }
                                h.forEach(function(t) {
                                    "text" === t ? c.text(r[t]) : c.attr(t, r[t])
                                }), u.forEach(function(t) {
                                    return c.attr(t, null)
                                })
                            }
                        })
                    }
                }, {
                    key: "getNoteBBox",
                    value: function() {
                        return zn(this.note, ".annotation-note-content text")
                    }
                }, {
                    key: "getNoteBBoxOffset",
                    value: function() {
                        var t = zn(this.note, ".annotation-note-content"),
                            n = this.noteContent.attr("transform").split(/\(|\,|\)/g);
                        return t.offsetCornerX = parseFloat(n[1]) + this.annotation.dx, t.offsetCornerY = parseFloat(n[2]) + this.annotation.dy, t.offsetX = this.annotation.dx, t.offsetY = this.annotation.dy, t
                    }
                }, {
                    key: "drawSubject",
                    value: function() {
                        var t = this,
                            n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            e = this.annotation.subject,
                            i = n.type,
                            o = {
                                type: this,
                                subjectData: e
                            },
                            r = {};
                        "circle" === i ? r = Pn(o) : "rect" === i ? r = function(t) {
                            var n = t.subjectData,
                                e = t.type;
                            n.width || (n.width = 100), n.height || (n.height = 100);
                            var i = [],
                                o = n.width,
                                r = n.height,
                                a = jn({
                                    data: [
                                        [0, 0],
                                        [o, 0],
                                        [o, r],
                                        [0, r],
                                        [0, 0]
                                    ],
                                    className: "subject"
                                });
                            if (e.editMode) {
                                var s = [{
                                    x: o,
                                    y: r / 2,
                                    drag: function() {
                                        n.width = x.x, e.redrawSubject(), e.redrawConnector()
                                    }.bind(e)
                                }, {
                                    x: o / 2,
                                    y: r,
                                    drag: function() {
                                        n.height = x.y, e.redrawSubject(), e.redrawConnector()
                                    }.bind(e)
                                }];
                                i = e.mapHandles(s)
                            }
                            return a.attrs["fill-opacity"] = .1, {
                                components: [a],
                                handles: i
                            }
                        }(o) : "threshold" === i ? r = function(t) {
                            var n = t.subjectData,
                                e = t.type.annotation.position,
                                i = (void 0 !== n.x1 ? n.x1 : e.x) - e.x,
                                o = (void 0 !== n.x2 ? n.x2 : e.x) - e.x,
                                r = (void 0 !== n.y1 ? n.y1 : e.y) - e.y,
                                a = (void 0 !== n.y2 ? n.y2 : e.y) - e.y;
                            return {
                                components: [jn({
                                    data: [
                                        [i, r],
                                        [o, a]
                                    ],
                                    className: "subject"
                                })]
                            }
                        }(o) : "badge" === i && (r = function(t) {
                            var n = t.subjectData,
                                e = void 0 === n ? {} : n,
                                i = t.type,
                                o = void 0 === i ? {} : i,
                                r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                                a = o.typeSettings && o.typeSettings.subject;
                            e.radius || (a && a.radius ? e.radius = a.radius : e.radius = 14), e.x || a && a.x && (e.x = a.x), e.y || a && a.y && (e.y = a.y);
                            var s = [],
                                c = [],
                                h = e.radius,
                                u = .7 * h,
                                l = 0,
                                f = 0,
                                d = Math.sqrt(2) * h,
                                p = {
                                    xleftcorner: -h,
                                    xrightcorner: h,
                                    ytopcorner: -h,
                                    ybottomcorner: h,
                                    xleft: -d,
                                    xright: d,
                                    ytop: -d,
                                    ybottom: d
                                };
                            e.x && !e.y ? l = p["x" + e.x] : e.y && !e.x ? f = p["y" + e.y] : e.x && e.y && (l = p["x" + e.x + "corner"], f = p["y" + e.y + "corner"]);
                            var _ = "translate(" + l + ", " + f + ")",
                                y = Nn({
                                    className: "subject",
                                    data: {
                                        radius: h
                                    }
                                });
                            y.attrs.transform = _, y.attrs.fill = r.color, y.attrs["stroke-linecap"] = "round", y.attrs["stroke-width"] = "3px";
                            var v = Nn({
                                className: "subject-ring",
                                data: {
                                    outerRadius: h,
                                    innerRadius: u
                                }
                            });
                            v.attrs.transform = _, v.attrs["stroke-width"] = "3px", v.attrs.fill = "white";
                            var g = void 0;
                            if (l && f || !l && !f) g = jn({
                                className: "subject-pointer",
                                data: [
                                    [0, 0],
                                    [l || 0, 0],
                                    [0, f || 0],
                                    [0, 0]
                                ]
                            });
                            else if (l || f) {
                                var m = function(t) {
                                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
                                    return t && t / Math.sqrt(2) / Math.sqrt(2) || n * h / Math.sqrt(2)
                                };
                                g = jn({
                                    className: "subject-pointer",
                                    data: [
                                        [0, 0],
                                        [m(l), m(f)],
                                        [m(l, -1), m(f, -1)],
                                        [0, 0]
                                    ]
                                })
                            }
                            if (g && (g.attrs.fill = r.color, g.attrs["stroke-linecap"] = "round", g.attrs["stroke-width"] = "3px", c.push(g)), o.editMode) {
                                var b = {
                                    x: 2 * l,
                                    y: 2 * f,
                                    drag: function() {
                                        e.x = x.x < 2 * -h ? "left" : x.x > 2 * h ? "right" : void 0, e.y = x.y < 2 * -h ? "top" : x.y > 2 * h ? "bottom" : void 0, o.redrawSubject()
                                    }.bind(o)
                                };
                                b.x || b.y || (b.y = -h), s = o.mapHandles([b])
                            }
                            var w = void 0;
                            return e.text && (w = {
                                type: "text",
                                className: "badge-text",
                                attrs: {
                                    fill: "white",
                                    stroke: "none",
                                    "font-size": ".7em",
                                    text: e.text,
                                    "text-anchor": "middle",
                                    dy: ".25em",
                                    x: l,
                                    y: f
                                }
                            }), c.push(y), c.push(v), c.push(w), {
                                components: c,
                                handles: s
                            }
                        }(o, this.annotation));
                        var a = r,
                            s = a.components,
                            c = void 0 === s ? [] : s,
                            h = a.handles,
                            u = void 0 === h ? [] : h;
                        return c.forEach(function(n) {
                            n && n.attrs && !n.attrs.stroke && (n.attrs.stroke = t.annotation.color)
                        }), this.editMode && (u = u.concat(this.mapHandles([{
                            drag: this.dragSubject.bind(this)
                        }])), c.push({
                            type: "handle",
                            handles: u
                        })), c
                    }
                }, {
                    key: "drawConnector",
                    value: function() {
                        var t = this,
                            n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            e = this.annotation.connector,
                            i = e.type || n.type,
                            o = {
                                type: this,
                                connectorData: e
                            };
                        o.subjectType = this.typeSettings && this.typeSettings.subject && this.typeSettings.subject.type;
                        var r = "curve" === i ? An(o) : "elbow" === i ? function(t) {
                                var n = t.type,
                                    e = t.subjectType,
                                    i = n.annotation,
                                    o = i.position,
                                    r = i.x - o.x,
                                    a = r + i.dx,
                                    s = i.y - o.y,
                                    c = s + i.dy,
                                    h = i.subject;
                                if ("rect" === e) {
                                    var u = h.width,
                                        l = h.height;
                                    (u > 0 && i.dx > 0 || u < 0 && i.dx < 0) && (r = Math.abs(u) > Math.abs(i.dx) ? u / 2 : u), (l > 0 && i.dy > 0 || l < 0 && i.dy < 0) && (s = Math.abs(l) > Math.abs(i.dy) ? l / 2 : l), r === u / 2 && s === l / 2 && (r = a, s = c)
                                }
                                var f = [
                                        [r, s],
                                        [a, c]
                                    ],
                                    d = c - s,
                                    p = a - r,
                                    _ = a,
                                    y = c,
                                    v = c < s && a > r || a < r && c > s ? -1 : 1;
                                if (Math.abs(p) < Math.abs(d) ? (_ = a, y = s + p * v) : (y = c, _ = r + d * v), "circle" === e && (h.outerRadius || h.radius)) {
                                    var x = (h.outerRadius || h.radius) + (h.radiusPadding || 0),
                                        g = x / Math.sqrt(2);
                                    if (Math.abs(p) > g && Math.abs(d) > g) f = [
                                        [r = g * (a < 0 ? -1 : 1), s = g * (c < 0 ? -1 : 1)],
                                        [_, y],
                                        [a, c]
                                    ];
                                    else if (Math.abs(p) > Math.abs(d)) {
                                        var m = Math.asin(-c / x);
                                        f = [
                                            [r = Math.abs(Math.cos(m) * x) * (a < 0 ? -1 : 1), c],
                                            [a, c]
                                        ]
                                    } else {
                                        var b = Math.acos(a / x);
                                        f = [
                                            [a, s = Math.abs(Math.sin(b) * x) * (c < 0 ? -1 : 1)],
                                            [a, c]
                                        ]
                                    }
                                } else f = [
                                    [r, s],
                                    [_, y],
                                    [a, c]
                                ];
                                return {
                                    components: [jn({
                                        data: f,
                                        className: "connector"
                                    })]
                                }
                            }(o) : function(t) {
                                var n = On(t);
                                return {
                                    components: [jn({
                                        data: n,
                                        className: "connector"
                                    })]
                                }
                            }(o),
                            a = r.components,
                            s = void 0 === a ? [] : a,
                            c = r.handles,
                            h = void 0 === c ? [] : c,
                            u = s[0];
                        u && (u.attrs.stroke = this.annotation.color, u.attrs.fill = "none");
                        var l = e.end || n.end,
                            f = {};
                        if ("arrow" === l) {
                            var d = u.data[1],
                                p = u.data[0];
                            Math.sqrt(Math.pow(d[0] - p[0], 2) + Math.pow(d[1] - p[1], 2)) < 5 && u.data[2] && (d = u.data[2]), f = function(t) {
                                var n = t.annotation,
                                    e = t.start,
                                    i = t.end,
                                    o = t.scale,
                                    r = void 0 === o ? 1 : o,
                                    a = n.position;
                                e = e ? [-i[0] + e[0], -i[1] + e[1]] : [n.dx, n.dy], i || (i = [n.x - a.x, n.y - a.y]);
                                var s = i[0],
                                    c = i[1],
                                    h = e[0],
                                    u = e[1],
                                    l = 10 * r,
                                    f = 16 / 180 * Math.PI,
                                    d = Math.atan(u / h);
                                h < 0 && (d += Math.PI);
                                var p = [
                                    [s, c],
                                    [Math.cos(d + f) * l + s, Math.sin(d + f) * l + c],
                                    [Math.cos(d - f) * l + s, Math.sin(d - f) * l + c],
                                    [s, c]
                                ];
                                return {
                                    components: [jn({
                                        data: p,
                                        className: "connector-end connector-arrow",
                                        classID: "connector-end"
                                    })]
                                }
                            }({
                                annotation: this.annotation,
                                start: d,
                                end: p,
                                scale: e.endScale
                            })
                        } else "dot" === l ? f = function(t) {
                            var n = t.line,
                                e = t.scale,
                                i = void 0 === e ? 1 : e,
                                o = Nn({
                                    className: "connector-end connector-dot",
                                    classID: "connector-end",
                                    data: {
                                        radius: 3 * Math.sqrt(i)
                                    }
                                });
                            return o.attrs.transform = "translate(" + n.data[0][0] + ", " + n.data[0][1] + ")", {
                                components: [o]
                            }
                        }({
                            line: u,
                            scale: e.endScale
                        }) : l && "none" !== l || this.connector && this.connector.select(".connector-end").remove();
                        return f.components && (f.components.forEach(function(n) {
                            n.attrs.fill = t.annotation.color, n.attrs.stroke = t.annotation.color
                        }), s = s.concat(f.components)), this.editMode && 0 !== h.length && s.push({
                            type: "handle",
                            handles: h
                        }), s
                    }
                }, {
                    key: "drawNote",
                    value: function() {
                        var t = this,
                            n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            e = this.annotation.note,
                            i = e.align || n.align || "dynamic",
                            o = {
                                bbox: n.bbox,
                                align: i,
                                offset: this.annotation.offset
                            },
                            r = e.lineType || n.lineType,
                            a = {};
                        "vertical" === r ? a = function(t) {
                            var n = t.align,
                                e = t.x,
                                i = void 0 === e ? 0 : e,
                                o = t.y,
                                r = void 0 === o ? 0 : o,
                                a = t.bbox,
                                s = t.offset;
                            "top" === (n = Mn(n, s.y)) ? r -= a.height: "middle" === n && (r -= a.height / 2);
                            var c = [
                                [i, r],
                                [i, r + a.height]
                            ];
                            return {
                                components: [jn({
                                    data: c,
                                    className: "note-line"
                                })]
                            }
                        }(o) : "horizontal" === r && (a = function(t) {
                            var n = t.align,
                                e = t.x,
                                i = void 0 === e ? 0 : e,
                                o = t.y,
                                r = void 0 === o ? 0 : o,
                                a = t.offset,
                                s = t.bbox;
                            "right" === (n = kn(n, a.x)) ? i -= s.width: "middle" === n && (i -= s.width / 2);
                            var c = [
                                [i, r],
                                [i + s.width, r]
                            ];
                            return {
                                components: [jn({
                                    data: c,
                                    className: "note-line"
                                })]
                            }
                        }(o));
                        var s = a,
                            c = s.components,
                            h = void 0 === c ? [] : c,
                            u = s.handles,
                            l = void 0 === u ? [] : u;
                        if (h.forEach(function(n) {
                                n.attrs.stroke = t.annotation.color
                            }), this.editMode) {
                            l = this.mapHandles([{
                                x: 0,
                                y: 0,
                                drag: this.dragNote.bind(this)
                            }]), h.push({
                                type: "handle",
                                handles: l
                            });
                            var f = this.dragNote.bind(this),
                                d = this.dragstarted.bind(this),
                                p = this.dragended.bind(this);
                            this.note.call(pt().container(Z("g.annotations").node()).on("start", function(t) {
                                return d(t)
                            }).on("drag", function(t) {
                                return f(t)
                            }).on("end", function(t) {
                                return p(t)
                            }))
                        } else this.note.on("mousedown.drag", null);
                        return h
                    }
                }, {
                    key: "drawNoteContent",
                    value: function(t) {
                        var n = this.annotation.note,
                            e = void 0 !== n.padding ? n.padding : this.notePadding,
                            i = n.orientation || t.orientation || "topBottom",
                            o = n.lineType || t.lineType,
                            r = n.align || t.align || "dynamic";
                        "vertical" === o ? i = "leftRight" : "horizontal" === o && (i = "topBottom");
                        var a = function(t) {
                                var n = t.padding,
                                    e = void 0 === n ? 0 : n,
                                    i = t.bbox,
                                    o = void 0 === i ? {
                                        x: 0,
                                        y: 0,
                                        width: 0,
                                        height: 0
                                    } : i,
                                    r = t.align,
                                    a = t.orientation,
                                    s = t.offset,
                                    c = void 0 === s ? {
                                        x: 0,
                                        y: 0
                                    } : s,
                                    h = -o.x,
                                    u = 0;
                                return -1 !== Tn.indexOf(a) ? (r = kn(r, c.x), c.y < 0 && "topBottom" === a || "top" === a ? u -= o.height + e : u += e, "middle" === r ? h -= o.width / 2 : "right" === r && (h -= o.width)) : -1 !== Sn.indexOf(a) && (r = Mn(r, c.y), c.x < 0 && "leftRight" === a || "left" === a ? h -= o.width + e : h += e, "middle" === r ? u -= o.height / 2 : "top" === r && (u -= o.height)), {
                                    x: h,
                                    y: u
                                }
                            }({
                                padding: e,
                                bbox: t.bbox,
                                offset: this.annotation.offset,
                                orientation: i,
                                align: r
                            }),
                            s = a.x,
                            c = a.y;
                        return this.offsetCornerX = s + this.annotation.dx, this.offsetCornerY = c + this.annotation.dy, this.note && this.noteContent.attr("transform", "translate(" + s + ", " + c + ")"), []
                    }
                }, {
                    key: "drawOnScreen",
                    value: function(t, n) {
                        return this.drawOnSVG(t, n)
                    }
                }, {
                    key: "redrawSubject",
                    value: function() {
                        this.subject && this.drawOnScreen(this.subject, this.drawSubject())
                    }
                }, {
                    key: "redrawConnector",
                    value: function() {
                        this.connector && this.drawOnScreen(this.connector, this.drawConnector())
                    }
                }, {
                    key: "redrawNote",
                    value: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this.getNoteBBox();
                        this.noteContent && this.drawOnScreen(this.noteContent, this.drawNoteContent({
                            bbox: t
                        })), this.note && this.drawOnScreen(this.note, this.drawNote({
                            bbox: t
                        }))
                    }
                }, {
                    key: "setPosition",
                    value: function() {
                        var t = this.annotation.position;
                        this.a.attr("transform", "translate(" + t.x + ", " + t.y + ")")
                    }
                }, {
                    key: "clearComponents",
                    value: function() {
                        this.subject && this.subject.select("*").remove(), this.connector && this.connector.select("*").remove()
                    }
                }, {
                    key: "setOffset",
                    value: function() {
                        if (this.note) {
                            var t = this.annotation.offset;
                            this.note.attr("transform", "translate(" + t.x + ", " + t.y + ")")
                        }
                    }
                }, {
                    key: "setPositionWithAccessors",
                    value: function(t) {
                        t && this.annotation.data && (this.mapX(t), this.mapY(t)), this.setPosition()
                    }
                }, {
                    key: "setClassName",
                    value: function() {
                        this.a.attr("class", "annotation " + (this.className && this.className()) + " " + (this.editMode ? "editable" : "") + " " + (this.annotation.className || ""))
                    }
                }, {
                    key: "draw",
                    value: function() {
                        this.setClassName(), this.setPosition(), this.setOffset(), this.redrawSubject(), this.redrawConnector(), this.redrawNote()
                    }
                }, {
                    key: "dragstarted",
                    value: function() {
                        x.sourceEvent.stopPropagation(), this.dispatcher && this.dispatcher.call("dragstart", this.a, this.annotation), this.a.classed("dragging", !0), this.a.selectAll("circle.handle").style("pointer-events", "none")
                    }
                }, {
                    key: "dragended",
                    value: function() {
                        this.dispatcher && this.dispatcher.call("dragend", this.a, this.annotation), this.a.classed("dragging", !1), this.a.selectAll("circle.handle").style("pointer-events", "all")
                    }
                }, {
                    key: "dragSubject",
                    value: function() {
                        var t = this.annotation.position;
                        t.x += x.dx, t.y += x.dy, this.annotation.position = t
                    }
                }, {
                    key: "dragNote",
                    value: function() {
                        var t = this.annotation.offset;
                        t.x += x.dx, t.y += x.dy, this.annotation.offset = t
                    }
                }, {
                    key: "mapHandles",
                    value: function(t) {
                        var n = this;
                        return t.map(function(t) {
                            return vn({}, t, {
                                start: n.dragstarted.bind(n),
                                end: n.dragended.bind(n)
                            })
                        })
                    }
                }]), t
            }(),
            Rn = function(t, n, e) {
                return function(i) {
                    function o(t) {
                        _n(this, o);
                        var e = mn(this, (o.__proto__ || Object.getPrototypeOf(o)).call(this, t));
                        return e.typeSettings = n, n.disable && n.disable.forEach(function(t) {
                            e[t] && e[t].remove(), e[t] = void 0, "note" === t && (e.noteContent = void 0)
                        }), e
                    }
                    return gn(o, t), yn(o, [{
                        key: "className",
                        value: function() {
                            return "" + (n.className || xn(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "className", this) && xn(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "className", this).call(this) || "")
                        }
                    }, {
                        key: "drawSubject",
                        value: function(t) {
                            return this.typeSettings.subject = vn({}, n.subject, this.typeSettings.subject), xn(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "drawSubject", this).call(this, vn({}, t, this.typeSettings.subject))
                        }
                    }, {
                        key: "drawConnector",
                        value: function(t) {
                            return this.typeSettings.connector = vn({}, n.connector, this.typeSettings.connector), xn(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "drawConnector", this).call(this, vn({}, t, n.connector, this.typeSettings.connector))
                        }
                    }, {
                        key: "drawNote",
                        value: function(t) {
                            return this.typeSettings.note = vn({}, n.note, this.typeSettings.note), xn(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "drawNote", this).call(this, vn({}, t, n.note, this.typeSettings.note))
                        }
                    }, {
                        key: "drawNoteContent",
                        value: function(t) {
                            return xn(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "drawNoteContent", this).call(this, vn({}, t, n.note, this.typeSettings.note))
                        }
                    }], [{
                        key: "init",
                        value: function(t, n) {
                            return xn(o.__proto__ || Object.getPrototypeOf(o), "init", this).call(this, t, n), e && (t = e(t, n)), t
                        }
                    }]), o
                }()
            },
            Ln = function(t) {
                function n(t) {
                    _n(this, n);
                    var e = mn(this, (n.__proto__ || Object.getPrototypeOf(n)).call(this, t));
                    return e.textWrap = t.textWrap || 120, e.drawText(), e
                }
                return gn(n, Cn), yn(n, [{
                    key: "updateTextWrap",
                    value: function(t) {
                        this.textWrap = t, this.drawText()
                    }
                }, {
                    key: "drawText",
                    value: function() {
                        if (this.note) {
                            In(this.note, [this.annotation], "g", "annotation-note-content");
                            var t = this.note.select("g.annotation-note-content");
                            In(t, [this.annotation], "rect", "annotation-note-bg"), In(t, [this.annotation], "text", "annotation-note-label"), In(t, [this.annotation], "text", "annotation-note-title");
                            var n = {
                                    height: 0
                                },
                                e = this.a.select("text.annotation-note-label"),
                                i = this.annotation.note && this.annotation.note.wrap || this.typeSettings && this.typeSettings.note && this.typeSettings.note.wrap || this.textWrap,
                                o = this.annotation.note && this.annotation.note.wrapSplitter || this.typeSettings && this.typeSettings.note && this.typeSettings.note.wrapSplitter,
                                r = this.annotation.note && this.annotation.note.bgPadding || this.typeSettings && this.typeSettings.note && this.typeSettings.note.bgPadding,
                                a = {
                                    top: 0,
                                    bottom: 0,
                                    left: 0,
                                    right: 0
                                };
                            if ("number" == typeof r ? a = {
                                    top: r,
                                    bottom: r,
                                    left: r,
                                    right: r
                                } : r && "object" === (void 0 === r ? "undefined" : pn(r)) && (a = vn(a, r)), this.annotation.note.title) {
                                var s = this.a.select("text.annotation-note-title");
                                s.text(this.annotation.note.title), s.attr("fill", this.annotation.color), s.attr("font-weight", "bold"), s.call(Hn, i, o), n = s.node().getBBox()
                            }
                            e.text(this.annotation.note.label).attr("dx", "0"), e.call(Hn, i, o), e.attr("y", 1.1 * n.height || 0), e.attr("fill", this.annotation.color);
                            var c = this.getNoteBBox();
                            this.a.select("rect.annotation-note-bg").attr("width", c.width + a.left + a.right).attr("height", c.height + a.top + a.bottom).attr("x", c.x - a.left).attr("y", -a.top).attr("fill", "white").attr("fill-opacity", 0)
                        }
                    }
                }]), n
            }(),
            Wn = (Rn(Ln, {
                className: "label",
                note: {
                    align: "middle"
                }
            }), Rn(Ln, {
                className: "callout",
                note: {
                    lineType: "horizontal"
                }
            })),
            qn = (Rn(Wn, {
                className: "callout elbow",
                connector: {
                    type: "elbow"
                }
            }), Rn(Wn, {
                className: "callout curve",
                connector: {
                    type: "curve"
                }
            })),
            Bn = (Rn(Cn, {
                className: "badge",
                subject: {
                    type: "badge"
                },
                disable: ["connector", "note"]
            }), Rn(Ln, {
                className: "callout circle",
                subject: {
                    type: "circle"
                },
                note: {
                    lineType: "horizontal"
                },
                connector: {
                    type: "elbow"
                }
            }), Rn(Ln, {
                className: "callout rect",
                subject: {
                    type: "rect"
                },
                note: {
                    lineType: "horizontal"
                },
                connector: {
                    type: "elbow"
                }
            }), function(t) {
                function n() {
                    return _n(this, n), mn(this, (n.__proto__ || Object.getPrototypeOf(n)).apply(this, arguments))
                }
                return gn(n, Wn), yn(n, [{
                    key: "mapY",
                    value: function(t) {
                        xn(n.prototype.__proto__ || Object.getPrototypeOf(n.prototype), "mapY", this).call(this, t);
                        var e = this.annotation;
                        (e.subject.x1 || e.subject.x2) && e.data && t.y && (e.y = t.y(e.data)), !e.subject.x1 && !e.subject.x2 || e.x || (e.x = e.subject.x1 || e.subject.x2)
                    }
                }, {
                    key: "mapX",
                    value: function(t) {
                        xn(n.prototype.__proto__ || Object.getPrototypeOf(n.prototype), "mapX", this).call(this, t);
                        var e = this.annotation;
                        (e.subject.y1 || e.subject.y2) && e.data && t.x && (e.x = t.x(e.data)), !e.subject.y1 && !e.subject.y2 || e.y || (e.y = e.subject.y1 || e.subject.y2)
                    }
                }]), n
            }()),
            In = (Rn(Bn, {
                className: "callout xythreshold",
                subject: {
                    type: "threshold"
                }
            }), function(t, n, e, i, o) {
                var r = t.selectAll(e + "." + (o || i)).data(n);
                return r.enter().append(e).merge(r).attr("class", i), r.exit().remove(), t
            }),
            Dn = function(t, n, e) {
                var i = e.component,
                    o = e.name;
                i && i.on("mouseover.annotations", function() {
                    t.call(o + "over", i, n)
                }).on("mouseout.annotations", function() {
                    return t.call(o + "out", i, n)
                }).on("click.annotations", function() {
                    return t.call(o + "click", i, n)
                })
            },
            Hn = function(t, n, e) {
                var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1.2;
                t.each(function() {
                    for (var t = Z(this), o = t.text().split(e || /[ \t\r\n]+/).reverse().filter(function(t) {
                            return "" !== t
                        }), r = void 0, a = [], s = t.text(null).append("tspan").attr("x", 0).attr("dy", "0.8em"); r = o.pop();) a.push(r), s.text(a.join(" ")), s.node().getComputedTextLength() > n && a.length > 1 && (a.pop(), s.text(a.join(" ")), a = [r], s = t.append("tspan").attr("x", 0).attr("dy", i + "em").text(r))
                })
            },
            zn = function(t) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ":not(.handle)";
                return t ? t.selectAll(n).nodes().reduce(function(t, n) {
                    var e = n.getBBox();
                    t.x = Math.min(t.x, e.x), t.y = Math.min(t.y, e.y), t.width = Math.max(t.width, e.width);
                    var i = n && n.attributes && n.attributes.y;
                    return t.height = Math.max(t.height, (i && parseFloat(i.value) || 0) + e.height), t
                }, {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0
                }) : {
                    x: 0,
                    y: 0,
                    width: 0,
                    height: 0
                }
            };

        function Yn() {
            var t = [],
                n = void 0,
                e = void 0,
                i = [],
                o = {},
                r = {},
                a = !1,
                s = void 0,
                c = Wn,
                h = void 0,
                u = void 0,
                l = rt("subjectover", "subjectout", "subjectclick", "connectorover", "connectorout", "connectorclick", "noteover", "noteout", "noteclick", "dragend", "dragstart"),
                f = void 0,
                d = function(e) {
                    f = e, a || e.selectAll("circle.handle").remove();
                    var d = t.map(function(t) {
                        return t.type || (t.type = c), t.disable || (t.disable = i), new bn(t)
                    });
                    n = n || new wn({
                        annotations: d,
                        accessors: o,
                        accessorsInverse: r,
                        ids: s
                    }), e.selectAll("g").data([n]).enter().append("g").attr("class", "annotations");
                    var p = e.select("g.annotations");
                    In(p, n.annotations, "g", "annotation");
                    var _ = p.selectAll("g.annotation");
                    _.each(function(t) {
                        var n = Z(this);
                        n.attr("class", "annotation"), In(n, [t], "g", "annotation-connector"), In(n, [t], "g", "annotation-subject"), In(n, [t], "g", "annotation-note"), In(n.select("g.annotation-note"), [t], "g", "annotation-note-content"), t.type = "[object Object]" === t.type.toString() ? t.type : new t.type({
                            a: n,
                            annotation: t,
                            textWrap: h,
                            notePadding: u,
                            editMode: a,
                            dispatcher: l,
                            accessors: o
                        }), t.type.draw(), t.type.drawText && t.type.drawText()
                    })
                };
            return d.json = function() {
                return console.log("Annotations JSON was copied to your clipboard. Please note the annotation type is not JSON compatible. It appears in the objects array in the console, but not in the copied JSON.", n.json), window.copy(JSON.stringify(n.json.map(function(t) {
                    return delete t.type, t
                }))), d
            }, d.update = function() {
                return t && n && (t = n.annotations.map(function(t) {
                    return t.type.draw(), t
                })), d
            }, d.updateText = function() {
                return n && (n.updateText(h), t = n.annotations), d
            }, d.updatedAccessors = function() {
                return n.setPositionWithAccessors(), t = n.annotations, d
            }, d.disable = function(e) {
                return arguments.length ? (i = e, n && (n.updateDisable(i), t = n.annotations), d) : i
            }, d.textWrap = function(e) {
                return arguments.length ? (h = e, n && (n.updateTextWrap(h), t = n.annotations), d) : h
            }, d.notePadding = function(e) {
                return arguments.length ? (u = e, n && (n.updateNotePadding(u), t = n.annotations), d) : u
            }, d.type = function(e, i) {
                return arguments.length ? (c = e, n && (n.annotations.map(function(t) {
                    t.type.note && t.type.note.selectAll("*:not(.annotation-note-content)").remove(), t.type.noteContent && t.type.noteContent.selectAll("*").remove(), t.type.subject && t.type.subject.selectAll("*").remove(), t.type.connector && t.type.connector.selectAll("*").remove(), t.type.typeSettings = {}, t.type = c, t.subject = i && i.subject || t.subject, t.connector = i && i.connector || t.connector, t.note = i && i.note || t.note
                }), t = n.annotations), d) : c
            }, d.annotations = function(e) {
                if (!arguments.length) return n && n.annotations || t;
                (t = e, n && n.annotations) && (t.some(function(t) {
                    return !t.type || "[object Object]" !== t.type.toString()
                }) ? (n = null, d(f)) : n.annotations = t);
                return d
            }, d.context = function(t) {
                return arguments.length ? (e = t, d) : e
            }, d.accessors = function(t) {
                return arguments.length ? (o = t, d) : o
            }, d.accessorsInverse = function(t) {
                return arguments.length ? (r = t, d) : r
            }, d.ids = function(t) {
                return arguments.length ? (s = t, d) : s
            }, d.editMode = function(e) {
                return arguments.length ? (a = e, f && f.selectAll("g.annotation").classed("editable", a), n && (n.editMode(a), t = n.annotations), d) : a
            }, d.collection = function(t) {
                return arguments.length ? (n = t, d) : n
            }, d.on = function() {
                var t = l.on.apply(l, arguments);
                return t === l ? d : t
            }, d
        }
        var Fn = e(3),
            Xn = e.n(Fn);
        var Gn = function(t) {
                var n = t.text,
                    e = t.chars,
                    i = void 0 === e ? 100 : e,
                    o = t.clean,
                    r = void 0 === o || o,
                    a = t.ellipses,
                    s = void 0 !== a && a,
                    c = n.length > i,
                    h = n.substring(0, i),
                    u = r ? h.lastIndexOf(" ") : h.length,
                    l = c ? h.substring(0, u) : n,
                    f = c && s ? "..." : "";
                return "".concat(l).concat(f)
            },
            Jn = e(4);

        function Vn(t, n) {
            return function(t) {
                if (Array.isArray(t)) return t
            }(t) || function(t, n) {
                var e = [],
                    i = !0,
                    o = !1,
                    r = void 0;
                try {
                    for (var a, s = t[Symbol.iterator](); !(i = (a = s.next()).done) && (e.push(a.value), !n || e.length !== n); i = !0);
                } catch (t) {
                    o = !0, r = t
                } finally {
                    try {
                        i || null == s.return || s.return()
                    } finally {
                        if (o) throw r
                    }
                }
                return e
            }(t, n) || function() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance")
            }()
        }

        function Un(t) {
            for (var n = 1; n < arguments.length; n++) {
                var e = null != arguments[n] ? arguments[n] : {},
                    i = Object.keys(e);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(e).filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }))), i.forEach(function(n) {
                    $n(t, n, e[n])
                })
            }
            return t
        }

        function $n(t, n, e) {
            return n in t ? Object.defineProperty(t, n, {
                value: e,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[n] = e, t
        }

        //отвечает за карты
        function Kn(t) {
            return function(t) {
                if (Array.isArray(t)) {
                    for (var n = 0, e = new Array(t.length); n < t.length; n++) e[n] = t[n];
                    return e
                }
            }(t) || function(t) {
                if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
            }(t) || function() {
                throw new TypeError("Invalid attempt to spread non-iterable instance")
            }()
        }
        var Zn = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"],
            Qn = 4 / 3,
            te = 320,
            ne = 16,
            ee = [],
            ie = [],
            oe = [],
            re = d3.select("#timeline"),
            ae = re.select(".figure__chart"),
            se = re.select(".figure__annotation"),
            ce = re.select(".timeline__headline"),
            he = ce.select("h3"),
            ue = ce.select("ul"),
            le = re.select(".timeline__toggle"),
            fe = d3.select("#outro"),
            de = ae.node(),
            pe = re.select(".mobile-label"),
            _e = 0,
            ye = 0,
            ve = 0,
            xe = 0,
            ge = 0,
            me = !1,
            be = 0,
            we = 0,
            Me = 0,
            ke = !1;

        function Te() {
            var t = ae.selectAll(".year").filter(function(t, n) {
                return n === Me
            }).datum();
            he.text("Headlines from ".concat(t.key)), ue.selectAll("li").remove();
            var n = t.values;
            n.sort(function(t, n) {
                return d3.descending(t.count, n.count)
            });
            var e = n.map(function(t) {
                    return Un({
                        month: Zn[+t.month - 1]
                    }, function(t) {
                        var n = oe.find(function(n) {
                            return n.month === t.month && n.year === t.year
                        });
                        if (!n) return "N/A";
                        var e = n.headline,
                            i = n.common,
                            o = n.demonym,
                            r = n.city,
                            a = n.web_url,
                            s = Gn({
                                text: e,
                                chars: ge,
                                clean: !0,
                                ellipses: !0
                            }),
                            c = Kn(i.split(":")).concat(Kn(o.split(":")), Kn(r.split(":"))).find(function(n) {
                                return n.includes(t.country[0])
                            });
                        if (!c) return "N/A";
                        var h = c.split("(")[1].replace(")", "").trim(),
                            u = e.toLowerCase().indexOf(h),
                            l = u + h.length,
                            f = s.substring(0, u),
                            d = s.substring(u, l),
                            p = s.substring(l, s.length);
                        return {
                            headline: "".concat(f, "<strong>").concat(d, "</strong>").concat(p),
                            web_url: a
                        }
                    }(t))
                }).filter(function(t) {
                    return t.headline
                }),
                i = ue.selectAll("li").data(e).enter().append("li");
            i.append("span.month").text(function(t) {
                return t.month
            }), i.append("span.headline").html(function(t) {
                return t.headline
            }), ce.classed("is-visible", !0)
        }

        function Se() {
            ae.selectAll(".year").classed("is-focus", function(t, n) {
                return n === Me
            }), Te()
        }

        function je(t) {
            var n = t.data;
            d3.select(this).parent().parent().parent().select(".annotation-connector").st("opacity", 1), ae.select('[data-id="'.concat(n.year, "-").concat(n.month, '"]')).classed("is-focus", !0)
        }

        function Ne(t) {
            var n = t.data;
            d3.select(this).parent().parent().parent().select(".annotation-connector").st("opacity", 0), ae.select('[data-id="'.concat(n.year, "-").concat(n.month, '"]')).classed("is-focus", !1)
        }

        function Oe(t) {
            var n = this.getBoundingClientRect(),
                e = n.top,
                i = n.left + n.width / 2,
                o = e - n.height,
                r = ee.find(function(n) {
                    return n.commonLower === t
                });
            pe.select("p").text(r ? r.common : t), pe.st({
                top: o,
                left: i
            }).transition().duration(0).st("opacity", 1).transition().delay(1e3).duration(250).st("opacity", 0)
        }

        function Ae() {
            var t = ce.classed("is-show");
            ce.classed("is-show", !t), le.text(t ? "Show headlines" : "Hide headlines")
        }

        function Ee() {
            var t = re.select(".year");
            if (t.size()) {
                //re node ширина
                //t.node()
                var n = re.node().offsetWidth,
                    e = t.node().offsetWidth,
                    i = (n - e) / 2,
                    o = (ke = n < 70 * ne) ? n - 5 * ne : n - i;
                se.st("width", o).st("right", ke ? 5 * ne : i), ye = (_e = e / 22) / Qn, re.selectAll("li").st("height", ye), re.selectAll(".flag").st({
                    width: _e,
                    height: ye
                }), re.selectAll(".title").st("line-height", ye);
                var r = Math.min(i - 1.25 * _e, 480),
                    a = Math.max(0, i - r - 5 * ne),
                    s = window.innerHeight - (ke ? 3 : 5) * ne;
                //innerHeight - сколько процентов занимает окно
                //-3*16
                //margin if ke true - 0, else -s (s is  s = window.innerHeight - (ke ? 3 : 5) * ne;
                ce.st("width", ke ? "100%" : r).st("left", ke ? 0 : a).st("height", ke ? .8 * window.innerHeight : s), we = s / 2, ae.st("margin-top", "5%").st(), fe.st("margin-top", ke ? 0 : -s / 2), ve = Math.floor(Math.min(ke ? 1.6 * i : .7 * i, te)),
                    function() {
                        se.select(".g-annotation").remove();
                        var t = se.append("g.g-annotation"),
                            n = Rn(qn, {
                                className: "custom",
                                connector: {
                                    type: "curve",
                                    end: "arrow"
                                },
                                note: {
                                    lineType: "horizontal",
                                    align: "right"
                                }
                            }),
                            e = Jn.a.map(function(t) {
                                return {
                                    note: {
                                        title: t.year,
                                        label: t.text,
                                        padding: 0,
                                        wrap: ve,
                                        bgPadding: {
                                            top: 8,
                                            left: 8,
                                            right: 8,
                                            bottom: 8
                                        }
                                    },
                                    data: {
                                        year: t.year,
                                        yearOff: +t.year - 1900,
                                        month: t.month
                                    },
                                    dx: (12 - +t.month) * _e + 1.25 * _e,
                                    dy: +t.pos * ye * 2,
                                    connector: {
                                        points: 1
                                    }
                                }
                            }),
                            i = Yn().type(n).accessors({
                                x: function(t) {
                                    return t.month * _e - _e / 2
                                },
                                y: function(t) {
                                    return t.yearOff * ye + ye / 2
                                }
                            }).annotations(e);
                        //on("mouseenter"
                        //on("mouseout"
                        t.call(i), t.selectAll(".annotation-note-bg").on("mouseenter", je).on("mouseout", Ne)
                    }(), Se()
            }
        }

        function Pe() {
            ge = Math.floor(.3 * window.innerHeight), be = window.innerHeight / 2
        }

        function Ce(t) {
            var n = d3.select(this);
            "1992" === t.year && n.append("span.month").text(function(t) {
                return Zn[+t.month - 1]
            });
            var e = n.selectAll(".country").data(function(t) {
                    return t.country
                }).enter().append("div.country").classed("is-uk", function(t) {
                    return "united kingdom" === t
                }),
                i = e.append("span.flag");
            i.html(function(t) {
                var n = (ee.find(function(n) {
                    return n.commonLower === t
                }) || {
                    cca2: "none"
                }).cca2;
                return '<img class="documentIcon" data-src="noun_Document_2127693.svg">'
            }), a.any() && i.on("touchstart", Oe), e.append("span.name").text(function(t) {
                var n = ee.find(function(n) {
                    return n.commonLower === t
                });
                return n ? n.common : t
            }), t.country.length > 1 && n.append("span.layer").text("+".concat(t.country.length - 1))
        }

        function Re() {
            me = !1;
            var t = de.getBoundingClientRect(),
                n = t.top,
                e = t.height,
                i = -1 * (n - (ke ? .25 * be : .5 * be)),
                o = ke ? e : e - 1.5 * we,
                r = Math.min(1, Math.max(0, i / o)),
                a = Math.floor(r * (xe - 1));
            a !== Me && (Me = a, Se(), le.classed("is-visible", !0))
        }

        function Le() {
            me || (me = !0, requestAnimationFrame(Re))
        }

        function We() {
            var t = d3.select(this),
                n = t.at("data-src");
            t.at("src", n)
        }

        function qe() {
            d3.loadData("headlines.csv", function(t, n) {
                t && console.log(t), oe = n[0], Se()
            })
        }

        function Be() {
            ! function() {
                ae.selectAll(".year").remove();
                var t = d3.nest().key(function(t) {
                        return t.year
                    }).entries(ie),
                    n = ae.selectAll(".year").data(t).enter().append("div.year");
                n.append("h3.title").text(function(t) {
                    return t.key
                });
                var e = n.append("ul").selectAll("li").data(function(t) {
                    return t.values
                }).enter().append("li").at("data-id", function(t) {
                    return "".concat(t.year, "-").concat(t.month)
                });
                xe = n.size(), e.each(Ce)
            }(), le.on("click", Ae), window.removeEventListener("scroll", Le), window.addEventListener("scroll", Le, !0), Re(), ae.selectAll("img").each(We), Se()
        }

        function Ie() {
            return new Promise(function(t) {
                d3.loadData("result--month.csv", function(n, e) {
                    n && console.log(n), ie = function(t) {
                        var n, e = t.map(function(t) {
                                return Un({}, t, {
                                    count: +t.count,
                                    country: t.country.split(":")
                                })
                            }),
                            i = Vn(d3.extent(e, function(t) {
                                return +t.year
                            }), 2),
                            o = i[0],
                            r = i[1],
                            a = d3.range(o, r + 1).map(function(t) {
                                return d3.range(Zn.length).map(function(n) {
                                    return {
                                        year: t,
                                        month: n + 1
                                    }
                                })
                            });
                        return (n = []).concat.apply(n, Kn(a)).map(function(t) {
                            var n = e.find(function(n) {
                                return +n.year === t.year && +n.month === t.month
                            });
                            return n && n.count < 5 && (n.country = ["N/A"]), n || {
                                year: t.year.toString(),
                                month: d3.format("02")(t.month),
                                country: ["N/A"],
                                count: 0
                            }
                        })
                    }(e[0].filter(function(t) {
                        return +t.year
                    })), Pe(), Be(), Ee(), t()
                })
            })
        }
    var De = {
                init: function() {
                    var t;
                    Xn.a.add(d3.selectAll(".sticky").nodes());
                    var n = ["countries.csv"].map(function(t) {
                        return "/assets/data/".concat(t)
                    });
                    (t = d3).loadData.apply(t, Kn(n).concat([function(t, n) {
                        t && console.log(t), ee = function(t) {
                            return t.map(function(t) {
                                return Un({}, t, {
                                    ccn3: +t.ccn3,
                                    lat: +t.latlng.split(",")[0].trim(),
                                    commonLower: t.common.toLowerCase(),
                                    lng: +t.latlng.split(",")[1].trim()
                                })
                            })
                        }(n[0]), Ie().then(qe)
                    }]))
                },
                resize: function() {
                    Pe(), Be(), Ee()
                }
            },
            He = d3.select("body"),
            ze = 0;

        function Ye() {
            var t = He.node().offsetWidth;
            ze !== t && (ze = t, De.resize())
        }
        He.classed("is-mobile", a.any()), window.addEventListener("resize", o()(Ye, 500)),
            function() {
            }(), De.init()
    },
    2: function(t, n, e) {
        (function(n) {
            var e = "Expected a function",
                i = NaN,
                o = "[object Symbol]",
                r = /^\s+|\s+$/g,
                a = /^[-+]0x[0-9a-f]+$/i,
                s = /^0b[01]+$/i,
                c = /^0o[0-7]+$/i,
                h = parseInt,
                u = "object" == typeof n && n && n.Object === Object && n,
                l = "object" == typeof self && self && self.Object === Object && self,
                f = u || l || Function("return this")(),
                d = Object.prototype.toString,
                p = Math.max,
                _ = Math.min,
                y = function() {
                    return f.Date.now()
                };

            function v(t) {
                var n = typeof t;
                return !!t && ("object" == n || "function" == n)
            }

            function x(t) {
                if ("number" == typeof t) return t;
                if (function(t) {
                        return "symbol" == typeof t || function(t) {
                            return !!t && "object" == typeof t
                        }(t) && d.call(t) == o
                    }(t)) return i;
                if (v(t)) {
                    var n = "function" == typeof t.valueOf ? t.valueOf() : t;
                    t = v(n) ? n + "" : n
                }
                if ("string" != typeof t) return 0 === t ? t : +t;
                t = t.replace(r, "");
                var e = s.test(t);
                return e || c.test(t) ? h(t.slice(2), e ? 2 : 8) : a.test(t) ? i : +t
            }
            t.exports = function(t, n, i) {
                var o, r, a, s, c, h, u = 0,
                    l = !1,
                    f = !1,
                    d = !0;
                if ("function" != typeof t) throw new TypeError(e);

                function g(n) {
                    var e = o,
                        i = r;
                    return o = r = void 0, u = n, s = t.apply(i, e)
                }

                function m(t) {
                    var e = t - h;
                    return void 0 === h || e >= n || e < 0 || f && t - u >= a
                }

                function b() {
                    var t = y();
                    if (m(t)) return w(t);
                    c = setTimeout(b, function(t) {
                        var e = n - (t - h);
                        return f ? _(e, a - (t - u)) : e
                    }(t))
                }

                function w(t) {
                    return c = void 0, d && o ? g(t) : (o = r = void 0, s)
                }

                function M() {
                    var t = y(),
                        e = m(t);
                    if (o = arguments, r = this, h = t, e) {
                        if (void 0 === c) return function(t) {
                            return u = t, c = setTimeout(b, n), l ? g(t) : s
                        }(h);
                        if (f) return c = setTimeout(b, n), g(h)
                    }
                    return void 0 === c && (c = setTimeout(b, n)), s
                }
                return n = x(n) || 0, v(i) && (l = !!i.leading, a = (f = "maxWait" in i) ? p(x(i.maxWait) || 0, n) : a, d = "trailing" in i ? !!i.trailing : d), M.cancel = function() {
                    void 0 !== c && clearTimeout(c), u = 0, o = h = r = c = void 0
                }, M.flush = function() {
                    return void 0 === c ? s : w(y())
                }, M
            }
        }).call(this, e(0))
    },
    3: function(t, n, e) {
        ! function(n, e) {
            "use strict";
            var i = function() {
                function t(t, n) {
                    for (var e = 0; e < n.length; e++) {
                        var i = n[e];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
                    }
                }
                return function(n, e, i) {
                    return e && t(n.prototype, e), i && t(n, i), n
                }
            }();
            var o = !1,
                r = void 0 !== n;
            r && n.getComputedStyle ? function() {
                var t = e.createElement("div");
                ["", "-webkit-", "-moz-", "-ms-"].some(function(n) {
                    try {
                        t.style.position = n + "sticky"
                    } catch (t) {}
                    return "" != t.style.position
                }) && (o = !0)
            }() : o = !0;
            var a = !1,
                s = "undefined" != typeof ShadowRoot,
                c = {
                    top: null,
                    left: null
                },
                h = [];

            function u(t, n) {
                for (var e in n) n.hasOwnProperty(e) && (t[e] = n[e])
            }

            function l(t) {
                return parseFloat(t) || 0
            }

            function f(t) {
                for (var n = 0; t;) n += t.offsetTop, t = t.offsetParent;
                return n
            }
            var d = function() {
                    function t(n) {
                        if (function(t, n) {
                                if (!(t instanceof n)) throw new TypeError("Cannot call a class as a function")
                            }(this, t), !(n instanceof HTMLElement)) throw new Error("First argument must be HTMLElement");
                        if (h.some(function(t) {
                                return t._node === n
                            })) throw new Error("Stickyfill is already applied to this node");
                        this._node = n, this._stickyMode = null, this._active = !1, h.push(this), this.refresh()
                    }
                    return i(t, [{
                        key: "refresh",
                        value: function() {
                            if (!o && !this._removed) {
                                this._active && this._deactivate();
                                var t = this._node,
                                    i = getComputedStyle(t),
                                    r = {
                                        position: i.position,
                                        top: i.top,
                                        display: i.display,
                                        marginTop: i.marginTop,
                                        marginBottom: i.marginBottom,
                                        marginLeft: i.marginLeft,
                                        marginRight: i.marginRight,
                                        cssFloat: i.cssFloat
                                    };
                                if (!isNaN(parseFloat(r.top)) && "table-cell" != r.display && "none" != r.display) {
                                    this._active = !0;
                                    var a = t.style.position;
                                    "sticky" != i.position && "-webkit-sticky" != i.position || (t.style.position = "static");
                                    var c = t.parentNode,
                                        h = s && c instanceof ShadowRoot ? c.host : c,
                                        d = t.getBoundingClientRect(),
                                        p = h.getBoundingClientRect(),
                                        _ = getComputedStyle(h);
                                    this._parent = {
                                        node: h,
                                        styles: {
                                            position: h.style.position
                                        },
                                        offsetHeight: h.offsetHeight
                                    }, this._offsetToWindow = {
                                        left: d.left,
                                        right: e.documentElement.clientWidth - d.right
                                    }, this._offsetToParent = {
                                        top: d.top - p.top - l(_.borderTopWidth),
                                        left: d.left - p.left - l(_.borderLeftWidth),
                                        right: -d.right + p.right - l(_.borderRightWidth)
                                    }, this._styles = {
                                        position: a,
                                        top: t.style.top,
                                        bottom: t.style.bottom,
                                        left: t.style.left,
                                        right: t.style.right,
                                        width: t.style.width,
                                        marginTop: t.style.marginTop,
                                        marginLeft: t.style.marginLeft,
                                        marginRight: t.style.marginRight
                                    };
                                    var y = l(r.top);
                                    this._limits = {
                                        start: d.top + n.pageYOffset - y,
                                        end: p.top + n.pageYOffset + h.offsetHeight - l(_.borderBottomWidth) - t.offsetHeight - y - l(r.marginBottom)
                                    };
                                    var v = _.position;
                                    "absolute" != v && "relative" != v && (h.style.position = "relative"), this._recalcPosition();
                                    var x = this._clone = {};
                                    x.node = e.createElement("div"), u(x.node.style, {
                                        width: d.right - d.left + "px",
                                        height: d.bottom - d.top + "px",
                                        marginTop: r.marginTop,
                                        marginBottom: r.marginBottom,
                                        marginLeft: r.marginLeft,
                                        marginRight: r.marginRight,
                                        cssFloat: r.cssFloat,
                                        padding: 0,
                                        border: 0,
                                        borderSpacing: 0,
                                        fontSize: "1em",
                                        position: "static"
                                    }), c.insertBefore(x.node, t), x.docOffsetTop = f(x.node)
                                }
                            }
                        }
                    }, {
                        key: "_recalcPosition",
                        value: function() {
                            if (this._active && !this._removed) {
                                var t = c.top <= this._limits.start ? "start" : c.top >= this._limits.end ? "end" : "middle";
                                if (this._stickyMode != t) {
                                    switch (t) {
                                        case "start":
                                            u(this._node.style, {
                                                position: "absolute",
                                                left: this._offsetToParent.left + "px",
                                                right: this._offsetToParent.right + "px",
                                                top: this._offsetToParent.top + "px",
                                                bottom: "auto",
                                                width: "auto",
                                                marginLeft: 0,
                                                marginRight: 0,
                                                marginTop: 0
                                            });
                                            break;
                                        case "middle":
                                            u(this._node.style, {
                                                position: "fixed",
                                                left: this._offsetToWindow.left + "px",
                                                right: this._offsetToWindow.right + "px",
                                                top: this._styles.top,
                                                bottom: "auto",
                                                width: "auto",
                                                marginLeft: 0,
                                                marginRight: 0,
                                                marginTop: 0
                                            });
                                            break;
                                        case "end":
                                            u(this._node.style, {
                                                position: "absolute",
                                                left: this._offsetToParent.left + "px",
                                                right: this._offsetToParent.right + "px",
                                                top: "auto",
                                                bottom: 0,
                                                width: "auto",
                                                marginLeft: 0,
                                                marginRight: 0
                                            })
                                    }
                                    this._stickyMode = t
                                }
                            }
                        }
                    }, {
                        key: "_fastCheck",
                        value: function() {
                            this._active && !this._removed && (Math.abs(f(this._clone.node) - this._clone.docOffsetTop) > 1 || Math.abs(this._parent.node.offsetHeight - this._parent.offsetHeight) > 1) && this.refresh()
                        }
                    }, {
                        key: "_deactivate",
                        value: function() {
                            var t = this;
                            this._active && !this._removed && (this._clone.node.parentNode.removeChild(this._clone.node), delete this._clone, u(this._node.style, this._styles), delete this._styles, h.some(function(n) {
                                return n !== t && n._parent && n._parent.node === t._parent.node
                            }) || u(this._parent.node.style, this._parent.styles), delete this._parent, this._stickyMode = null, this._active = !1, delete this._offsetToWindow, delete this._offsetToParent, delete this._limits)
                        }
                    }, {
                        key: "remove",
                        value: function() {
                            var t = this;
                            this._deactivate(), h.some(function(n, e) {
                                if (n._node === t._node) return h.splice(e, 1), !0
                            }), this._removed = !0
                        }
                    }]), t
                }(),
                p = {
                    stickies: h,
                    Sticky: d,
                    forceSticky: function() {
                        o = !1, _(), this.refreshAll()
                    },
                    addOne: function(t) {
                        if (!(t instanceof HTMLElement)) {
                            if (!t.length || !t[0]) return;
                            t = t[0]
                        }
                        for (var n = 0; n < h.length; n++)
                            if (h[n]._node === t) return h[n];
                        return new d(t)
                    },
                    add: function(t) {
                        if (t instanceof HTMLElement && (t = [t]), t.length) {
                            for (var n = [], e = function(e) {
                                    var i = t[e];
                                    return i instanceof HTMLElement ? h.some(function(t) {
                                        if (t._node === i) return n.push(t), !0
                                    }) ? "continue" : void n.push(new d(i)) : (n.push(void 0), "continue")
                                }, i = 0; i < t.length; i++) e(i);
                            return n
                        }
                    },
                    refreshAll: function() {
                        h.forEach(function(t) {
                            return t.refresh()
                        })
                    },
                    removeOne: function(t) {
                        if (!(t instanceof HTMLElement)) {
                            if (!t.length || !t[0]) return;
                            t = t[0]
                        }
                        h.some(function(n) {
                            if (n._node === t) return n.remove(), !0
                        })
                    },
                    remove: function(t) {
                        if (t instanceof HTMLElement && (t = [t]), t.length)
                            for (var n = function(n) {
                                    var e = t[n];
                                    h.some(function(t) {
                                        if (t._node === e) return t.remove(), !0
                                    })
                                }, e = 0; e < t.length; e++) n(e)
                    },
                    removeAll: function() {
                        for (; h.length;) h[0].remove()
                    }
                };

            function _() {
                if (!a) {
                    a = !0, r(), n.addEventListener("scroll", r), n.addEventListener("resize", p.refreshAll), n.addEventListener("orientationchange", p.refreshAll);
                    var t = void 0,
                        i = void 0,
                        o = void 0;
                    "hidden" in e ? (i = "hidden", o = "visibilitychange") : "webkitHidden" in e && (i = "webkitHidden", o = "webkitvisibilitychange"), o ? (e[i] || s(), e.addEventListener(o, function() {
                        e[i] ? clearInterval(t) : s()
                    })) : s()
                }

                function r() {
                    n.pageXOffset != c.left ? (c.top = n.pageYOffset, c.left = n.pageXOffset, p.refreshAll()) : n.pageYOffset != c.top && (c.top = n.pageYOffset, c.left = n.pageXOffset, h.forEach(function(t) {
                        return t._recalcPosition()
                    }))
                }

                function s() {
                    t = setInterval(function() {
                        h.forEach(function(t) {
                            return t._fastCheck()
                        })
                    }, 500)
                }
            }
            o || _(), t.exports ? t.exports = p : r && (n.Stickyfill = p)
        }(window, document)
    },
    4: function(t) {
        t.exports = {
            a: [{
                year: "1904",
                month: "01",
                text: "The Russo-Japanese War began February 8, 1904 and lasted until September 5, 1905. President Theodore Roosevelt mediated the Treaty of Portsmouth, which ended the conflict.",
                pos: "1"
            }, {
                year: "1914",
                month: "08",
                text: "Germany declared war on the Russian Empire August 1, 1914. The conflict caused the New York Stock Exchange to close since nearly all the European stock exchanges were already closed. At these early stages in the Great War, the United States declared neutrality.",
                pos: "1"
            }, {
                year: "1926",
                month: "08",
                text: "Conflict broke out at the Church of Our Lady of Guadalupe in Mexico on August 3 when 400 Catholics exchanged gunfire with federal troops. Later that month, federal firing squad executed 20 people because of the riots.",
                pos: "1"
            }, {
                year: "1939",
                month: "09",
                text: "September 1, 1939 is recognized as the start of the second World War, beginning with the German invasion of Poland. Based on the headlines, World War I seemed to be much more focused on Germany while more focus was placed on Great Britain and Russia during World War II.",
                pos: "-1"
            }, {
                year: "1947",
                month: "03",
                text: "Two years after the end of World War II, the Cold War consumed American attention, with Russia as the most-talked about country until the Vietnam War took precedence.",
                pos: "1"
            }, {
                year: "1965",
                month: "01",
                text: "After the assassination of President Kennedy in 1963, Lyndon B. Johnson assumed the presidency and set his focus on the Vietnam War. Marked by fervent opposition stateside, Vietnam was the singular focus in New York Times headlines for almost a decade.",
                pos: "-1"
            }, {
                year: "1976",
                month: "09",
                text: "Another Geneva Conference took place in Switzerland at the end of 1976 during the Rhodesian Bush War with the goal of agreeing on a new constitution for Rhodesia and therefore ending conflict in the region. It was indefinitely adjourned in December and never reconvened.",
                pos: "-1"
            }, {
                year: "1987",
                month: "06",
                text: "South Korea appears suddenly in June 1987, the same time as the â€œJune Struggle,â€ during which mass protests forced the ruling government to integrate democratic reforms. This led to the establishment of the Sixth Republic, South Koreaâ€™s current government today.",
                pos: "1"
            }, {
                year: "2003",
                month: "01",
                text: "By the start of 2003, attention shifted to Iraq. The 2003 invasion of Iraq occurred March 20, initiating the first stage of the Iraq War. The country overshadowed headlines for almost five years straight. The war ended a few years later on December 18, 2011.",
                pos: "-1"
            }, {
                year: "2010",
                month: "01",
                text: "Haiti was hit with disaster in January 2010 when a magnitude 7.0 earthquake ravaged the Caribbean nation. In the earthquakeâ€™s aftermath, the country was at the forefront of American headlines, especially in the wake of a series of powerful aftershocks throughout the month.",
                pos: "-1"
            }, {
                year: "2017",
                month: "01",
                text: "Since the Cold War concluded in 1991, Russia dissipated from American headlines, until the most-recent presidential cycle, when collusion became a notable focus in the news.",
                pos: "-1"
            }]
        }
    }
});