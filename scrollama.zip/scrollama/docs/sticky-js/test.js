! function(t) {
    var e = {};

    function r(n) {
        if (e[n]) return e[n].exports;
        var a = e[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return t[n].call(a.exports, a, a.exports, r), a.l = !0, a.exports
    }
    r.m = t, r.c = e, r.d = function(t, e, n) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }, r.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, r.t = function(t, e) {
        if (1 & e && (t = r(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var a in t) r.d(n, a, function(e) {
                return t[e]
            }.bind(null, a));
        return n
    }, r.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return r.d(e, "a", e), e
    }, r.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, r.p = "", r(r.s = 4)
}([function(t, e, r) {
    "use strict";
    t.exports = function(t) {
        return null !== t && "object" == typeof t
    }
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n = Object.assign || function(t) {
            for (var e = 1; e < arguments.length; e++) {
                var r = arguments[e];
                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
            }
            return t
        },
        a = {
            all: [0, 100],
            light: [0, 4],
            medium: [4, 7],
            heavy: [7, 100]
        };
    e.default = {
        init: function(t) {
            var e = t.cityData,
                r = t.breweryData,
                o = t.dist,
                i = void 0 === o ? 20 : o,
                s = t.abv,
                c = void 0 === s ? "all" : s,
                u = t.nearby,
                l = void 0 === u ? 5 : u,
                f = t.max,
                d = void 0 === f ? 1e3 : f,
                p = r.map(function(t) {
                    return n({}, t, {
                        cities: function(t, e, r) {
                            var n = t.map(function(t) {
                                return t
                            });
                            return "number" == typeof r && n.unshift({
                                index: r,
                                dist: 0
                            }), n.filter(function(t) {
                                return t.dist <= e
                            }).map(function(t) {
                                return t.index
                            })
                        }(t.cities, i, t.cityIndex).slice(0, 1),
                        beers: function(t, e) {
                            var r = t.filter(function(t) {
                                return t.abv >= a[e][0] && t.abv < a[e][1]
                            });
                            return r.length ? {
                                score: d3.sum(r, function(t) {
                                    return t.score * t.reviews
                                }),
                                reviews: d3.sum(r, function(t) {
                                    return t.reviews
                                })
                            } : null
                        }(t.beers, c)
                    })
                }).filter(function(t) {
                    return t.beers && t.cities.length
                }),
                h = [];
            return p.forEach(function(t) {
                    t.cities.forEach(function(t) {
                        return h[t] = !0
                    })
                }),
                function(t) {
                    var e = t.cityReduced,
                        r = t.breweryReduced,
                        a = t.nearby;
                    return e.map(function(t) {
                        var e = r.filter(function(e) {
                                return e.cities.includes(t.index)
                            }),
                            a = e.length,
                            o = function(t) {
                                return d3.sum(t, function(t) {
                                    return t.beers.score
                                }) / d3.sum(t, function(t) {
                                    return t.beers.reviews
                                })
                            }(e),
                            i = e.map(function(t) {
                                return {
                                    lat: t.lat,
                                    lng: t.lng
                                }
                            }),
                            s = function(t, e) {
                                return e.map(function(t) {
                                    return {
                                        score: t.beers.score / t.beers.reviews,
                                        name: t.name
                                    }
                                }).sort(function(t, e) {
                                    return d3.descending(t.score, e.score)
                                }).slice(0, 5).map(function(t) {
                                    return t.name
                                })
                            }(t.city, e);
                        return n({}, t, {
                            score: o,
                            count: a,
                            breweryCoords: i,
                            breweryNames: s
                        })
                    }).filter(function(t) {
                        return t.count >= a
                    })
                }({
                    cityReduced: e.filter(function(t) {
                        return h[t.index]
                    }),
                    breweryReduced: p,
                    nearby: l
                }).slice(0, d)
        },
        weight: function(t) {
            var e = t.data,
                r = t.balance,
                a = d3.extent(e, function(t) {
                    return t.score
                }),
                o = d3.scaleLinear().domain(a).range([0, r.quality]),
                i = d3.scaleLinear().domain(d3.extent(e, function(t) {
                    return t.count
                })).range([0, r.quantity]),
                s = d3.scaleQuantize().domain(d3.extent(e, function(t) {
                    return t.score
                })).range(["C-", "C", "C+", "B-", "B", "B+", "A-", "A", "A+"]);
            return e.map(function(t) {
                return n({}, t, {
                    grade: s(t.score),
                    weighted: o(t.score) + i(t.count)
                })
            }).sort(function(t, e) {
                return d3.descending(t.weighted, e.weighted) || d3.descending(t.score, e.score) || d3.descending(t.count, e.count)
            }).map(function(t, e) {
                return n({}, t, {
                    rank: e
                })
            })
        }
    }
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n = window.location.hostname.indexOf("localhost") > -1,
        a = {};
    e.default = {
        send: function(t) {
            var e = t.category,
                r = t.action,
                o = t.once;
            (function(t) {
                var e = t.action;
                if (t.once) {
                    var r = "" + t.category.toString().replace(/\W+/g, "") + e.toString().replace(/\W+/g, "");
                    return !a[r] && (a[r] = !0, !0)
                }
                return !0
            })({
                category: e,
                action: r,
                once: o
            }) && (n ? console.log({
                category: e,
                action: r,
                once: o
            }) : window.ga && ga("send", {
                hitType: "event",
                eventCategory: e.toString(),
                eventAction: r.toString()
            }))
        }
    }
}, function(t, e, r) {
    "use strict";
    r.r(e);
    var n = function(t) {
            return t
        },
        a = function(t) {
            if (null == t) return n;
            var e, r, a = t.scale[0],
                o = t.scale[1],
                i = t.translate[0],
                s = t.translate[1];
            return function(t, n) {
                n || (e = r = 0);
                var c = 2,
                    u = t.length,
                    l = new Array(u);
                for (l[0] = (e += t[0]) * a + i, l[1] = (r += t[1]) * o + s; c < u;) l[c] = t[c], ++c;
                return l
            }
        },
        o = function(t) {
            var e, r = a(t.transform),
                n = 1 / 0,
                o = n,
                i = -n,
                s = -n;

            function c(t) {
                (t = r(t))[0] < n && (n = t[0]), t[0] > i && (i = t[0]), t[1] < o && (o = t[1]), t[1] > s && (s = t[1])
            }

            function u(t) {
                switch (t.type) {
                    case "GeometryCollection":
                        t.geometries.forEach(u);
                        break;
                    case "Point":
                        c(t.coordinates);
                        break;
                    case "MultiPoint":
                        t.coordinates.forEach(c)
                }
            }
            for (e in t.arcs.forEach(function(t) {
                    for (var e, a = -1, c = t.length; ++a < c;)(e = r(t[a], a))[0] < n && (n = e[0]), e[0] > i && (i = e[0]), e[1] < o && (o = e[1]), e[1] > s && (s = e[1])
                }), t.objects) u(t.objects[e]);
            return [n, o, i, s]
        },
        i = function(t, e) {
            for (var r, n = t.length, a = n - e; a < --n;) r = t[a], t[a++] = t[n], t[n] = r
        },
        s = function(t, e) {
            return "GeometryCollection" === e.type ? {
                type: "FeatureCollection",
                features: e.geometries.map(function(e) {
                    return c(t, e)
                })
            } : c(t, e)
        };

    function c(t, e) {
        var r = e.id,
            n = e.bbox,
            a = null == e.properties ? {} : e.properties,
            o = u(t, e);
        return null == r && null == n ? {
            type: "Feature",
            properties: a,
            geometry: o
        } : null == n ? {
            type: "Feature",
            id: r,
            properties: a,
            geometry: o
        } : {
            type: "Feature",
            id: r,
            bbox: n,
            properties: a,
            geometry: o
        }
    }

    function u(t, e) {
        var r = a(t.transform),
            n = t.arcs;

        function o(t, e) {
            e.length && e.pop();
            for (var a = n[t < 0 ? ~t : t], o = 0, s = a.length; o < s; ++o) e.push(r(a[o], o));
            t < 0 && i(e, s)
        }

        function s(t) {
            return r(t)
        }

        function c(t) {
            for (var e = [], r = 0, n = t.length; r < n; ++r) o(t[r], e);
            return e.length < 2 && e.push(e[0]), e
        }

        function u(t) {
            for (var e = c(t); e.length < 4;) e.push(e[0]);
            return e
        }

        function l(t) {
            return t.map(u)
        }
        return function t(e) {
            var r, n = e.type;
            switch (n) {
                case "GeometryCollection":
                    return {
                        type: n,
                        geometries: e.geometries.map(t)
                    };
                case "Point":
                    r = s(e.coordinates);
                    break;
                case "MultiPoint":
                    r = e.coordinates.map(s);
                    break;
                case "LineString":
                    r = c(e.arcs);
                    break;
                case "MultiLineString":
                    r = e.arcs.map(c);
                    break;
                case "Polygon":
                    r = l(e.arcs);
                    break;
                case "MultiPolygon":
                    r = e.arcs.map(l);
                    break;
                default:
                    return null
            }
            return {
                type: n,
                coordinates: r
            }
        }(e)
    }
    var l = function(t, e) {
            var r = {},
                n = {},
                a = {},
                o = [],
                i = -1;

            function s(t, e) {
                for (var n in t) {
                    var a = t[n];
                    delete e[a.start], delete a.start, delete a.end, a.forEach(function(t) {
                        r[t < 0 ? ~t : t] = 1
                    }), o.push(a)
                }
            }
            return e.forEach(function(r, n) {
                var a, o = t.arcs[r < 0 ? ~r : r];
                o.length < 3 && !o[1][0] && !o[1][1] && (a = e[++i], e[i] = r, e[n] = a)
            }), e.forEach(function(e) {
                var r, o, i = function(e) {
                        var r, n = t.arcs[e < 0 ? ~e : e],
                            a = n[0];
                        return t.transform ? (r = [0, 0], n.forEach(function(t) {
                            r[0] += t[0], r[1] += t[1]
                        })) : r = n[n.length - 1], e < 0 ? [r, a] : [a, r]
                    }(e),
                    s = i[0],
                    c = i[1];
                if (r = a[s])
                    if (delete a[r.end], r.push(e), r.end = c, o = n[c]) {
                        delete n[o.start];
                        var u = o === r ? r : r.concat(o);
                        n[u.start = r.start] = a[u.end = o.end] = u
                    } else n[r.start] = a[r.end] = r;
                else if (r = n[c])
                    if (delete n[r.start], r.unshift(e), r.start = s, o = a[s]) {
                        delete a[o.end];
                        var l = o === r ? r : o.concat(r);
                        n[l.start = o.start] = a[l.end = r.end] = l
                    } else n[r.start] = a[r.end] = r;
                else n[(r = [e]).start = s] = a[r.end = c] = r
            }), s(a, n), s(n, a), e.forEach(function(t) {
                r[t < 0 ? ~t : t] || o.push([t])
            }), o
        },
        f = function(t) {
            return u(t, d.apply(this, arguments))
        };

    function d(t, e, r) {
        var n, a, o;
        if (arguments.length > 1) n = function(t, e, r) {
            var n, a = [],
                o = [];

            function i(t) {
                var e = t < 0 ? ~t : t;
                (o[e] || (o[e] = [])).push({
                    i: t,
                    g: n
                })
            }

            function s(t) {
                t.forEach(i)
            }

            function c(t) {
                t.forEach(s)
            }
            return function t(e) {
                switch (n = e, e.type) {
                    case "GeometryCollection":
                        e.geometries.forEach(t);
                        break;
                    case "LineString":
                        s(e.arcs);
                        break;
                    case "MultiLineString":
                    case "Polygon":
                        c(e.arcs);
                        break;
                    case "MultiPolygon":
                        e.arcs.forEach(c)
                }
            }(e), o.forEach(null == r ? function(t) {
                a.push(t[0].i)
            } : function(t) {
                r(t[0].g, t[t.length - 1].g) && a.push(t[0].i)
            }), a
        }(0, e, r);
        else
            for (a = 0, n = new Array(o = t.arcs.length); a < o; ++a) n[a] = a;
        return {
            type: "MultiLineString",
            arcs: l(t, n)
        }
    }
    var p = function(t) {
        return u(t, h.apply(this, arguments))
    };

    function h(t, e) {
        var r = {},
            n = [],
            a = [];

        function o(t) {
            t.forEach(function(e) {
                e.forEach(function(e) {
                    (r[e = e < 0 ? ~e : e] || (r[e] = [])).push(t)
                })
            }), n.push(t)
        }

        function i(e) {
            return function(t) {
                for (var e, r = -1, n = t.length, a = t[n - 1], o = 0; ++r < n;) e = a, a = t[r], o += e[0] * a[1] - e[1] * a[0];
                return Math.abs(o)
            }(u(t, {
                type: "Polygon",
                arcs: [e]
            }).coordinates[0])
        }
        return e.forEach(function t(e) {
            switch (e.type) {
                case "GeometryCollection":
                    e.geometries.forEach(t);
                    break;
                case "Polygon":
                    o(e.arcs);
                    break;
                case "MultiPolygon":
                    e.arcs.forEach(o)
            }
        }), n.forEach(function(t) {
            if (!t._) {
                var e = [],
                    n = [t];
                for (t._ = 1, a.push(e); t = n.pop();) e.push(t), t.forEach(function(t) {
                    t.forEach(function(t) {
                        r[t < 0 ? ~t : t].forEach(function(t) {
                            t._ || (t._ = 1, n.push(t))
                        })
                    })
                })
            }
        }), n.forEach(function(t) {
            delete t._
        }), {
            type: "MultiPolygon",
            arcs: a.map(function(e) {
                var n, a = [];
                if (e.forEach(function(t) {
                        t.forEach(function(t) {
                            t.forEach(function(t) {
                                r[t < 0 ? ~t : t].length < 2 && a.push(t)
                            })
                        })
                    }), (n = (a = l(t, a)).length) > 1)
                    for (var o, s, c = 1, u = i(a[0]); c < n; ++c)(o = i(a[c])) > u && (s = a[0], a[0] = a[c], a[c] = s, u = o);
                return a
            })
        }
    }
    var m = function(t, e) {
            for (var r = 0, n = t.length; r < n;) {
                var a = r + n >>> 1;
                t[a] < e ? r = a + 1 : n = a
            }
            return r
        },
        y = function(t) {
            var e = {},
                r = t.map(function() {
                    return []
                });

            function n(t, r) {
                t.forEach(function(t) {
                    t < 0 && (t = ~t);
                    var n = e[t];
                    n ? n.push(r) : e[t] = [r]
                })
            }

            function a(t, e) {
                t.forEach(function(t) {
                    n(t, e)
                })
            }
            var o = {
                LineString: n,
                MultiLineString: a,
                Polygon: a,
                MultiPolygon: function(t, e) {
                    t.forEach(function(t) {
                        a(t, e)
                    })
                }
            };
            for (var i in t.forEach(function t(e, r) {
                    "GeometryCollection" === e.type ? e.geometries.forEach(function(e) {
                        t(e, r)
                    }) : e.type in o && o[e.type](e.arcs, r)
                }), e)
                for (var s = e[i], c = s.length, u = 0; u < c; ++u)
                    for (var l = u + 1; l < c; ++l) {
                        var f, d = s[u],
                            p = s[l];
                        (f = r[d])[i = m(f, p)] !== p && f.splice(i, 0, p), (f = r[p])[i = m(f, d)] !== d && f.splice(i, 0, d)
                    }
            return r
        },
        g = function(t) {
            if (null == t) return n;
            var e, r, a = t.scale[0],
                o = t.scale[1],
                i = t.translate[0],
                s = t.translate[1];
            return function(t, n) {
                n || (e = r = 0);
                var c = 2,
                    u = t.length,
                    l = new Array(u),
                    f = Math.round((t[0] - i) / a),
                    d = Math.round((t[1] - s) / o);
                for (l[0] = f - e, e = f, l[1] = d - r, r = d; c < u;) l[c] = t[c], ++c;
                return l
            }
        },
        v = function(t, e) {
            if (t.transform) throw new Error("already quantized");
            if (e && e.scale) c = t.bbox;
            else {
                if (!((r = Math.floor(e)) >= 2)) throw new Error("n must be в‰Ґ2");
                var r, n = (c = t.bbox || o(t))[0],
                    a = c[1],
                    i = c[2],
                    s = c[3];
                e = {
                    scale: [i - n ? (i - n) / (r - 1) : 1, s - a ? (s - a) / (r - 1) : 1],
                    translate: [n, a]
                }
            }
            var c, u, l = g(e),
                f = t.objects,
                d = {};

            function p(t) {
                return l(t)
            }

            function h(t) {
                var e;
                switch (t.type) {
                    case "GeometryCollection":
                        e = {
                            type: "GeometryCollection",
                            geometries: t.geometries.map(h)
                        };
                        break;
                    case "Point":
                        e = {
                            type: "Point",
                            coordinates: p(t.coordinates)
                        };
                        break;
                    case "MultiPoint":
                        e = {
                            type: "MultiPoint",
                            coordinates: t.coordinates.map(p)
                        };
                        break;
                    default:
                        return t
                }
                return null != t.id && (e.id = t.id), null != t.bbox && (e.bbox = t.bbox), null != t.properties && (e.properties = t.properties), e
            }
            for (u in f) d[u] = h(f[u]);
            return {
                type: "Topology",
                bbox: c,
                transform: e,
                objects: d,
                arcs: t.arcs.map(function(t) {
                    var e, r = 0,
                        n = 1,
                        a = t.length,
                        o = new Array(a);
                    for (o[0] = l(t[0], 0); ++r < a;)((e = l(t[r], r))[0] || e[1]) && (o[n++] = e);
                    return 1 === n && (o[n++] = [0, 0]), o.length = n, o
                })
            }
        },
        b = function(t, e, r, n, a, o) {
            3 === arguments.length && (n = o = Array, a = null);
            for (var i = new n(t = 1 << Math.max(4, Math.ceil(Math.log(t) / Math.LN2))), s = new o(t), c = t - 1, u = 0; u < t; ++u) i[u] = a;
            return {
                set: function(n, o) {
                    for (var u = e(n) & c, l = i[u], f = 0; l != a;) {
                        if (r(l, n)) return s[u] = o;
                        if (++f >= t) throw new Error("full hashmap");
                        l = i[u = u + 1 & c]
                    }
                    return i[u] = n, s[u] = o, o
                },
                maybeSet: function(n, o) {
                    for (var u = e(n) & c, l = i[u], f = 0; l != a;) {
                        if (r(l, n)) return s[u];
                        if (++f >= t) throw new Error("full hashmap");
                        l = i[u = u + 1 & c]
                    }
                    return i[u] = n, s[u] = o, o
                },
                get: function(n, o) {
                    for (var u = e(n) & c, l = i[u], f = 0; l != a;) {
                        if (r(l, n)) return s[u];
                        if (++f >= t) break;
                        l = i[u = u + 1 & c]
                    }
                    return o
                },
                keys: function() {
                    for (var t = [], e = 0, r = i.length; e < r; ++e) {
                        var n = i[e];
                        n != a && t.push(n)
                    }
                    return t
                }
            }
        },
        x = function(t, e) {
            return t[0] === e[0] && t[1] === e[1]
        },
        w = new ArrayBuffer(16),
        _ = new Float64Array(w),
        E = new Uint32Array(w),
        k = function(t) {
            _[0] = t[0], _[1] = t[1];
            var e = E[0] ^ E[1];
            return 2147483647 & (e << 5 ^ e >> 7 ^ E[2] ^ E[3])
        },
        S = function(t) {
            var e, r, n, a, o = t.coordinates,
                i = t.lines,
                s = t.rings,
                c = function() {
                    for (var t = b(1.4 * o.length, E, S, Int32Array, -1, Int32Array), e = new Int32Array(o.length), r = 0, n = o.length; r < n; ++r) e[r] = t.maybeSet(r, r);
                    return e
                }(),
                u = new Int32Array(o.length),
                l = new Int32Array(o.length),
                f = new Int32Array(o.length),
                d = new Int8Array(o.length),
                p = 0;
            for (e = 0, r = o.length; e < r; ++e) u[e] = l[e] = f[e] = -1;
            for (e = 0, r = i.length; e < r; ++e) {
                var h = i[e],
                    m = h[0],
                    y = h[1];
                for (n = c[m], a = c[++m], ++p, d[n] = 1; ++m <= y;) _(e, n, n = a, a = c[m]);
                ++p, d[a] = 1
            }
            for (e = 0, r = o.length; e < r; ++e) u[e] = -1;
            for (e = 0, r = s.length; e < r; ++e) {
                var g = s[e],
                    v = g[0] + 1,
                    w = g[1];
                for (_(e, c[w - 1], n = c[v - 1], a = c[v]); ++v <= w;) _(e, n, n = a, a = c[v])
            }

            function _(t, e, r, n) {
                if (u[r] !== t) {
                    u[r] = t;
                    var a = l[r];
                    if (a >= 0) {
                        var o = f[r];
                        a === e && o === n || a === n && o === e || (++p, d[r] = 1)
                    } else l[r] = e, f[r] = n
                }
            }

            function E(t) {
                return k(o[t])
            }

            function S(t, e) {
                return x(o[t], o[e])
            }
            u = l = f = null;
            var M, A = function(t, e, r, n, a) {
                3 === arguments.length && (n = Array, a = null);
                for (var o = new n(t = 1 << Math.max(4, Math.ceil(Math.log(t) / Math.LN2))), i = t - 1, s = 0; s < t; ++s) o[s] = a;
                return {
                    add: function(n) {
                        for (var s = e(n) & i, c = o[s], u = 0; c != a;) {
                            if (r(c, n)) return !0;
                            if (++u >= t) throw new Error("full hashset");
                            c = o[s = s + 1 & i]
                        }
                        return o[s] = n, !0
                    },
                    has: function(n) {
                        for (var s = e(n) & i, c = o[s], u = 0; c != a;) {
                            if (r(c, n)) return !0;
                            if (++u >= t) break;
                            c = o[s = s + 1 & i]
                        }
                        return !1
                    },
                    values: function() {
                        for (var t = [], e = 0, r = o.length; e < r; ++e) {
                            var n = o[e];
                            n != a && t.push(n)
                        }
                        return t
                    }
                }
            }(1.4 * p, k, x);
            for (e = 0, r = o.length; e < r; ++e) d[M = c[e]] && A.add(o[M]);
            return A
        };

    function M(t, e, r) {
        for (var n, a = e + (r-- - e >> 1); e < a; ++e, --r) n = t[e], t[e] = t[r], t[r] = n
    }

    function A(t) {
        var e, r = C(t.geometry);
        for (e in null != t.id && (r.id = t.id), null != t.bbox && (r.bbox = t.bbox), t.properties) {
            r.properties = t.properties;
            break
        }
        return r
    }

    function C(t) {
        if (null == t) return {
            type: null
        };
        var e = "GeometryCollection" === t.type ? {
            type: "GeometryCollection",
            geometries: t.geometries.map(C)
        } : "Point" === t.type || "MultiPoint" === t.type ? {
            type: t.type,
            coordinates: t.coordinates
        } : {
            type: t.type,
            arcs: t.coordinates
        };
        return null != t.bbox && (e.bbox = t.bbox), e
    }
    var P = function(t, e) {
        var r = function(t) {
                var e = 1 / 0,
                    r = 1 / 0,
                    n = -1 / 0,
                    a = -1 / 0;

                function o(t) {
                    null != t && i.hasOwnProperty(t.type) && i[t.type](t)
                }
                var i = {
                    GeometryCollection: function(t) {
                        t.geometries.forEach(o)
                    },
                    Point: function(t) {
                        s(t.coordinates)
                    },
                    MultiPoint: function(t) {
                        t.coordinates.forEach(s)
                    },
                    LineString: function(t) {
                        c(t.arcs)
                    },
                    MultiLineString: function(t) {
                        t.arcs.forEach(c)
                    },
                    Polygon: function(t) {
                        t.arcs.forEach(c)
                    },
                    MultiPolygon: function(t) {
                        t.arcs.forEach(u)
                    }
                };

                function s(t) {
                    var o = t[0],
                        i = t[1];
                    o < e && (e = o), o > n && (n = o), i < r && (r = i), i > a && (a = i)
                }

                function c(t) {
                    t.forEach(s)
                }

                function u(t) {
                    t.forEach(c)
                }
                for (var l in t) o(t[l]);
                return n >= e && a >= r ? [e, r, n, a] : void 0
            }(t = function(t) {
                var e, r, n = {};
                for (e in t) n[e] = null == (r = t[e]) ? {
                    type: null
                } : ("FeatureCollection" === r.type ? function(t) {
                    var e = {
                        type: "GeometryCollection",
                        geometries: t.features.map(A)
                    };
                    return null != t.bbox && (e.bbox = t.bbox), e
                } : "Feature" === r.type ? A : C)(r);
                return n
            }(t)),
            n = e > 0 && r && function(t, e, r) {
                var n = e[0],
                    a = e[1],
                    o = e[2],
                    i = e[3],
                    s = o - n ? (r - 1) / (o - n) : 1,
                    c = i - a ? (r - 1) / (i - a) : 1;

                function u(t) {
                    return [Math.round((t[0] - n) * s), Math.round((t[1] - a) * c)]
                }

                function l(t, e) {
                    for (var r, o, i, u, l, f = -1, d = 0, p = t.length, h = new Array(p); ++f < p;) r = t[f], u = Math.round((r[0] - n) * s), l = Math.round((r[1] - a) * c), u === o && l === i || (h[d++] = [o = u, i = l]);
                    for (h.length = d; d < e;) d = h.push([h[0][0], h[0][1]]);
                    return h
                }

                function f(t) {
                    return l(t, 2)
                }

                function d(t) {
                    return l(t, 4)
                }

                function p(t) {
                    return t.map(d)
                }

                function h(t) {
                    null != t && m.hasOwnProperty(t.type) && m[t.type](t)
                }
                var m = {
                    GeometryCollection: function(t) {
                        t.geometries.forEach(h)
                    },
                    Point: function(t) {
                        t.coordinates = u(t.coordinates)
                    },
                    MultiPoint: function(t) {
                        t.coordinates = t.coordinates.map(u)
                    },
                    LineString: function(t) {
                        t.arcs = f(t.arcs)
                    },
                    MultiLineString: function(t) {
                        t.arcs = t.arcs.map(f)
                    },
                    Polygon: function(t) {
                        t.arcs = p(t.arcs)
                    },
                    MultiPolygon: function(t) {
                        t.arcs = t.arcs.map(p)
                    }
                };
                for (var y in t) h(t[y]);
                return {
                    scale: [1 / s, 1 / c],
                    translate: [n, a]
                }
            }(t, r, e),
            a = function(t) {
                var e, r, n, a, o = t.coordinates,
                    i = t.lines,
                    s = t.rings,
                    c = i.length + s.length;
                for (delete t.lines, delete t.rings, n = 0, a = i.length; n < a; ++n)
                    for (e = i[n]; e = e.next;) ++c;
                for (n = 0, a = s.length; n < a; ++n)
                    for (r = s[n]; r = r.next;) ++c;
                var u = b(2 * c * 1.4, k, x),
                    l = t.arcs = [];
                for (n = 0, a = i.length; n < a; ++n) {
                    e = i[n];
                    do {
                        f(e)
                    } while (e = e.next)
                }
                for (n = 0, a = s.length; n < a; ++n)
                    if ((r = s[n]).next)
                        do {
                            f(r)
                        } while (r = r.next);
                    else d(r);
                function f(t) {
                    var e, r, n, a, i, s, c, f;
                    if (n = u.get(e = o[t[0]]))
                        for (c = 0, f = n.length; c < f; ++c)
                            if (p(a = n[c], t)) return t[0] = a[0], void(t[1] = a[1]);
                    if (i = u.get(r = o[t[1]]))
                        for (c = 0, f = i.length; c < f; ++c)
                            if (h(s = i[c], t)) return t[1] = s[0], void(t[0] = s[1]);
                    n ? n.push(t) : u.set(e, [t]), i ? i.push(t) : u.set(r, [t]), l.push(t)
                }

                function d(t) {
                    var e, r, n, a, i;
                    if (r = u.get(o[t[0]]))
                        for (a = 0, i = r.length; a < i; ++a) {
                            if (m(n = r[a], t)) return t[0] = n[0], void(t[1] = n[1]);
                            if (y(n, t)) return t[0] = n[1], void(t[1] = n[0])
                        }
                    if (r = u.get(e = o[t[0] + g(t)]))
                        for (a = 0, i = r.length; a < i; ++a) {
                            if (m(n = r[a], t)) return t[0] = n[0], void(t[1] = n[1]);
                            if (y(n, t)) return t[0] = n[1], void(t[1] = n[0])
                        }
                    r ? r.push(t) : u.set(e, [t]), l.push(t)
                }

                function p(t, e) {
                    var r = t[0],
                        n = e[0],
                        a = t[1];
                    if (r - a != n - e[1]) return !1;
                    for (; r <= a; ++r, ++n)
                        if (!x(o[r], o[n])) return !1;
                    return !0
                }

                function h(t, e) {
                    var r = t[0],
                        n = e[0],
                        a = t[1],
                        i = e[1];
                    if (r - a != n - i) return !1;
                    for (; r <= a; ++r, --i)
                        if (!x(o[r], o[i])) return !1;
                    return !0
                }

                function m(t, e) {
                    var r = t[0],
                        n = e[0],
                        a = t[1] - r;
                    if (a !== e[1] - n) return !1;
                    for (var i = g(t), s = g(e), c = 0; c < a; ++c)
                        if (!x(o[r + (c + i) % a], o[n + (c + s) % a])) return !1;
                    return !0
                }

                function y(t, e) {
                    var r = t[0],
                        n = e[0],
                        a = t[1],
                        i = e[1],
                        s = a - r;
                    if (s !== i - n) return !1;
                    for (var c = g(t), u = s - g(e), l = 0; l < s; ++l)
                        if (!x(o[r + (l + c) % s], o[i - (l + u) % s])) return !1;
                    return !0
                }

                function g(t) {
                    for (var e = t[0], r = t[1], n = e, a = n, i = o[n]; ++n < r;) {
                        var s = o[n];
                        (s[0] < i[0] || s[0] === i[0] && s[1] < i[1]) && (a = n, i = s)
                    }
                    return a - e
                }
                return t
            }(function(t) {
                var e, r, n, a, o, i, s, c = S(t),
                    u = t.coordinates,
                    l = t.lines,
                    f = t.rings;
                for (r = 0, n = l.length; r < n; ++r)
                    for (var d = l[r], p = d[0], h = d[1]; ++p < h;) c.has(u[p]) && (e = {
                        0: p,
                        1: d[1]
                    }, d[1] = p, d = d.next = e);
                for (r = 0, n = f.length; r < n; ++r)
                    for (var m = f[r], y = m[0], g = y, v = m[1], b = c.has(u[y]); ++g < v;) c.has(u[g]) && (b ? (e = {
                        0: g,
                        1: m[1]
                    }, m[1] = g, m = m.next = e) : (s = v - g, M(a = u, o = y, i = v), M(a, o, o + s), M(a, o + s, i), u[v] = u[y], b = !0, g = y));
                return t
            }(function(t) {
                var e = -1,
                    r = [],
                    n = [],
                    a = [];

                function o(t) {
                    t && i.hasOwnProperty(t.type) && i[t.type](t)
                }
                var i = {
                    GeometryCollection: function(t) {
                        t.geometries.forEach(o)
                    },
                    LineString: function(t) {
                        t.arcs = s(t.arcs)
                    },
                    MultiLineString: function(t) {
                        t.arcs = t.arcs.map(s)
                    },
                    Polygon: function(t) {
                        t.arcs = t.arcs.map(c)
                    },
                    MultiPolygon: function(t) {
                        t.arcs = t.arcs.map(u)
                    }
                };

                function s(t) {
                    for (var n = 0, o = t.length; n < o; ++n) a[++e] = t[n];
                    var i = {
                        0: e - o + 1,
                        1: e
                    };
                    return r.push(i), i
                }

                function c(t) {
                    for (var r = 0, o = t.length; r < o; ++r) a[++e] = t[r];
                    var i = {
                        0: e - o + 1,
                        1: e
                    };
                    return n.push(i), i
                }

                function u(t) {
                    return t.map(c)
                }
                for (var l in t) o(t[l]);
                return {
                    type: "Topology",
                    coordinates: a,
                    lines: r,
                    rings: n,
                    objects: t
                }
            }(t))),
            o = a.coordinates,
            i = b(1.4 * a.arcs.length, T, O);

        function s(t) {
            t && c.hasOwnProperty(t.type) && c[t.type](t)
        }
        t = a.objects, a.bbox = r, a.arcs = a.arcs.map(function(t, e) {
            return i.set(t, e), o.slice(t[0], t[1] + 1)
        }), delete a.coordinates, o = null;
        var c = {
            GeometryCollection: function(t) {
                t.geometries.forEach(s)
            },
            LineString: function(t) {
                t.arcs = u(t.arcs)
            },
            MultiLineString: function(t) {
                t.arcs = t.arcs.map(u)
            },
            Polygon: function(t) {
                t.arcs = t.arcs.map(u)
            },
            MultiPolygon: function(t) {
                t.arcs = t.arcs.map(l)
            }
        };

        function u(t) {
            var e = [];
            do {
                var r = i.get(t);
                e.push(t[0] < t[1] ? r : ~r)
            } while (t = t.next);
            return e
        }

        function l(t) {
            return t.map(u)
        }
        for (var f in t) s(t[f]);
        return n && (a.transform = n, a.arcs = function(t) {
            for (var e = -1, r = t.length; ++e < r;) {
                for (var n, a, o = t[e], i = 0, s = 1, c = o.length, u = o[0], l = u[0], f = u[1]; ++i < c;) n = (u = o[i])[0], a = u[1], n === l && a === f || (o[s++] = [n - l, a - f], l = n, f = a);
                1 === s && (o[s++] = [0, 0]), o.length = s
            }
            return t
        }(a.arcs)), a
    };

    function T(t) {
        var e, r = t[0],
            n = t[1];
        return n < r && (e = r, r = n, n = e), r + 31 * n
    }

    function O(t, e) {
        var r, n = t[0],
            a = t[1],
            o = e[0],
            i = e[1];
        return a < n && (r = n, n = a, a = r), i < o && (r = o, o = i, i = r), n === o && a === i
    }
    var N = function(t, e) {
        var r, n = t.objects,
            a = {};

        function o(t) {
            var e, r;
            switch (t.type) {
                case "Polygon":
                    e = (r = i(t.arcs)) ? {
                        type: "Polygon",
                        arcs: r
                    } : {
                        type: null
                    };
                    break;
                case "MultiPolygon":
                    e = (r = t.arcs.map(i).filter(L)).length ? {
                        type: "MultiPolygon",
                        arcs: r
                    } : {
                        type: null
                    };
                    break;
                case "GeometryCollection":
                    e = (r = t.geometries.map(o).filter(q)).length ? {
                        type: "GeometryCollection",
                        geometries: r
                    } : {
                        type: null
                    };
                    break;
                default:
                    return t
            }
            return null != t.id && (e.id = t.id), null != t.bbox && (e.bbox = t.bbox), null != t.properties && (e.properties = t.properties), e
        }

        function i(t) {
            return t.length && (r = t[0], e(r, !1)) ? [t[0]].concat(t.slice(1).filter(s)) : null;
            var r
        }

        function s(t) {
            return e(t, !0)
        }
        for (r in null == e && (e = j), n) a[r] = o(n[r]);
        return function(t) {
            var e, r, n = t.objects,
                a = {},
                o = t.arcs,
                i = o.length,
                s = -1,
                c = new Array(i),
                u = 0,
                l = -1;

            function f(t) {
                switch (t.type) {
                    case "GeometryCollection":
                        t.geometries.forEach(f);
                        break;
                    case "LineString":
                        p(t.arcs);
                        break;
                    case "MultiLineString":
                    case "Polygon":
                        t.arcs.forEach(p);
                        break;
                    case "MultiPolygon":
                        t.arcs.forEach(h)
                }
            }

            function d(t) {
                t < 0 && (t = ~t), c[t] || (c[t] = 1, ++u)
            }

            function p(t) {
                t.forEach(d)
            }

            function h(t) {
                t.forEach(p)
            }

            function m(t) {
                var e;
                switch (t.type) {
                    case "GeometryCollection":
                        e = {
                            type: "GeometryCollection",
                            geometries: t.geometries.map(m)
                        };
                        break;
                    case "LineString":
                        e = {
                            type: "LineString",
                            arcs: g(t.arcs)
                        };
                        break;
                    case "MultiLineString":
                        e = {
                            type: "MultiLineString",
                            arcs: t.arcs.map(g)
                        };
                        break;
                    case "Polygon":
                        e = {
                            type: "Polygon",
                            arcs: t.arcs.map(g)
                        };
                        break;
                    case "MultiPolygon":
                        e = {
                            type: "MultiPolygon",
                            arcs: t.arcs.map(v)
                        };
                        break;
                    default:
                        return t
                }
                return null != t.id && (e.id = t.id), null != t.bbox && (e.bbox = t.bbox), null != t.properties && (e.properties = t.properties), e
            }

            function y(t) {
                return t < 0 ? ~c[~t] : c[t]
            }

            function g(t) {
                return t.map(y)
            }

            function v(t) {
                return t.map(g)
            }
            for (r in n) f(n[r]);
            for (e = new Array(u); ++s < i;) c[s] && (c[s] = ++l, e[l] = o[s]);
            for (r in n) a[r] = m(n[r]);
            return {
                type: "Topology",
                bbox: t.bbox,
                transform: t.transform,
                objects: a,
                arcs: e
            }
        }({
            type: "Topology",
            bbox: t.bbox,
            transform: t.transform,
            objects: a,
            arcs: t.arcs
        })
    };

    function j() {
        return !0
    }

    function L(t) {
        return t
    }

    function q(t) {
        return null != t.type
    }
    var I = function(t) {
        var e, r = new Array(t.arcs.length),
            n = 0;

        function a(t) {
            switch (t.type) {
                case "GeometryCollection":
                    t.geometries.forEach(a);
                    break;
                case "Polygon":
                    o(t.arcs);
                    break;
                case "MultiPolygon":
                    t.arcs.forEach(o)
            }
        }

        function o(t) {
            for (var e = 0, a = t.length; e < a; ++e, ++n)
                for (var o = t[e], i = 0, s = o.length; i < s; ++i) {
                    var c = o[i];
                    c < 0 && (c = ~c);
                    var u = r[c];
                    null == u ? r[c] = n : u !== n && (r[c] = -1)
                }
        }
        for (e in t.objects) a(t.objects[e]);
        return function(t) {
            for (var e, n = 0, a = t.length; n < a; ++n)
                if (-1 === r[(e = t[n]) < 0 ? ~e : e]) return !0;
            return !1
        }
    };

    function D(t) {
        var e = t[0],
            r = t[1],
            n = t[2];
        return Math.abs((e[0] - n[0]) * (r[1] - e[1]) - (e[0] - r[0]) * (n[1] - e[1])) / 2
    }

    function R(t) {
        for (var e, r = -1, n = t.length, a = t[n - 1], o = 0; ++r < n;) e = a, a = t[r], o += e[0] * a[1] - e[1] * a[0];
        return Math.abs(o) / 2
    }
    var z = function(t, e, r) {
            return e = null == e ? Number.MIN_VALUE : +e, null == r && (r = R),
                function(n, a) {
                    return r(s(t, {
                        type: "Polygon",
                        arcs: [n]
                    }).geometry.coordinates[0], a) >= e
                }
        },
        U = function(t, e, r) {
            var n = I(t),
                a = z(t, e, r);
            return function(t, e) {
                return n(t, e) || a(t, e)
            }
        };

    function H(t, e) {
        return t[1][2] - e[1][2]
    }

    function V(t) {
        return [t[0], t[1], 0]
    }
    var F = function(t, e) {
            var r = t.transform ? a(t.transform) : V,
                n = function() {
                    var t = {},
                        e = [],
                        r = 0;

                    function n(t, r) {
                        for (; r > 0;) {
                            var n = (r + 1 >> 1) - 1,
                                a = e[n];
                            if (H(t, a) >= 0) break;
                            e[a._ = r] = a, e[t._ = r = n] = t
                        }
                    }

                    function a(t, n) {
                        for (;;) {
                            var a = n + 1 << 1,
                                o = a - 1,
                                i = n,
                                s = e[i];
                            if (o < r && H(e[o], s) < 0 && (s = e[i = o]), a < r && H(e[a], s) < 0 && (s = e[i = a]), i === n) break;
                            e[s._ = n] = s, e[t._ = n = i] = t
                        }
                    }
                    return t.push = function(t) {
                        return n(e[t._ = r] = t, r++), r
                    }, t.pop = function() {
                        if (!(r <= 0)) {
                            var t, n = e[0];
                            return --r > 0 && (t = e[r], a(e[t._ = 0] = t, 0)), n
                        }
                    }, t.remove = function(t) {
                        var o, i = t._;
                        if (e[i] === t) return i !== --r && (H(o = e[r], t) < 0 ? n : a)(e[o._ = i] = o, i), i
                    }, t
                }();
            null == e && (e = D);
            var o = t.arcs.map(function(t) {
                var a, o, s, c = [],
                    u = 0;
                for (o = 1, s = (t = t.map(r)).length - 1; o < s; ++o)(a = [t[o - 1], t[o], t[o + 1]])[1][2] = e(a), c.push(a), n.push(a);
                for (t[0][2] = t[s][2] = 1 / 0, o = 0, s = c.length; o < s; ++o)(a = c[o]).previous = c[o - 1], a.next = c[o + 1];
                for (; a = n.pop();) {
                    var l = a.previous,
                        f = a.next;
                    a[1][2] < u ? a[1][2] = u : u = a[1][2], l && (l.next = f, l[2] = a[2], i(l)), f && (f.previous = l, f[0] = a[0], i(f))
                }
                return t
            });

            function i(t) {
                n.remove(t), t[1][2] = e(t), n.push(t)
            }
            return {
                type: "Topology",
                bbox: t.bbox,
                objects: t.objects,
                arcs: o
            }
        },
        B = function(t, e) {
            var r = [];
            return t.arcs.forEach(function(t) {
                t.forEach(function(t) {
                    isFinite(t[2]) && r.push(t[2])
                })
            }), r.length && function(t, e) {
                if (r = t.length) {
                    if ((e = +e) <= 0 || r < 2) return t[0];
                    if (e >= 1) return t[r - 1];
                    var r, n = (r - 1) * e,
                        a = Math.floor(n),
                        o = t[a];
                    return o + (t[a + 1] - o) * (n - a)
                }
            }(r.sort(W), e)
        };

    function W(t, e) {
        return e - t
    }
    var G = function(t, e) {
            e = null == e ? Number.MIN_VALUE : +e;
            var r = t.arcs.map(function(t) {
                for (var r, n = -1, a = 0, o = t.length, i = new Array(o); ++n < o;)(r = t[n])[2] >= e && (i[a++] = [r[0], r[1]]);
                return i.length = a, i
            });
            return {
                type: "Topology",
                transform: t.transform,
                bbox: t.bbox,
                objects: t.objects,
                arcs: r
            }
        },
        X = Math.PI,
        Y = 2 * X,
        $ = X / 4,
        Q = X / 180,
        K = Math.abs,
        J = Math.atan2,
        Z = Math.cos,
        tt = Math.sin;

    function et(t, e) {
        for (var r, n, a, o = 0, i = t.length, s = 0, c = t[e ? o++ : i - 1], u = c[0] * Q, l = c[1] * Q / 2 + $, f = Z(l), d = tt(l); o < i; ++o) {
            r = u, u = (c = t[o])[0] * Q, l = c[1] * Q / 2 + $, n = f, f = Z(l), a = d, d = tt(l);
            var p = u - r,
                h = p >= 0 ? 1 : -1,
                m = h * p,
                y = a * d,
                g = n * f + y * Z(m),
                v = y * h * tt(m);
            s += J(v, g)
        }
        return s
    }

    function rt(t, e) {
        var r = et(t, !0);
        return e && (r *= -1), 2 * (r < 0 ? Y + r : r)
    }

    function nt(t) {
        return 2 * K(et(t, !1))
    }
    r.d(e, "bbox", function() {
        return o
    }), r.d(e, "feature", function() {
        return s
    }), r.d(e, "mesh", function() {
        return f
    }), r.d(e, "meshArcs", function() {
        return d
    }), r.d(e, "merge", function() {
        return p
    }), r.d(e, "mergeArcs", function() {
        return h
    }), r.d(e, "neighbors", function() {
        return y
    }), r.d(e, "quantize", function() {
        return v
    }), r.d(e, "transform", function() {
        return a
    }), r.d(e, "untransform", function() {
        return g
    }), r.d(e, "topology", function() {
        return P
    }), r.d(e, "filter", function() {
        return N
    }), r.d(e, "filterAttached", function() {
        return I
    }), r.d(e, "filterAttachedWeight", function() {
        return U
    }), r.d(e, "filterWeight", function() {
        return z
    }), r.d(e, "planarRingArea", function() {
        return R
    }), r.d(e, "planarTriangleArea", function() {
        return D
    }), r.d(e, "presimplify", function() {
        return F
    }), r.d(e, "quantile", function() {
        return B
    }), r.d(e, "simplify", function() {
        return G
    }), r.d(e, "sphericalRingArea", function() {
        return rt
    }), r.d(e, "sphericalTriangleArea", function() {
        return nt
    })
}, function(t, e, r) {
    "use strict";
    var n = s(r(5)),
        a = s(r(7)),
        o = s(r(8)),
        i = r(24);

    function s(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }
    var c = d3.select("body"),
        u = (0, i.select)("body"),
        l = 0;

    function f() {
        window.matchMedia("(min-width: 800px)").matches ? (0, i.addClass)(u, "is-full") : (0, i.removeClass)(u, "is-full")
    }
    c.classed("is-mobile", a.default.any()), f(), window.addEventListener("resize", (0, n.default)(function() {
        var t = c.node().offsetWidth;
        l !== t && (l = t, f(), o.default.resize())
    }, 150)), o.default.init()
}, function(t, e, r) {
    (function(e) {
        var r = NaN,
            n = "[object Symbol]",
            a = /^\s+|\s+$/g,
            o = /^[-+]0x[0-9a-f]+$/i,
            i = /^0b[01]+$/i,
            s = /^0o[0-7]+$/i,
            c = parseInt,
            u = "object" == typeof e && e && e.Object === Object && e,
            l = "object" == typeof self && self && self.Object === Object && self,
            f = u || l || Function("return this")(),
            d = Object.prototype.toString,
            p = Math.max,
            h = Math.min,
            m = function() {
                return f.Date.now()
            };

        function y(t) {
            var e = typeof t;
            return !!t && ("object" == e || "function" == e)
        }

        function g(t) {
            if ("number" == typeof t) return t;
            if (function(t) {
                    return "symbol" == typeof t || function(t) {
                        return !!t && "object" == typeof t
                    }(t) && d.call(t) == n
                }(t)) return r;
            if (y(t)) {
                var e = "function" == typeof t.valueOf ? t.valueOf() : t;
                t = y(e) ? e + "" : e
            }
            if ("string" != typeof t) return 0 === t ? t : +t;
            t = t.replace(a, "");
            var u = i.test(t);
            return u || s.test(t) ? c(t.slice(2), u ? 2 : 8) : o.test(t) ? r : +t
        }
        t.exports = function(t, e, r) {
            var n, a, o, i, s, c, u = 0,
                l = !1,
                f = !1,
                d = !0;
            if ("function" != typeof t) throw new TypeError("Expected a function");

            function v(e) {
                var r = n,
                    o = a;
                return n = a = void 0, u = e, i = t.apply(o, r)
            }

            function b(t) {
                var r = t - c;
                return void 0 === c || r >= e || r < 0 || f && t - u >= o
            }

            function x() {
                var t = m();
                if (b(t)) return w(t);
                s = setTimeout(x, function(t) {
                    var r = e - (t - c);
                    return f ? h(r, o - (t - u)) : r
                }(t))
            }

            function w(t) {
                return s = void 0, d && n ? v(t) : (n = a = void 0, i)
            }

            function _() {
                var t = m(),
                    r = b(t);
                if (n = arguments, a = this, c = t, r) {
                    if (void 0 === s) return function(t) {
                        return u = t, s = setTimeout(x, e), l ? v(t) : i
                    }(c);
                    if (f) return s = setTimeout(x, e), v(c)
                }
                return void 0 === s && (s = setTimeout(x, e)), i
            }
            return e = g(e) || 0, y(r) && (l = !!r.leading, o = (f = "maxWait" in r) ? p(g(r.maxWait) || 0, e) : o, d = "trailing" in r ? !!r.trailing : d), _.cancel = function() {
                void 0 !== s && clearTimeout(s), u = 0, n = c = a = s = void 0
            }, _.flush = function() {
                return void 0 === s ? i : w(m())
            }, _
        }
    }).call(this, r(6))
}, function(t, e) {
    var r;
    r = function() {
        return this
    }();
    try {
        r = r || Function("return this")() || (0, eval)("this")
    } catch (t) {
        "object" == typeof window && (r = window)
    }
    t.exports = r
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n = {
        android: function() {
            return navigator.userAgent.match(/Android/i)
        },
        blackberry: function() {
            return navigator.userAgent.match(/BlackBerry/i)
        },
        ios: function() {
            return navigator.userAgent.match(/iPhone|iPad|iPod/i)
        },
        opera: function() {
            return navigator.userAgent.match(/Opera Mini/i)
        },
        windows: function() {
            return navigator.userAgent.match(/IEMobile/i)
        },
        any: function() {
            return n.android() || n.blackberry() || n.ios() || n.opera() || n.windows()
        }
    };
    e.default = n
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n = c(r(9)),
        a = c(r(17)),
        o = c(r(19)),
        i = c(r(21)),
        s = c(r(23));

    function c(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }
    var u = d3.select("body"),
        l = {
            location: !1,
            loaded: !1
        };

    function f() {
        l.location && l.loaded && (o.default.setupScroll(l.location), s.default.init())
    }
    e.default = {
        init: function() {
            ! function() {
                if (u.classed("is-mobile")) {
                    var t = window.innerHeight;
                    u.select("main").style("height", Math.floor(1.05 * t) + "px"), u.select(".intro").style("height", t + "px")
                }
            }(), (0, n.default)("fd4d87f605681c0959c16d9164ab6a4a", function(t, e) {
                var r = t ? {} : e;
                l.location = !0, o.default.hed(r), f()
            }), a.default.init().then(function(t) {
                l.loaded = !0;
                var e = [].concat(function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, r = Array(t.length); e < t.length; e++) r[e] = t[e];
                            return r
                        }
                        return Array.from(t)
                    }(t)),
                    r = e[0],
                    n = e[1],
                    a = e[2];
                o.default.init({
                    usaData: r,
                    breweryData: n,
                    cityData: a
                }), i.default.init({
                    breweryData: n,
                    cityData: a
                }), f()
            }).catch(function(t) {
                return console.log(t)
            })
        },
        resize: function() {
            o.default.resize(), i.default.resize(), s.default.resize()
        }
    }
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n = o(r(10)),
        a = o(r(16));

    function o(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }
    var i = !1,
        s = null;

    function c(t) {
        var e = t.ip;
        if (i) return Promise.resolve(a.default);
        var r = "https://api.ipstack.com/" + e + "?access_key=" + s;
        return new Promise(function(t, e) {
            n.default.get(r).end(function(r, n) {
                if (r) e(r);
                else if (n && n.status >= 200 && n.status < 400) {
                    var a = JSON.parse(n.text);
                    a.error ? e(a.error) : t(a)
                } else e(r)
            })
        })
    }
    e.default = function(t, e) {
        if (t) {
            s = t;
            var r = setTimeout(function() {
                return e("timeout")
            }, 4e3);
            (i ? Promise.resolve(a.default) : new Promise(function(t, e) {
                n.default.get("https://api.ipify.org?format=json").end(function(r, n) {
                    r ? e(r) : n && n.status >= 200 && n.status < 400 ? t(JSON.parse(n.text)) : e(r)
                })
            })).then(c).then(function(t) {
                clearTimeout(r), e(null, t)
            }).catch(function(t) {
                return e(t)
            })
        } else e("error: must pass ipstack key")
    }
}, function(t, e, r) {
    var n;
    "undefined" != typeof window ? n = window : "undefined" != typeof self ? n = self : (console.warn("Using browser-only version of superagent in non-browser environment"), n = this);
    var a = r(11),
        o = r(12),
        i = r(0),
        s = r(13),
        c = r(15);

    function u() {}
    var l = e = t.exports = function(t, r) {
        return "function" == typeof r ? new e.Request("GET", t).end(r) : 1 == arguments.length ? new e.Request("GET", t) : new e.Request(t, r)
    };
    e.Request = g, l.getXHR = function() {
        if (!(!n.XMLHttpRequest || n.location && "file:" == n.location.protocol && n.ActiveXObject)) return new XMLHttpRequest;
        try {
            return new ActiveXObject("Microsoft.XMLHTTP")
        } catch (t) {}
        try {
            return new ActiveXObject("Msxml2.XMLHTTP.6.0")
        } catch (t) {}
        try {
            return new ActiveXObject("Msxml2.XMLHTTP.3.0")
        } catch (t) {}
        try {
            return new ActiveXObject("Msxml2.XMLHTTP")
        } catch (t) {}
        throw Error("Browser-only version of superagent could not find XHR")
    };
    var f = "".trim ? function(t) {
        return t.trim()
    } : function(t) {
        return t.replace(/(^\s*|\s*$)/g, "")
    };

    function d(t) {
        if (!i(t)) return t;
        var e = [];
        for (var r in t) p(e, r, t[r]);
        return e.join("&")
    }

    function p(t, e, r) {
        if (null != r)
            if (Array.isArray(r)) r.forEach(function(r) {
                p(t, e, r)
            });
            else if (i(r))
            for (var n in r) p(t, e + "[" + n + "]", r[n]);
        else t.push(encodeURIComponent(e) + "=" + encodeURIComponent(r));
        else null === r && t.push(encodeURIComponent(e))
    }

    function h(t) {
        for (var e, r, n = {}, a = t.split("&"), o = 0, i = a.length; o < i; ++o) - 1 == (r = (e = a[o]).indexOf("=")) ? n[decodeURIComponent(e)] = "" : n[decodeURIComponent(e.slice(0, r))] = decodeURIComponent(e.slice(r + 1));
        return n
    }

    function m(t) {
        return /[\/+]json($|[^-\w])/.test(t)
    }

    function y(t) {
        this.req = t, this.xhr = this.req.xhr, this.text = "HEAD" != this.req.method && ("" === this.xhr.responseType || "text" === this.xhr.responseType) || void 0 === this.xhr.responseType ? this.xhr.responseText : null, this.statusText = this.req.xhr.statusText;
        var e = this.xhr.status;
        1223 === e && (e = 204), this._setStatusProperties(e), this.header = this.headers = function(t) {
            for (var e, r, n, a, o = t.split(/\r?\n/), i = {}, s = 0, c = o.length; s < c; ++s) - 1 !== (e = (r = o[s]).indexOf(":")) && (n = r.slice(0, e).toLowerCase(), a = f(r.slice(e + 1)), i[n] = a);
            return i
        }(this.xhr.getAllResponseHeaders()), this.header["content-type"] = this.xhr.getResponseHeader("content-type"), this._setHeaderProperties(this.header), null === this.text && t._responseType ? this.body = this.xhr.response : this.body = "HEAD" != this.req.method ? this._parseBody(this.text ? this.text : this.xhr.response) : null
    }

    function g(t, e) {
        var r = this;
        this._query = this._query || [], this.method = t, this.url = e, this.header = {}, this._header = {}, this.on("end", function() {
            var t, e = null,
                n = null;
            try {
                n = new y(r)
            } catch (t) {
                return (e = new Error("Parser is unable to parse the response")).parse = !0, e.original = t, r.xhr ? (e.rawResponse = void 0 === r.xhr.responseType ? r.xhr.responseText : r.xhr.response, e.status = r.xhr.status ? r.xhr.status : null, e.statusCode = e.status) : (e.rawResponse = null, e.status = null), r.callback(e)
            }
            r.emit("response", n);
            try {
                r._isResponseOK(n) || (t = new Error(n.statusText || "Unsuccessful HTTP response"))
            } catch (e) {
                t = e
            }
            t ? (t.original = e, t.response = n, t.status = n.status, r.callback(t, n)) : r.callback(null, n)
        })
    }

    function v(t, e, r) {
        var n = l("DELETE", t);
        return "function" == typeof e && (r = e, e = null), e && n.send(e), r && n.end(r), n
    }
    l.serializeObject = d, l.parseString = h, l.types = {
        html: "text/html",
        json: "application/json",
        xml: "text/xml",
        urlencoded: "application/x-www-form-urlencoded",
        form: "application/x-www-form-urlencoded",
        "form-data": "application/x-www-form-urlencoded"
    }, l.serialize = {
        "application/x-www-form-urlencoded": d,
        "application/json": JSON.stringify
    }, l.parse = {
        "application/x-www-form-urlencoded": h,
        "application/json": JSON.parse
    }, s(y.prototype), y.prototype._parseBody = function(t) {
        var e = l.parse[this.type];
        return this.req._parser ? this.req._parser(this, t) : (!e && m(this.type) && (e = l.parse["application/json"]), e && t && (t.length || t instanceof Object) ? e(t) : null)
    }, y.prototype.toError = function() {
        var t = this.req,
            e = t.method,
            r = t.url,
            n = "cannot " + e + " " + r + " (" + this.status + ")",
            a = new Error(n);
        return a.status = this.status, a.method = e, a.url = r, a
    }, l.Response = y, a(g.prototype), o(g.prototype), g.prototype.type = function(t) {
        return this.set("Content-Type", l.types[t] || t), this
    }, g.prototype.accept = function(t) {
        return this.set("Accept", l.types[t] || t), this
    }, g.prototype.auth = function(t, e, r) {
        return 1 === arguments.length && (e = ""), "object" == typeof e && null !== e && (r = e, e = ""), r || (r = {
            type: "function" == typeof btoa ? "basic" : "auto"
        }), this._auth(t, e, r, function(t) {
            if ("function" == typeof btoa) return btoa(t);
            throw new Error("Cannot use basic auth, btoa is not a function")
        })
    }, g.prototype.query = function(t) {
        return "string" != typeof t && (t = d(t)), t && this._query.push(t), this
    }, g.prototype.attach = function(t, e, r) {
        if (e) {
            if (this._data) throw Error("superagent can't mix .send() and .attach()");
            this._getFormData().append(t, e, r || e.name)
        }
        return this
    }, g.prototype._getFormData = function() {
        return this._formData || (this._formData = new n.FormData), this._formData
    }, g.prototype.callback = function(t, e) {
        if (this._shouldRetry(t, e)) return this._retry();
        var r = this._callback;
        this.clearTimeout(), t && (this._maxRetries && (t.retries = this._retries - 1), this.emit("error", t)), r(t, e)
    }, g.prototype.crossDomainError = function() {
        var t = new Error("Request has been terminated\nPossible causes: the network is offline, Origin is not allowed by Access-Control-Allow-Origin, the page is being unloaded, etc.");
        t.crossDomain = !0, t.status = this.status, t.method = this.method, t.url = this.url, this.callback(t)
    }, g.prototype.buffer = g.prototype.ca = g.prototype.agent = function() {
        return console.warn("This is not supported in browser version of superagent"), this
    }, g.prototype.pipe = g.prototype.write = function() {
        throw Error("Streaming is not supported in browser version of superagent")
    }, g.prototype._isHost = function(t) {
        return t && "object" == typeof t && !Array.isArray(t) && "[object Object]" !== Object.prototype.toString.call(t)
    }, g.prototype.end = function(t) {
        return this._endCalled && console.warn("Warning: .end() was called twice. This is not supported in superagent"), this._endCalled = !0, this._callback = t || u, this._finalizeQueryString(), this._end()
    }, g.prototype._end = function() {
        var t = this,
            e = this.xhr = l.getXHR(),
            r = this._formData || this._data;
        this._setTimeouts(), e.onreadystatechange = function() {
            var r = e.readyState;
            if (r >= 2 && t._responseTimeoutTimer && clearTimeout(t._responseTimeoutTimer), 4 == r) {
                var n;
                try {
                    n = e.status
                } catch (t) {
                    n = 0
                }
                if (!n) {
                    if (t.timedout || t._aborted) return;
                    return t.crossDomainError()
                }
                t.emit("end")
            }
        };
        var n = function(e, r) {
            r.total > 0 && (r.percent = r.loaded / r.total * 100), r.direction = e, t.emit("progress", r)
        };
        if (this.hasListeners("progress")) try {
            e.onprogress = n.bind(null, "download"), e.upload && (e.upload.onprogress = n.bind(null, "upload"))
        } catch (t) {}
        try {
            this.username && this.password ? e.open(this.method, this.url, !0, this.username, this.password) : e.open(this.method, this.url, !0)
        } catch (t) {
            return this.callback(t)
        }
        if (this._withCredentials && (e.withCredentials = !0), !this._formData && "GET" != this.method && "HEAD" != this.method && "string" != typeof r && !this._isHost(r)) {
            var a = this._header["content-type"],
                o = this._serializer || l.serialize[a ? a.split(";")[0] : ""];
            !o && m(a) && (o = l.serialize["application/json"]), o && (r = o(r))
        }
        for (var i in this.header) null != this.header[i] && this.header.hasOwnProperty(i) && e.setRequestHeader(i, this.header[i]);
        return this._responseType && (e.responseType = this._responseType), this.emit("request", this), e.send(void 0 !== r ? r : null), this
    }, l.agent = function() {
        return new c
    }, ["GET", "POST", "OPTIONS", "PATCH", "PUT", "DELETE"].forEach(function(t) {
        c.prototype[t.toLowerCase()] = function(e, r) {
            var n = new l.Request(t, e);
            return this._setDefaults(n), r && n.end(r), n
        }
    }), c.prototype.del = c.prototype.delete, l.get = function(t, e, r) {
        var n = l("GET", t);
        return "function" == typeof e && (r = e, e = null), e && n.query(e), r && n.end(r), n
    }, l.head = function(t, e, r) {
        var n = l("HEAD", t);
        return "function" == typeof e && (r = e, e = null), e && n.query(e), r && n.end(r), n
    }, l.options = function(t, e, r) {
        var n = l("OPTIONS", t);
        return "function" == typeof e && (r = e, e = null), e && n.send(e), r && n.end(r), n
    }, l.del = v, l.delete = v, l.patch = function(t, e, r) {
        var n = l("PATCH", t);
        return "function" == typeof e && (r = e, e = null), e && n.send(e), r && n.end(r), n
    }, l.post = function(t, e, r) {
        var n = l("POST", t);
        return "function" == typeof e && (r = e, e = null), e && n.send(e), r && n.end(r), n
    }, l.put = function(t, e, r) {
        var n = l("PUT", t);
        return "function" == typeof e && (r = e, e = null), e && n.send(e), r && n.end(r), n
    }
}, function(t, e, r) {
    function n(t) {
        if (t) return function(t) {
            for (var e in n.prototype) t[e] = n.prototype[e];
            return t
        }(t)
    }
    t.exports = n, n.prototype.on = n.prototype.addEventListener = function(t, e) {
        return this._callbacks = this._callbacks || {}, (this._callbacks["$" + t] = this._callbacks["$" + t] || []).push(e), this
    }, n.prototype.once = function(t, e) {
        function r() {
            this.off(t, r), e.apply(this, arguments)
        }
        return r.fn = e, this.on(t, r), this
    }, n.prototype.off = n.prototype.removeListener = n.prototype.removeAllListeners = n.prototype.removeEventListener = function(t, e) {
        if (this._callbacks = this._callbacks || {}, 0 == arguments.length) return this._callbacks = {}, this;
        var r, n = this._callbacks["$" + t];
        if (!n) return this;
        if (1 == arguments.length) return delete this._callbacks["$" + t], this;
        for (var a = 0; a < n.length; a++)
            if ((r = n[a]) === e || r.fn === e) {
                n.splice(a, 1);
                break
            }
        return this
    }, n.prototype.emit = function(t) {
        this._callbacks = this._callbacks || {};
        var e = [].slice.call(arguments, 1),
            r = this._callbacks["$" + t];
        if (r)
            for (var n = 0, a = (r = r.slice(0)).length; n < a; ++n) r[n].apply(this, e);
        return this
    }, n.prototype.listeners = function(t) {
        return this._callbacks = this._callbacks || {}, this._callbacks["$" + t] || []
    }, n.prototype.hasListeners = function(t) {
        return !!this.listeners(t).length
    }
}, function(t, e, r) {
    "use strict";
    var n = r(0);

    function a(t) {
        if (t) return function(t) {
            for (var e in a.prototype) t[e] = a.prototype[e];
            return t
        }(t)
    }
    t.exports = a, a.prototype.clearTimeout = function() {
        return clearTimeout(this._timer), clearTimeout(this._responseTimeoutTimer), delete this._timer, delete this._responseTimeoutTimer, this
    }, a.prototype.parse = function(t) {
        return this._parser = t, this
    }, a.prototype.responseType = function(t) {
        return this._responseType = t, this
    }, a.prototype.serialize = function(t) {
        return this._serializer = t, this
    }, a.prototype.timeout = function(t) {
        if (!t || "object" != typeof t) return this._timeout = t, this._responseTimeout = 0, this;
        for (var e in t) switch (e) {
            case "deadline":
                this._timeout = t.deadline;
                break;
            case "response":
                this._responseTimeout = t.response;
                break;
            default:
                console.warn("Unknown timeout option", e)
        }
        return this
    }, a.prototype.retry = function(t, e) {
        return 0 !== arguments.length && !0 !== t || (t = 1), t <= 0 && (t = 0), this._maxRetries = t, this._retries = 0, this._retryCallback = e, this
    };
    var o = ["ECONNRESET", "ETIMEDOUT", "EADDRINFO", "ESOCKETTIMEDOUT"];
    a.prototype._shouldRetry = function(t, e) {
        if (!this._maxRetries || this._retries++ >= this._maxRetries) return !1;
        if (this._retryCallback) try {
            var r = this._retryCallback(t, e);
            if (!0 === r) return !0;
            if (!1 === r) return !1
        } catch (t) {
            console.error(t)
        }
        if (e && e.status && e.status >= 500 && 501 != e.status) return !0;
        if (t) {
            if (t.code && ~o.indexOf(t.code)) return !0;
            if (t.timeout && "ECONNABORTED" == t.code) return !0;
            if (t.crossDomain) return !0
        }
        return !1
    }, a.prototype._retry = function() {
        return this.clearTimeout(), this.req && (this.req = null, this.req = this.request()), this._aborted = !1, this.timedout = !1, this._end()
    }, a.prototype.then = function(t, e) {
        if (!this._fullfilledPromise) {
            var r = this;
            this._endCalled && console.warn("Warning: superagent request was sent twice, because both .end() and .then() were called. Never call .end() if you use promises"), this._fullfilledPromise = new Promise(function(t, e) {
                r.end(function(r, n) {
                    r ? e(r) : t(n)
                })
            })
        }
        return this._fullfilledPromise.then(t, e)
    }, a.prototype.catch = function(t) {
        return this.then(void 0, t)
    }, a.prototype.use = function(t) {
        return t(this), this
    }, a.prototype.ok = function(t) {
        if ("function" != typeof t) throw Error("Callback required");
        return this._okCallback = t, this
    }, a.prototype._isResponseOK = function(t) {
        return !!t && (this._okCallback ? this._okCallback(t) : t.status >= 200 && t.status < 300)
    }, a.prototype.get = function(t) {
        return this._header[t.toLowerCase()]
    }, a.prototype.getHeader = a.prototype.get, a.prototype.set = function(t, e) {
        if (n(t)) {
            for (var r in t) this.set(r, t[r]);
            return this
        }
        return this._header[t.toLowerCase()] = e, this.header[t] = e, this
    }, a.prototype.unset = function(t) {
        return delete this._header[t.toLowerCase()], delete this.header[t], this
    }, a.prototype.field = function(t, e) {
        if (null === t || void 0 === t) throw new Error(".field(name, val) name can not be empty");
        if (this._data && console.error(".field() can't be used if .send() is used. Please use only .send() or only .field() & .attach()"), n(t)) {
            for (var r in t) this.field(r, t[r]);
            return this
        }
        if (Array.isArray(e)) {
            for (var a in e) this.field(t, e[a]);
            return this
        }
        if (null === e || void 0 === e) throw new Error(".field(name, val) val can not be empty");
        return "boolean" == typeof e && (e = "" + e), this._getFormData().append(t, e), this
    }, a.prototype.abort = function() {
        return this._aborted ? this : (this._aborted = !0, this.xhr && this.xhr.abort(), this.req && this.req.abort(), this.clearTimeout(), this.emit("abort"), this)
    }, a.prototype._auth = function(t, e, r, n) {
        switch (r.type) {
            case "basic":
                this.set("Authorization", "Basic " + n(t + ":" + e));
                break;
            case "auto":
                this.username = t, this.password = e;
                break;
            case "bearer":
                this.set("Authorization", "Bearer " + t)
        }
        return this
    }, a.prototype.withCredentials = function(t) {
        return void 0 == t && (t = !0), this._withCredentials = t, this
    }, a.prototype.redirects = function(t) {
        return this._maxRedirects = t, this
    }, a.prototype.maxResponseSize = function(t) {
        if ("number" != typeof t) throw TypeError("Invalid argument");
        return this._maxResponseSize = t, this
    }, a.prototype.toJSON = function() {
        return {
            method: this.method,
            url: this.url,
            data: this._data,
            headers: this._header
        }
    }, a.prototype.send = function(t) {
        var e = n(t),
            r = this._header["content-type"];
        if (this._formData && console.error(".send() can't be used if .attach() or .field() is used. Please use only .send() or only .field() & .attach()"), e && !this._data) Array.isArray(t) ? this._data = [] : this._isHost(t) || (this._data = {});
        else if (t && this._data && this._isHost(this._data)) throw Error("Can't merge these send calls");
        if (e && n(this._data))
            for (var a in t) this._data[a] = t[a];
        else "string" == typeof t ? (r || this.type("form"), r = this._header["content-type"], this._data = "application/x-www-form-urlencoded" == r ? this._data ? this._data + "&" + t : t : (this._data || "") + t) : this._data = t;
        return !e || this._isHost(t) ? this : (r || this.type("json"), this)
    }, a.prototype.sortQuery = function(t) {
        return this._sort = void 0 === t || t, this
    }, a.prototype._finalizeQueryString = function() {
        var t = this._query.join("&");
        if (t && (this.url += (this.url.indexOf("?") >= 0 ? "&" : "?") + t), this._query.length = 0, this._sort) {
            var e = this.url.indexOf("?");
            if (e >= 0) {
                var r = this.url.substring(e + 1).split("&");
                "function" == typeof this._sort ? r.sort(this._sort) : r.sort(), this.url = this.url.substring(0, e) + "?" + r.join("&")
            }
        }
    }, a.prototype._appendQueryString = function() {
        console.trace("Unsupported")
    }, a.prototype._timeoutError = function(t, e, r) {
        if (!this._aborted) {
            var n = new Error(t + e + "ms exceeded");
            n.timeout = e, n.code = "ECONNABORTED", n.errno = r, this.timedout = !0, this.abort(), this.callback(n)
        }
    }, a.prototype._setTimeouts = function() {
        var t = this;
        this._timeout && !this._timer && (this._timer = setTimeout(function() {
            t._timeoutError("Timeout of ", t._timeout, "ETIME")
        }, this._timeout)), this._responseTimeout && !this._responseTimeoutTimer && (this._responseTimeoutTimer = setTimeout(function() {
            t._timeoutError("Response timeout of ", t._responseTimeout, "ETIMEDOUT")
        }, this._responseTimeout))
    }
}, function(t, e, r) {
    "use strict";
    var n = r(14);

    function a(t) {
        if (t) return function(t) {
            for (var e in a.prototype) t[e] = a.prototype[e];
            return t
        }(t)
    }
    t.exports = a, a.prototype.get = function(t) {
        return this.header[t.toLowerCase()]
    }, a.prototype._setHeaderProperties = function(t) {
        var e = t["content-type"] || "";
        this.type = n.type(e);
        var r = n.params(e);
        for (var a in r) this[a] = r[a];
        this.links = {};
        try {
            t.link && (this.links = n.parseLinks(t.link))
        } catch (t) {}
    }, a.prototype._setStatusProperties = function(t) {
        var e = t / 100 | 0;
        this.status = this.statusCode = t, this.statusType = e, this.info = 1 == e, this.ok = 2 == e, this.redirect = 3 == e, this.clientError = 4 == e, this.serverError = 5 == e, this.error = (4 == e || 5 == e) && this.toError(), this.created = 201 == t, this.accepted = 202 == t, this.noContent = 204 == t, this.badRequest = 400 == t, this.unauthorized = 401 == t, this.notAcceptable = 406 == t, this.forbidden = 403 == t, this.notFound = 404 == t, this.unprocessableEntity = 422 == t
    }
}, function(t, e, r) {
    "use strict";
    e.type = function(t) {
        return t.split(/ *; */).shift()
    }, e.params = function(t) {
        return t.split(/ *; */).reduce(function(t, e) {
            var r = e.split(/ *= */),
                n = r.shift(),
                a = r.shift();
            return n && a && (t[n] = a), t
        }, {})
    }, e.parseLinks = function(t) {
        return t.split(/ *, */).reduce(function(t, e) {
            var r = e.split(/ *; */),
                n = r[0].slice(1, -1);
            return t[r[1].split(/ *= */)[1].slice(1, -1)] = n, t
        }, {})
    }, e.cleanHeader = function(t, e) {
        return delete t["content-type"], delete t["content-length"], delete t["transfer-encoding"], delete t.host, e && (delete t.authorization, delete t.cookie), t
    }
}, function(t, e) {
    function r() {
        this._defaults = []
    }["use", "on", "once", "set", "query", "type", "accept", "auth", "withCredentials", "sortQuery", "retry", "ok", "redirects", "timeout", "buffer", "serialize", "parse", "ca", "key", "pfx", "cert"].forEach(function(t) {
        r.prototype[t] = function() {
            return this._defaults.push({
                fn: t,
                arguments: arguments
            }), this
        }
    }), r.prototype._setDefaults = function(t) {
        this._defaults.forEach(function(e) {
            t[e.fn].apply(t, e.arguments)
        })
    }, t.exports = r
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = {
        ip: "72.228.10.129",
        hostname: "cpe-72-228-10-129.nycap.res.rr.com",
        type: "ipv4",
        continent_code: "NA",
        continent_name: "North America",
        country_code: "US",
        country_name: "United States",
        region_code: "MA",
        region_name: "Massachusetts",
        city: "Great Barrington",
        zip: "01230",
        latitude: 42.1617,
        longitude: -73.3277,
        location: {
            geoname_id: 4938157,
            capital: "Washington D.C.",
            languages: [{
                code: "en",
                name: "English",
                native: "English"
            }],
            country_flag: "http://assets.ipstack.com/flags/us.svg",
            country_flag_emoji: "рџ‡єрџ‡ё",
            country_flag_emoji_unicode: "U+1F1FA U+1F1F8",
            calling_code: "1",
            is_eu: !1
        },
        time_zone: {
            id: "America/New_York",
            current_time: "2018-04-17T15:29:13-04:00",
            gmt_offset: -14400,
            code: "EDT",
            is_daylight_saving: !0
        },
        currency: {
            code: "USD",
            name: "US Dollar",
            plural: "US dollars",
            symbol: "$",
            symbol_native: "$"
        },
        connection: {
            asn: 11351,
            isp: "Time Warner Cable Internet LLC"
        },
        security: {
            is_proxy: !1,
            proxy_type: null,
            is_crawler: !1,
            crawler_name: null,
            crawler_type: null,
            is_tor: !1,
            threat_level: "low",
            threat_types: null
        }
    }
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n, a = Object.assign || function(t) {
            for (var e = 1; e < arguments.length; e++) {
                var r = arguments[e];
                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
            }
            return t
        },
        o = (n = (function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            e.default = t
        }(r(3)), r(18))) && n.__esModule ? n : {
            default: n
        };

    function i(t) {
        d3.json("assets/usa.json", function(e, r) {
            if (r) {
                var n = r.objects.states.geometries.filter(function(t) {
                    return t.id < 60
                });
                r.objects.states.geometries = n
            }
            t(e, r)
        })
    }

    function s(t) {
        return a({}, t, {
            lat: +t.lat,
            lng: +t.lng,
            year: +t.year,
            cities: (o = t.cities, o.split("|").map(function(t) {
                var e = t.split("-");
                return {
                    index: +e[0],
                    dist: +e[1]
                }
            })),
            beers: (n = t.beers, n.split("|").map(function(t) {
                var e = t.split("-");
                return {
                    abv: +e[0],
                    score: +e[1],
                    reviews: +e[2]
                }
            })),
            cityIndex: t.cityIndex ? +t.cityIndex : null,
            name: (e = t.name, r = e.split(/\(|\//)[0].substring(0, 35), r.length > 32 ? r.substring(0, 32) + "..." : r)
        });
        var e, r, n, o
    }

    function c(t) {
        d3.csv("assets/breweries_geocoded_with_stats.csv", s, function(e, r) {
            t(e, r)
        })
    }

    function u(t) {
        return a({}, t, {
            lat: +t.lat,
            lng: +t.lng,
            population: +t.population,
            index: +t.index,
            stateAbbr: (e = t.state, r = e.toLowerCase(), n = o.default.find(function(t) {
                return t.state.toLowerCase() === r
            }), n ? n.abbr : "")
        });
        var e, r, n
    }

    function l(t) {
        d3.csv("assets/cities_geocoded_40k.csv", u, function(e, r) {
            t(e, r)
        })
    }
    e.default = {
        init: function() {
            return new Promise(function(t, e) {
                d3.queue().defer(i).defer(c).defer(l).awaitAll(function(r, n) {
                    r ? e(r) : t(n)
                })
            })
        }
    }
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = [{
        state: "Alabama",
        abbr: "AL"
    }, {
        state: "Alaska",
        abbr: "AK"
    }, {
        state: "Arizona",
        abbr: "AZ"
    }, {
        state: "Arkansas",
        abbr: "AR"
    }, {
        state: "California",
        abbr: "CA"
    }, {
        state: "Colorado",
        abbr: "CO"
    }, {
        state: "Connecticut",
        abbr: "CT"
    }, {
        state: "Delaware",
        abbr: "DE"
    }, {
        state: "District of Columbia",
        abbr: "DC"
    }, {
        state: "Florida",
        abbr: "FL"
    }, {
        state: "Georgia",
        abbr: "GA"
    }, {
        state: "Hawaii",
        abbr: "HI"
    }, {
        state: "Idaho",
        abbr: "ID"
    }, {
        state: "Illinois",
        abbr: "IL"
    }, {
        state: "Indiana",
        abbr: "IN"
    }, {
        state: "Iowa",
        abbr: "IA"
    }, {
        state: "Kansas",
        abbr: "KS"
    }, {
        state: "Kentucky",
        abbr: "KY"
    }, {
        state: "Louisiana",
        abbr: "LA"
    }, {
        state: "Maine",
        abbr: "ME"
    }, {
        state: "Montana",
        abbr: "MT"
    }, {
        state: "Nebraska",
        abbr: "NE"
    }, {
        state: "Nevada",
        abbr: "NV"
    }, {
        state: "New Hampshire",
        abbr: "NH"
    }, {
        state: "New Jersey",
        abbr: "NJ"
    }, {
        state: "New Mexico",
        abbr: "NM"
    }, {
        state: "New York",
        abbr: "NY"
    }, {
        state: "North Carolina",
        abbr: "NC"
    }, {
        state: "North Dakota",
        abbr: "ND"
    }, {
        state: "Ohio",
        abbr: "OH"
    }, {
        state: "Oklahoma",
        abbr: "OK"
    }, {
        state: "Oregon",
        abbr: "OR"
    }, {
        state: "Maryland",
        abbr: "MD"
    }, {
        state: "Massachusetts",
        abbr: "MA"
    }, {
        state: "Michigan",
        abbr: "MI"
    }, {
        state: "Minnesota",
        abbr: "MN"
    }, {
        state: "Mississippi",
        abbr: "MS"
    }, {
        state: "Missouri",
        abbr: "MO"
    }, {
        state: "Pennsylvania",
        abbr: "PA"
    }, {
        state: "Rhode Island",
        abbr: "RI"
    }, {
        state: "South Carolina",
        abbr: "SC"
    }, {
        state: "South Dakota",
        abbr: "SD"
    }, {
        state: "Tennessee",
        abbr: "TN"
    }, {
        state: "Texas",
        abbr: "TX"
    }, {
        state: "Utah",
        abbr: "UT"
    }, {
        state: "Vermont",
        abbr: "VT"
    }, {
        state: "Virginia",
        abbr: "VA"
    }, {
        state: "Washington",
        abbr: "WA"
    }, {
        state: "West Virginia",
        abbr: "WV"
    }, {
        state: "Wisconsin",
        abbr: "WI"
    }, {
        state: "Wyoming",
        abbr: "WY"
    }, {
        state: "Washington DC",
        abbr: "DC"
    }]
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n = function(t, e) {
            if (Array.isArray(t)) return t;
            if (Symbol.iterator in Object(t)) return function(t, e) {
                var r = [],
                    n = !0,
                    a = !1,
                    o = void 0;
                try {
                    for (var i, s = t[Symbol.iterator](); !(n = (i = s.next()).done) && (r.push(i.value), !e || r.length !== e); n = !0);
                } catch (t) {
                    a = !0, o = t
                } finally {
                    try {
                        !n && s.return && s.return()
                    } finally {
                        if (a) throw o
                    }
                }
                return r
            }(t, e);
            throw new TypeError("Invalid attempt to destructure non-iterable instance")
        },
        a = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            return e.default = t, e
        }(r(3)),
        o = c(r(20)),
        i = c(r(1)),
        s = c(r(2));

    function c(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }
    var u = !0,
        l = ["#dbcdbd", "#e8b8a0", "#f2a385", "#f88d69", "#fc764f", "#fe5c34", "#ff3814"].reverse(),
        f = d3.select("body"),
        d = d3.select(".capital__chart"),
        p = d3.select(".capital__prose"),
        h = d.select("svg"),
        m = 20,
        y = 7,
        g = 12,
        v = 3,
        b = (0, o.default)(),
        x = 0,
        w = 0,
        _ = 0,
        E = 1,
        k = null,
        S = null,
        M = null,
        A = null,
        C = null,
        P = {
            lat: 42,
            lng: -72
        },
        T = null,
        O = {
            quality: 80,
            quantity: 20
        },
        N = {
            rank: d3.scaleLinear(),
            fill: d3.scaleQuantile(),
            angle: 0
        },
        j = d3.geoAlbersUsa().scale(1),
        L = d3.geoPath(),
        q = d3.zoom().scaleExtent([1, y]);

    function I(t) {
        var e = t.city,
            r = t.state;
        return "" + e.toLowerCase().replace(/\W/g, "") + r.toLowerCase().replace(/\W/g, "")
    }

    function D(t) {
        var e = t.toString();
        return t > 10 && t < 20 ? t + "th" : e.endsWith("1") ? t + "st" : e.endsWith("2") ? t + "nd" : e.endsWith("3") ? t + "rd" : t + "th"
    }

    function R() {
        var t = 1 / d3.event.transform.k,
            e = t * g,
            r = h.select(".g-map").attr("transform", d3.event.transform);
        r.selectAll("path").style("stroke-width", t + "px"), r.selectAll(".locator-text").style("font-size", e + "px").attr("x", t * v * 2), r.selectAll(".locator-circle").attr("r", t * v).attr("cy", t * -v / 2).style("stroke-width", t + "px")
    }

    function z() {}

    function U() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 500;
        h.transition().duration(t).call(q.transform, d3.zoomIdentity), d.select(".map-states").transition().duration(t).style("opacity", .5)
    }

    function H(t) {
        var e = t.city,
            r = t.down,
            a = t.zoomScale;
        d.transition().duration(250).style("opacity", 1);
        var o = j([e.lng, e.lat]),
            i = n(o, 2),
            s = i[0],
            c = i[1],
            u = r ? 3500 : 500,
            l = r ? d3.easeCubicInOut : d3.easeLinear,
            f = x / 2 - a * s,
            p = w / 2 - a * c,
            m = d3.zoomIdentity.translate(f, p).scale(a);
        h.transition().duration(u).ease(l).call(q.transform, m)
    }

    function V(t) {
        var e = h.select(".cities-container"),
            r = e.selectAll(".city").data(C, function(t) {
                return t.index
            }),
            a = r.enter().append("g").attr("class", "city").attr("transform", function(t) {
                var e = j([t.lng, t.lat]),
                    r = n(e, 2);
                return "translate(" + r[0] + ", " + r[1] + ")"
            });
        a.append("circle").attr("cx", 0).attr("cy", 0).attr("r", 0).style("fill", function(t) {
            return N.fill(t.rank)
        }).style("stroke", function(t) {
            return d3.color(N.fill(t.rank)).darker(.6)
        }), a.append("text").attr("class", "text--bg").attr("text-anchor", "middle").attr("y", function(t) {
            return -N.rank(t.rank) - g / 4
        }).style("display", function(t) {
            return t.rank < 10 ? "block" : "none"
        }).text(function(t) {
            return "#" + (t.rank + 1) + " " + t.city
        }), a.append("text").attr("class", "text--fg").attr("text-anchor", "middle").attr("y", function(t) {
            return -N.rank(t.rank) - g / 4
        }).style("display", function(t) {
            return t.rank < 10 ? "block" : "none"
        }).text(function(t) {
            return "#" + (t.rank + 1) + " " + t.city
        }), (r = a.merge(r)).select("circle").transition().duration(3e3).delay(function(e) {
            return e.rank * (t ? 60 : 20)
        }).attr("r", function(e) {
            return t ? N.rank(e.rank) * E : 0
        }), r.selectAll("text").transition().duration(t ? 3e3 : 1e3).delay(function(e) {
            return e.rank * (t ? 80 : 20)
        }).style("opacity", function(e) {
            return t ? 1 : 0
        }), e.transition().attr("transform", "translate(0,0) rotate(0)"), r.transition().attr("transform", function(t) {
            var e = j([t.lng, t.lat]),
                r = n(e, 2);
            return "translate(" + r[0] + ", " + r[1] + ")"
        })
    }

    function F() {
        _ = window.innerHeight, x = d.node().offsetWidth - 2 * m, w = _ - 2 * m, u = f.classed("is-full"), E = u ? 1 : .5
    }

    function B() {
        F(), h.attr("width", x + 2 * m).attr("height", w + 2 * m), h.select(".g-graphic").attr("transform", "translate(" + m + ", " + m + ")"), j.fitSize([x, w], A), L.projection(j), h.select(".state__border").attr("d", L), h.select(".map-custom").attr("transform", function() {
            var t = j([P.lng, P.lat]),
                e = n(t, 2);
            return "translate(" + e[0] + ", " + e[1] + ")"
        }), h.select(".map-best").attr("transform", function() {
            var t = j([T.lng, T.lat]),
                e = n(t, 2);
            return "translate(" + e[0] + ", " + e[1] + ")"
        }), u || (d3.selectAll(".prose__step").style("height", Math.floor(.9 * _) + "px"), d3.select(".prose__step:last-child").style("height", Math.floor(.6 * _) + "px")), b.resize()
    }

    function W(t) {
        var e = t.el,
            r = t.fadeIn,
            n = t.down,
            a = r ? 1 : 0,
            o = r ? 1 : 2,
            i = n ? 3e3 : 500,
            s = d3.transition().duration(i / o);
        h.select(e).transition(s).style("opacity", a)
    }

    function G(t) {
        var e = t.step,
            r = t.down;
        switch (e) {
            case "local":
                H({
                    city: P,
                    zoomScale: y,
                    down: r
                }), W({
                    el: ".map-custom",
                    fadeIn: !0,
                    down: r
                }), W({
                    el: ".map-best",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-cities",
                    fadeIn: !1,
                    down: r
                });
                break;
            case "best":
                H({
                    city: T,
                    zoomScale: y,
                    down: r
                }), W({
                    el: ".map-custom",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-best",
                    fadeIn: !0,
                    down: r
                }), W({
                    el: ".map-cities",
                    fadeIn: !1,
                    down: r
                });
                break;
            case "explanation":
                H({
                    city: T,
                    zoomScale: Math.floor(y / 2),
                    down: r
                }), W({
                    el: ".map-custom",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-best",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-cities",
                    fadeIn: !1,
                    down: r
                }), V(!1);
                break;
            case "everywhere":
                U(2e3), W({
                    el: ".map-custom",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-best",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-cities",
                    fadeIn: !0,
                    down: r
                }), W({
                    el: ".map-states",
                    fadeIn: !0,
                    down: r
                }), V(!0);
                break;
            case "rank":
                U(), V(!1), W({
                    el: ".map-custom",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-best",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-cities",
                    fadeIn: !0,
                    down: r
                }), W({
                    el: ".map-states",
                    fadeIn: !1,
                    down: r
                });
                break;
            default:
                U(), W({
                    el: ".map-custom",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-best",
                    fadeIn: !1,
                    down: r
                }), W({
                    el: ".map-cities",
                    fadeIn: !1,
                    down: r
                })
        }
    }
    e.default = {
        init: function(t) {
            k = t.usaData, S = t.breweryData, M = t.cityData;
            var e = i.default.init({
                cityData: M,
                breweryData: S,
                max: 50
            });
            C = i.default.weight({
                    data: e,
                    balance: O
                }).reverse(), T = C[49], F(),
                function() {
                    A = a.feature(k, k.objects.states);
                    var t = h.append("g").attr("class", "g-graphic").append("g").attr("class", "g-map");
                    t.append("g").attr("class", "map-states").append("path").datum(a.mesh(k, k.objects.states)).attr("class", "state__border"), t.append("g").attr("class", "map-cities").append("g").attr("class", "cities-container");
                    var e = t.append("g").attr("class", "map-custom");
                    e.append("circle").attr("class", "locator-circle").attr("cx", 0).attr("cy", -v / 2).attr("r", v), e.append("text").attr("alignment-baseline", "middle").attr("class", "locator-text").attr("y", 0).attr("x", 2 * v);
                    var r = t.append("g").attr("class", "map-best");
                    r.append("circle").attr("class", "locator-circle").attr("cx", 0).attr("cy", -v / 2).attr("r", v), r.append("text").attr("class", "locator-text").attr("alignment-baseline", "middle").attr("y", 0).attr("x", 2 * v), q.on("zoom", R).on("end", z)
                }(), N.rank.domain(d3.extent(C, function(t) {
                    return t.rank
                })).range([16, 2]), N.fill.domain(C.map(function(t) {
                    return t.rank
                })).range(l), B()
        },
        resize: B,
        setupScroll: function() {
            var t = d3.select(".intro__prompt");
            t.classed("is-reveal", !0), d3.select("main").classed("is-reveal", !0).style("height", "auto"), d3.select(".pudding-footer").classed("is-reveal", !0),
                function() {
                    var t, e, r = i.default.init({
                            cityData: M,
                            breweryData: S,
                            dist: 50,
                            nearby: 1
                        }),
                        n = i.default.weight({
                            data: r,
                            balance: O
                        }),
                        a = I(P),
                        o = n.find(function(t) {
                            return I(t) === a
                        }),
                        s = o || (t = n, (e = d3.scan(t, function(t, e) {
                            return Math.abs(t.lat - P.lat) + Math.abs(t.lng - P.lng) - (Math.abs(e.lat - P.lat) + Math.abs(e.lng - P.lng))
                        })) > -1 ? t[e] : null),
                        c = C.find(function(t) {
                            return t.index === s.index
                        });
                    if (s.index === T.index) p.select(".text--match-best").classed("is-visible", !0), p.select(".prose__step").remove();
                    else {
                        var u = p.select(".text--best");
                        u.classed("is-visible", !0), u.select(".place").text(T.city + ", " + T.state);
                        var l = p.select(".text--local");
                        l.classed("is-visible", !0);
                        var f = function(t) {
                                var e = t.editorialMatch,
                                    r = t.exactMatch;
                                return "US" === P.origin ? e && r ? "<strong>" + (e.rank < 10 ? "Almost!" : "Not quite.") + "</strong> After" : r ? "<strong>" + (r.rank < 10 ? "Almost!" : "Not quite.") + "</strong> After" : "<strong>Nope.</strong> It doesnвЂ™t even make the list. But after" : "You might think our biggest city, New York City, is the best, but not quite. After"
                            }({
                                editorialMatch: c,
                                exactMatch: o,
                                nearestMatch: s
                            }),
                            d = function(t) {
                                var e = t.exactMatch,
                                    r = t.nearestMatch;
                                return e ? e.city : "nearby " + r.city + ", " + r.state
                            }({
                                editorialMatch: c,
                                exactMatch: o,
                                nearestMatch: s
                            }),
                            m = "\n\t\t\t" + f + "\n\t\t\t analyzing over 1,600 breweries, \n\t\t\t" + function(t) {
                                var e = t.editorialMatch,
                                    r = t.nearestMatch,
                                    n = t.nearbyText;
                                return e ? n + " comes in " + D(e.rank + 1) + " out of the 800+ biggest cities in the country." : n + " comes in " + D(r.rank + 1) + " out of the 800+ biggest cities in the country."
                            }({
                                editorialMatch: c,
                                exactMatch: o,
                                nearestMatch: s,
                                nearbyText: d
                            }) + "\n\t\t";
                        l.html(m)
                    }
                    P.lat = s.lat, P.lng = s.lng, P.city = s.city, h.select(".map-custom text").text(P.city), h.select(".map-best text").text(T.city), B()
                }(), b.setup({
                    step: ".prose__step",
                    offset: .33
                }).onStepEnter(function(t) {
                    var e = t.element,
                        r = t.direction;
                    G({
                        step: d3.select(e).attr("data-step"),
                        down: "down" === r
                    })
                }).onStepExit(function(t) {
                    var e = t.element,
                        r = t.direction;
                    if (window.scrollY > 0) {
                        var n = d3.select(e).attr("data-step"),
                            a = "down" === r;
                        "Santa Rosa" !== P.city || "California" !== P.state || "best" !== n || a || G({
                            step: "default",
                            down: a
                        }), "local" !== n || a || G({
                            step: "default",
                            down: a
                        }), "rank" === n && G({
                            step: n,
                            down: a
                        })
                    }
                }).onContainerEnter(function(t) {
                    "up" === t.direction && d.classed("is-bottom", !1)
                }).onContainerExit(function(t) {
                    var e = t.direction;
                    window.scrollY > 0 && "down" === e && (d.classed("is-bottom", !0), s.default.send({
                        category: "prose",
                        action: "exit",
                        once: !0
                    }))
                });
            var e = (0, o.default)();
            e.setup({
                step: ".capital__prose",
                offset: .95
            }).onStepEnter(function() {
                t.classed("is-reveal", !1), e.disable()
            })
        },
        hed: function(t) {
            var e = t.city,
                r = t.region_name,
                n = t.country_code,
                a = t.latitude,
                o = t.longitude,
                i = e ? n + " | " + r + " | " + e : "unavailable";
            s.default.send({
                category: "custom location",
                action: i,
                once: !0
            });
            var c = null;
            "US" === n && e ? c = "Could " + (P = {
                city: e,
                lat: a,
                lng: o,
                state: r,
                origin: n
            }).city + ", " + P.state + ", really be the microbrew capital of the US?" : (P = {
                city: "New York",
                lat: 40,
                lng: -72,
                state: "New York",
                origin: null
            }, c = "But what city is the microbrew capital of the US?"), d3.select(".intro__hed span").text(c).classed("is-visible", !0)
        }
    }
}, function(t, e, r) {
    t.exports = function() {
        "use strict";

        function t(t) {
            for (var e = t.length, r = [], n = 0; n < e; n += 1) r.push(t[n]);
            return r
        }

        function e(t) {
            return t instanceof Element ? t : "string" == typeof t ? document.querySelector(t) : null
        }

        function r(t) {
            return "scrollama__debug-step--" + t.id + "-" + t.i
        }

        function n(t) {
            return "scrollama__debug-offset--" + t.id
        }

        function a(t) {
            var e = t.id,
                a = t.offsetVal,
                o = t.stepEl,
                i = o[0].getAttribute("class");
            o.forEach(function(t, n) {
                    return function(t) {
                        var e = r({
                                id: t.id,
                                i: t.i
                            }),
                            n = document.createElement("div");
                        n.setAttribute("id", e + "_above"), n.setAttribute("class", "scrollama__debug-step"), n.style.position = "fixed", n.style.left = "0", n.style.width = "100%", n.style.backgroundImage = "repeating-linear-gradient(45deg, green 0, green 2px, white 0, white 40px)", n.style.border = "2px solid green", n.style.opacity = "0.33", n.style.zIndex = "9999", n.style.display = "none", document.body.appendChild(n);
                        var a = document.createElement("div");
                        a.setAttribute("id", e + "_below"), a.setAttribute("class", "scrollama__debug-step"), a.style.position = "fixed", a.style.left = "0", a.style.width = "100%", a.style.backgroundImage = "repeating-linear-gradient(135deg, orange 0, orange 2px, white 0, white 40px)", a.style.border = "2px solid orange", a.style.opacity = "0.33", a.style.zIndex = "9999", a.style.display = "none", document.body.appendChild(a)
                    }({
                        id: e,
                        i: n
                    })
                }),
                function(t) {
                    var e = t.id,
                        r = t.offsetVal,
                        a = t.stepClass,
                        o = document.createElement("div");
                    o.setAttribute("id", n({
                        id: e
                    })), o.setAttribute("class", "scrollama__debug-offset"), o.style.position = "fixed", o.style.left = "0", o.style.width = "100%", o.style.height = "0px", o.style.borderTop = "2px dashed black", o.style.zIndex = "9999";
                    var i = document.createElement("p");
                    i.innerText = '".' + a + '" trigger: ' + r, i.style.fontSize = "12px", i.style.fontFamily = "monospace", i.style.color = "black", i.style.margin = "0", i.style.padding = "6px", o.appendChild(i), document.body.appendChild(o)
                }({
                    id: e,
                    offsetVal: a,
                    stepClass: i
                })
        }

        function o(t) {
            var e = t.id,
                a = t.stepOffsetHeight,
                o = t.offsetMargin;
            t.offsetVal, a.forEach(function(t, n) {
                    return function(t) {
                        var e = t.h,
                            n = t.offsetMargin,
                            a = r({
                                id: t.id,
                                i: t.i
                            }),
                            o = document.querySelector("#" + a + "_above");
                        o.style.height = e + "px", o.style.top = n - e + "px";
                        var i = document.querySelector("#" + a + "_below");
                        i.style.height = e + "px", i.style.top = n + "px"
                    }({
                        id: e,
                        h: t,
                        i: n,
                        offsetMargin: o
                    })
                }),
                function(t) {
                    var e = t.offsetMargin,
                        r = n({
                            id: t.id
                        });
                    document.querySelector("#" + r).style.top = e + "px"
                }({
                    id: e,
                    offsetMargin: o
                })
        }

        function i(t) {
            var e = t.id,
                n = t.index,
                a = t.state,
                o = r({
                    id: e,
                    i: n
                }),
                i = document.querySelector("#" + o + "_above"),
                s = document.querySelector("#" + o + "_below"),
                c = "enter" === a ? "block" : "none";
            i && (i.style.display = c), s && (s.style.display = c)
        }
        return function() {
            var r = 1,
                n = {},
                s = {},
                c = null,
                u = null,
                l = null,
                f = null,
                d = 0,
                p = 0,
                h = 0,
                m = 0,
                y = null,
                g = null,
                v = null,
                b = !1,
                x = !1,
                w = !1,
                _ = !1,
                E = 0,
                k = !1,
                S = !1,
                M = null,
                A = null,
                C = -1,
                P = null,
                T = [];

            function O(t) {
                var e = 0;
                if (t.offsetParent)
                    do {
                        e += t.offsetTop, t = t.offsetParent
                    } while (t);
                return e < 0 ? 0 : e
            }

            function N(t) {
                return +t.getAttribute("data-scrollama-index")
            }

            function j() {
                window.pageYOffset > C ? P = "down" : window.pageYOffset < C && (P = "up"), C = window.pageYOffset
            }

            function L() {
                var t, e;
                h = window.innerHeight, t = document.body, e = document.documentElement, m = Math.max(t.scrollHeight, t.offsetHeight, e.clientHeight, e.scrollHeight, e.offsetHeight), v = u ? u.getBoundingClientRect() : null, p = d * h, y = l ? l.map(function(t) {
                    return t.offsetHeight
                }) : [], g = l ? l.map(O) : [], x && b && $(), w && o({
                    id: f,
                    stepOffsetHeight: y,
                    offsetMargin: p,
                    offsetVal: d
                })
            }

            function q(t) {
                t && !x ? (b && $(), x = !0) : t || (s.top && s.top.disconnect(), s.bottom && s.bottom.disconnect(), s.stepAbove && s.stepAbove.forEach(function(t) {
                    return t.disconnect()
                }), s.stepBelow && s.stepBelow.forEach(function(t) {
                    return t.disconnect()
                }), s.stepProgress && s.stepProgress.forEach(function(t) {
                    return t.disconnect()
                }), s.viewportAbove && s.viewportAbove.forEach(function(t) {
                    return t.disconnect()
                }), s.viewportBelow && s.viewportBelow.forEach(function(t) {
                    return t.disconnect()
                }), x = !1)
            }

            function I(t, e) {
                if ("above" === e)
                    for (var r = 0; r < t; r++) {
                        var n = M[r];
                        "enter" === n.state && R(l[r]), "up" === n.direction && (D(l[r], "down"), R(l[r]))
                    } else if ("below" === e)
                        for (var a = M.length - 1; a > t; a--) {
                            var o = M[a];
                            "enter" === o.state && R(l[a]), "down" === o.direction && (D(l[a], "up"), R(l[a]))
                        }
            }

            function D(t, e) {
                void 0 === e && (e = !0);
                var r = N(t),
                    a = {
                        element: t,
                        index: r,
                        direction: P
                    };
                M[r].direction = P, M[r].state = "enter", k && e && "down" === P && I(r, "above"), k && e && "up" === P && I(r, "below"), n.stepEnter && "function" == typeof n.stepEnter && !T[r] && (n.stepEnter(a, M), w && i({
                    id: f,
                    index: r,
                    state: "enter"
                }), S && (T[r] = !0)), _ && z(t, "down" === P ? 0 : 1)
            }

            function R(t) {
                var e = N(t),
                    r = {
                        element: t,
                        index: e,
                        direction: P
                    };
                M[e].direction = P, M[e].state = "exit", _ && z(t, "down" === P ? 1 : 0), n.stepExit && "function" == typeof n.stepExit && (n.stepExit(r, M), w && i({
                    id: f,
                    index: e,
                    state: "exit"
                }))
            }

            function z(t, e) {
                var r = {
                    element: t,
                    index: N(t),
                    progress: e
                };
                n.stepProgress && "function" == typeof n.stepProgress && n.stepProgress(r)
            }

            function U() {
                var t = {
                    direction: P
                };
                A.direction = P, A.state = "enter", n.containerEnter && "function" == typeof n.containerEnter && n.containerEnter(t)
            }

            function H() {
                var t = {
                    direction: P
                };
                A.direction = P, A.state = "exit", n.containerExit && "function" == typeof n.containerExit && n.containerExit(t)
            }

            function V(t) {
                j(), t.forEach(function(t) {
                    var e = t.isIntersecting,
                        n = t.boundingClientRect,
                        a = t.target,
                        o = n.bottom,
                        i = n.height,
                        s = o - p,
                        c = N(a),
                        u = M[c];
                    s >= -r && (e && "down" === P && "enter" !== u.state ? D(a, P) : e || "up" !== P || "enter" !== u.state ? !e && s >= i && "down" === P && "enter" === u.state && R(a) : R(a))
                })
            }

            function F(t) {
                j(), t.forEach(function(t) {
                    var e = t.isIntersecting,
                        n = t.boundingClientRect,
                        a = t.target,
                        o = n.bottom,
                        i = n.height,
                        s = o - p,
                        c = N(a),
                        u = M[c];
                    s >= -r && s < i && e && "up" === P && "enter" !== u.state ? D(a, P) : s <= r && !e && "down" === P && "enter" === u.state && R(a)
                })
            }

            function B(t) {
                j(), t.forEach(function(t) {
                    var e = t.isIntersecting,
                        r = t.target,
                        n = N(r),
                        a = M[n];
                    e && "down" === P && "enter" !== a.state && "down" !== a.direction && (D(r, "down"), R(r))
                })
            }

            function W(t) {
                j(), t.forEach(function(t) {
                    var e = t.isIntersecting,
                        r = t.target,
                        n = N(r),
                        a = M[n];
                    e && "up" === P && "enter" !== a.state && "up" !== a.direction && (D(r, "up"), R(r))
                })
            }

            function G(t) {
                j(), t.forEach(function(t) {
                    var e = t.isIntersecting,
                        n = t.intersectionRatio,
                        a = t.boundingClientRect,
                        o = t.target,
                        i = a.bottom;
                    e && i - p >= -r && z(o, +n.toFixed(3))
                })
            }

            function X(t) {
                j();
                var e = t[0],
                    n = e.isIntersecting,
                    a = e.boundingClientRect;
                (a.top, a.bottom) > -r && (n ? U() : "enter" === A.state && H())
            }

            function Y(t) {
                j();
                var e = t[0],
                    n = e.isIntersecting;
                e.boundingClientRect.top < r && (n ? U() : "enter" === A.state && H())
            }

            function $() {
                s.viewportAbove && s.viewportAbove.forEach(function(t) {
                    return t.disconnect()
                }), s.viewportAbove = l.map(function(t, e) {
                    var r = g[e],
                        n = -(h - p + y[e]),
                        a = new IntersectionObserver(B, {
                            root: null,
                            rootMargin: r + "px 0px " + n + "px 0px",
                            threshold: 0
                        });
                    return a.observe(t), a
                }), s.viewportBelow && s.viewportBelow.forEach(function(t) {
                    return t.disconnect()
                }), s.viewportBelow = l.map(function(t, e) {
                    var r = -(p + y[e]),
                        n = m - g[e] - y[e] - p,
                        a = new IntersectionObserver(W, {
                            root: null,
                            rootMargin: r + "px 0px " + n + "px 0px",
                            threshold: 0
                        });
                    return a.observe(t), a
                }), s.stepAbove && s.stepAbove.forEach(function(t) {
                    return t.disconnect()
                }), s.stepAbove = l.map(function(t, e) {
                    var r = y[e],
                        n = new IntersectionObserver(V, {
                            root: null,
                            rootMargin: r + "px 0px " + (-h + p) + "px 0px",
                            threshold: 0
                        });
                    return n.observe(t), n
                }), s.stepBelow && s.stepBelow.forEach(function(t) {
                    return t.disconnect()
                }), s.stepBelow = l.map(function(t, e) {
                    var r = -p,
                        n = m - h + y[e] + p,
                        a = new IntersectionObserver(F, {
                            root: null,
                            rootMargin: r + "px 0px " + n + "px 0px",
                            threshold: 0
                        });
                    return a.observe(t), a
                }), _ && (s.stepProgress && s.stepProgress.forEach(function(t) {
                    return t.disconnect()
                }), s.stepProgress = l.map(function(t, e) {
                    var r = y[e] - p + "px 0px " + (-h + p) + "px 0px",
                        n = function(t) {
                            for (var e = Math.ceil(t / E), r = [], n = 1 / e, a = 0; a < e; a++) r.push(a * n);
                            return r
                        }(y[e]),
                        a = new IntersectionObserver(G, {
                            root: null,
                            rootMargin: r,
                            threshold: n
                        });
                    return a.observe(t), a
                })), c && u && (function() {
                    s.top && s.top.unobserve(c);
                    var t = {
                        root: null,
                        rootMargin: h + "px 0px -" + h + "px 0px",
                        threshold: 0
                    };
                    s.top = new IntersectionObserver(X, t), s.top.observe(c)
                }(), function() {
                    s.bottom && s.bottom.unobserve(c);
                    var t = {
                        root: null,
                        rootMargin: "-" + v.height + "px 0px " + v.height + "px 0px",
                        threshold: 0
                    };
                    s.bottom = new IntersectionObserver(Y, t), s.bottom.observe(c)
                }())
            }
            var Q = {
                setup: function(r) {
                    var n = r.container,
                        o = r.graphic,
                        i = r.step,
                        s = r.offset;
                    void 0 === s && (s = .5);
                    var p = r.progress;
                    void 0 === p && (p = !1);
                    var h = r.threshold;
                    void 0 === h && (h = 4);
                    var m = r.debug;
                    void 0 === m && (m = !1);
                    var y = r.order;
                    void 0 === y && (y = !0);
                    var g, v, x, C, P, T = r.once;
                    return void 0 === T && (T = !1), v = (g = "abcdefghijklmnopqrstuv").length, x = (new Date).getTime(), f = "" + [0, 0, 0].map(function(t) {
                        return g[Math.floor(Math.random() * v)]
                    }).join("") + x, C = i, void 0 === P && (P = document), l = "string" == typeof C ? t(P.querySelectorAll(C)) : C instanceof NodeList ? t(C) : C instanceof Array ? C : [], c = n ? e(n) : null, u = o ? e(o) : null, l.length ? (w = m, _ = p, k = y, S = T, Q.offsetTrigger(s), E = Math.max(1, +h), b = !0, w && a({
                        id: f,
                        stepEl: l,
                        offsetVal: d
                    }), l.forEach(function(t, e) {
                        return t.setAttribute("data-scrollama-index", e)
                    }), M = l.map(function() {
                        return {
                            direction: null,
                            state: null
                        }
                    }), A = {
                        direction: null,
                        state: null
                    }, L(), q(!0), Q) : (console.error("scrollama error: no step elements"), Q)
                },
                resize: function() {
                    return L(), Q
                },
                enable: function() {
                    return q(!0), Q
                },
                disable: function() {
                    return q(!1), Q
                },
                destroy: function() {
                    q(!1), Object.keys(n).forEach(function(t) {
                        return n[t] = null
                    }), Object.keys(s).forEach(function(t) {
                        return s[t] = null
                    })
                },
                offsetTrigger: function(t) {
                    return t && (isNaN(t), 1) ? (d = Math.min(Math.max(0, t), 1), Q) : d
                },
                onStepEnter: function(t) {
                    return n.stepEnter = t, Q
                },
                onStepExit: function(t) {
                    return n.stepExit = t, Q
                },
                onStepProgress: function(t) {
                    return n.stepProgress = t, Q
                },
                onContainerEnter: function(t) {
                    return n.containerEnter = t, Q
                },
                onContainerExit: function(t) {
                    return n.containerExit = t, Q
                }
            };
            return Q
        }
    }()
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n = function(t, e) {
            if (Array.isArray(t)) return t;
            if (Symbol.iterator in Object(t)) return function(t, e) {
                var r = [],
                    n = !0,
                    a = !1,
                    o = void 0;
                try {
                    for (var i, s = t[Symbol.iterator](); !(n = (i = s.next()).done) && (r.push(i.value), !e || r.length !== e); n = !0);
                } catch (t) {
                    a = !0, o = t
                } finally {
                    try {
                        !n && s.return && s.return()
                    } finally {
                        if (a) throw o
                    }
                }
                return r
            }(t, e);
            throw new TypeError("Invalid attempt to destructure non-iterable instance")
        },
        a = function(t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t)
                for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
            return e.default = t, e
        }(r(22)),
        o = s(r(1)),
        i = s(r(2));

    function s(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }
    var c = !0,
        u = !1,
        l = d3.select("body"),
        f = d3.select(".graphic__explore"),
        d = d3.select(".explore__chart"),
        p = d.select("svg"),
        h = ["#dbcdbd", "#e8b8a0", "#f2a385", "#f88d69", "#fc764f", "#fe5c34", "#ff3814"].reverse(),
        m = 20,
        y = 12,
        g = 160,
        v = 0,
        b = 0,
        x = 0,
        w = 0,
        _ = 0,
        E = null,
        k = null,
        S = null,
        M = null,
        A = {
            quality: 80,
            quantity: 20
        },
        C = {
            quality: d3.scaleLinear(),
            quantity: d3.scaleLinear(),
            rank: d3.scaleLinear(),
            fill: d3.scaleQuantile()
        },
        P = d3.voronoi();

    function T(t) {
        var e = t.breweryNames,
            r = t.rank,
            n = t.index;
        p.selectAll(".row").classed("is-connected", !1).transition().duration(100).attr("transform", function(t) {
            return "translate(0, " + t.rank * y * 1.5 + ")"
        });
        var a = p.select(".row-" + n),
            o = p.select(".table__brews");
        if (a.empty()) o.classed("is-visible", !1);
        else {
            var i = -y;
            a.classed("is-connected", !0).transition().attr("transform", function(t) {
                    return "translate(" + i + ", " + t.rank * y * 1.5 + ")"
                }),
                function(t) {
                    var e = t.breweryNames,
                        r = t.rank,
                        n = p.select(".table__brews"),
                        a = n.selectAll(".brew").data(e);
                    a.exit().remove();
                    var o = a.enter().append("g").attr("class", "brew");
                    o.append("text").style("font-size", y);
                    var i = o.merge(a);
                    i.attr("transform", function(t, e) {
                        return "translate(0, " + (e + 1) * y * 1.5 + ")"
                    }), i.select("text").text(function(t) {
                        return t
                    });
                    var s = r * y * 1.5;
                    n.classed("is-visible", c), n.transition().ease(d3.easeLinear).duration(100).attr("transform", "translate(" + (g + .5 * y) + ", " + s + ")")
                }({
                    breweryNames: e,
                    rank: r
                })
        }
    }

    function O(t) {
        var e = t.index,
            r = p.select(".row-" + e),
            n = p.select(".table__brews");
        r.classed("is-connected", !1).transition().attr("transform", function(t) {
            return "translate(0, " + t.rank * y * 1.5 + ")"
        }), n.classed("is-visible", !1)
    }

    function N(t) {
        var e = p.select(".g-cities-plot"),
            r = e.select(".city-" + t.index);
        e.selectAll(".city").classed("is-faded", !0).classed("is-active", !1), r.classed("is-active", !0).raise();
        var n = p.select(".g-tooltip");
        n.selectAll(".tooltip__text").text(t.city + ", " + t.stateAbbr), n.selectAll(".tooltip__quality").text("rating: " + t.grade), n.selectAll(".tooltip__quantity").text("breweries: " + t.count);
        var a = C.quantity(t.count),
            o = C.quality(t.score),
            i = (C.rank(t.rank), "translate(" + a + ", " + o + ")"),
            s = "rotate(" + C.angle + ")";
        n.attr("transform", i + " " + s).classed("is-visible", !0)
    }

    function j(t) {
        var e = p.select(".g-cities-plot"),
            r = e.select(".city-" + t.index);
        e.selectAll(".city").classed("is-faded", !1);
        var n = p.select(".g-tooltip");
        r.classed("is-active", !1), n.classed("is-visible", !1)
    }

    function L() {
        var t = d3.select(this),
            e = "Table" === t.text();
        d3.select(this.parentNode).selectAll("li").classed("is-selected", !1), t.classed("is-selected", !0), p.select(".g-table").classed("is-hidden", !e), p.select(".table__title").classed("is-hidden", !e), p.select(".g-cities").classed("is-hidden", e), p.select(".target").classed("is-hidden", e)
    }

    function q() {
        var t = p.select(".g-cities"),
            e = t.select(".g-cities-plot").selectAll(".city").data(M, function(t) {
                return t.index
            }),
            r = e.enter().append("g").attr("class", function(t) {
                return "city city-" + t.index
            });
        r.append("circle").attr("cx", 0).attr("cy", 0).attr("r", 0), e.exit().remove(), (e = r.merge(e)).select("circle").attr("r", function(t) {
            return C.rank(t.rank)
        }).style("fill", function(t) {
            return C.fill(t.rank)
        }).style("stroke", function(t) {
            return d3.color(C.fill(t.rank)).darker(.6)
        });
        var a = p.select(".g-table"),
            o = a.select(".table__rows"),
            i = p.select(".table__title"),
            s = o.selectAll(".row").data(M.slice(0, _), function(t) {
                return t.index
            });
        s.each(function(t) {
            return t.newbie = !1
        });
        var u = s.enter().append("g").attr("class", function(t) {
            return "row row-" + t.index
        }).attr("transform", "translate(0, " + b + ")").each(function(t) {
            return t.newbie = !0
        });
        u.append("text").style("font-size", y), u.append("rect").attr("x", 0).attr("y", 1.25 * -y).attr("height", 1.5 * y).on("mouseenter", function(t) {
            c && (T(t), N(t))
        }).on("mouseout", function(t) {
            O(t), j(t)
        }), s.exit().transition().style("opacity", 0).attr("transform", "translate(" + v / 4 + ", " + b / 2 + ")").remove(), s = u.merge(s);
        var l = c ? .5 * v - w - 3 * m : .5 * v - w / 2,
            f = c ? .5 * v + 2 * m : 0,
            d = C.quality.range()[0],
            h = "translate(" + (l + w / 2) + ", " + (w - d + 3 * m) + ") rotate(" + -C.angle + " 0 " + d + ")";
        t.attr("transform", h), p.select(".target").attr("transform", "translate(" + (l + w / 2) + "," + 3 * m + ")"), e.attr("transform", function(t) {
            return "translate(" + C.quantity(t.count) + ", " + C.quality(t.score) + ")"
        }), t.select(".axis--x line").attr("x1", 0).attr("y1", 0).attr("x2", C.quantity.range()[1] / 1).attr("y2", 0), t.select(".axis--y line").attr("x1", 0).attr("y1", 0).attr("x2", -C.quality.range()[0] / 1).attr("y2", 0), t.select(".axis--y").attr("transform", "translate(" + -m + "," + d + ") rotate(90)"), t.select(".axis--x").attr("transform", "translate(0," + (d + m) + ")"), a.attr("transform", "translate(" + f + ", " + 3 * m + ")"), i.attr("transform", "translate(" + f + ", " + 3 * m + ")"), d3.transition().duration(200).ease(d3.easeLinear), s.transition().duration(function(t, e, r) {
            var a = function(t) {
                    var e = document.createElementNS("http://www.w3.org/2000/svg", "g");
                    e.setAttributeNS(null, "transform", t);
                    var r = e.transform.baseVal.consolidate().matrix;
                    return [r.e, r.f]
                }(d3.select(r[e]).attr("transform")),
                o = n(a, 2),
                i = (o[0], o[1]),
                s = Math.min(t.rank * y * 1.5, 1e3);
            return s < y ? 20 : 100 + 2 * (i - s)
        }).delay(function(t) {
            return 30 * t.rank
        }).ease(d3.easeLinear).attr("transform", function(t) {
            return "translate(0, " + t.rank * y * 1.5 + ")"
        }).style("opacity", 1), s.select("text").text(function(t) {
            return d3.format("0>2")(t.rank + 1) + ". " + t.city + ", " + t.stateAbbr
        }).style("fill", function(t) {
            return C.fill(t.rank)
        }).each(function() {
            var t = this.getBoundingClientRect().width;
            d3.select(this.parentNode).select("rect").attr("width", t)
        });
        var g = p.select(".g-voronoi").selectAll("path").data(P.polygons(M)),
            x = g.enter().append("path");
        g.merge(x).attr("d", function(t) {
            return t ? "M" + t.join("L") + "Z" : null
        }).on("mouseenter", function(t) {
            N(t.data), c && T(t.data)
        }).on("mouseout", function(t) {
            j(t.data), c && O(t.data)
        })
    }

    function I() {
        var t = f.select(".explore__filter").node().getBoundingClientRect().height;
        x = Math.floor(window.innerHeight - 1.5 * t), v = d.node().offsetWidth - 2 * m, b = c ? x - 2 * m : x + .5 * t, c = l.classed("is-full")
    }

    function D() {
        I(), u && (p.attr("width", v + 2 * m).attr("height", b + 2 * m), p.select(".g-graphic").attr("transform", "translate(" + m + ", " + m + ")"), _ = 5 * Math.floor((b / (1.5 * y) - 5) / 5), R(), q(), c ? p.selectAll(".is-hidden").classed("is-hidden", !1) : (p.select(".g-table").classed("is-hidden", !0), p.select(".table__title").classed("is-hidden", !0), p.select(".g-cities").classed("is-hidden", !1), p.select(".target").classed("is-hidden", !1), f.selectAll(".explore__toggle li").classed("is-selected", function(t, e) {
            return 0 === e
        })))
    }

    function R() {
        var t = function(t) {
                var e = t.x,
                    r = t.y,
                    n = e * e,
                    a = r * r;
                return Math.sqrt(n + a)
            }({
                x: A.quantity,
                y: A.quality
            }),
            e = c ? 5 : 0,
            r = c ? 2 : 1.2;
        w = Math.min(v / r, b) - m * e;
        var n = A.quantity / t * w,
            a = A.quality / t * w;
        C.quality.domain(d3.extent(M, function(t) {
            return t.score
        })).range([a, 0]), C.quantity.domain(d3.extent(M, function(t) {
            return t.count
        })).range([0, n]), C.rank.domain(d3.extent(M, function(t) {
            return t.rank
        })).range([16, 2]), C.fill.domain(M.map(function(t) {
            return t.rank
        })).range(h);
        var o = Math.acos(A.quantity / t);
        C.angle = 90 - 180 * o / Math.PI, P.x(function(t) {
            return C.quantity(t.count)
        }).y(function(t) {
            return C.quality(t.score)
        }).extent([
            [-m, -m],
            [n + m, a + m]
        ])
    }
    e.default = {
        init: function(t) {
            E = t.breweryData, k = t.cityData, S = o.default.init({
                    cityData: k,
                    breweryData: E,
                    max: 50
                }), M = o.default.weight({
                    data: S,
                    balance: A
                }),
                function() {
                    var t, e;
                    I(),
                        function() {
                            var t = p.append("g").attr("class", "g-graphic");
                            t.append("line").attr("class", "connector");
                            var e = t.append("g").attr("class", "target"),
                                r = t.append("g").attr("class", "g-cities");
                            r.append("g").attr("class", "g-cities-plot"), t.append("text").attr("class", "table__title").attr("alignment-baseline", "baseline").attr("y", 1.75 * -y).text("Best cities");
                            var n = t.append("g").attr("class", "g-table"),
                                a = r.append("g").attr("class", "cities-axis"),
                                o = r.append("g").attr("class", "g-tooltip");
                            o.append("text").attr("class", "tooltip__text shadow").attr("text-anchor", "middle").attr("alignment-baseline", "middle"), o.append("text").attr("class", "tooltip__text").attr("text-anchor", "middle").attr("alignment-baseline", "middle"), o.append("text").attr("class", "tooltip__quality shadow").attr("text-anchor", "middle").attr("alignment-baseline", "middle").attr("y", 1.2 * y), o.append("text").attr("class", "tooltip__quality").attr("text-anchor", "middle").attr("alignment-baseline", "middle").attr("y", 1.2 * y), o.append("text").attr("class", "tooltip__quantity shadow").attr("text-anchor", "middle").attr("alignment-baseline", "middle").attr("y", 2.4 * y), o.append("text").attr("class", "tooltip__quantity").attr("text-anchor", "middle").attr("alignment-baseline", "middle").attr("y", 2.4 * y), r.append("g").attr("class", "g-voronoi"), e.append("circle").attr("cx", 0).attr("cy", 0).attr("r", 3);
                            var i = e.append("text");
                            i.append("tspan").attr("text-anchor", "middle").attr("x", 0).attr("y", 2.75 * -y).text("Closer to here"), i.append("tspan").attr("text-anchor", "middle").attr("x", 0).attr("y", 1.5 * -y).text("the better");
                            var s = a.append("g").attr("class", "axis--x");
                            s.append("text").html("Quantity &rarr;").attr("text-anchor", "start").attr("alignment-baseline", "hanging").attr("y", y / 2), s.append("line");
                            var c = a.append("g").attr("class", "axis--y");
                            c.append("text").html("&larr; Quality").attr("text-anchor", "end").attr("alignment-baseline", "hanging").attr("y", y / 2), c.append("line");
                            var u = n.append("g").attr("class", "table__brews");
                            n.append("g").attr("class", "table__rows"), u.append("text").style("font-size", y).attr("class", "brews__label").text("Top breweries"), u.append("line").attr("x1", -g).attr("y1", .25 * y).attr("x2", .5 * -y).attr("y2", .25 * y), u.append("line").attr("x1", .5 * -y).attr("y1", 1.25 * -y).attr("x2", .5 * -y).attr("y2", .25 * y), u.append("line").attr("x1", .5 * -y).attr("y1", 1.25 * -y).attr("x2", .67 * g).attr("y2", 1.25 * -y)
                        }(), t = f.select(".explore__slider"), a.create(t.node(), {
                            start: 20,
                            connect: [!0, !1],
                            step: 1,
                            range: {
                                min: 0,
                                max: 100
                            }
                        }), t.node().noUiSlider.on("update", function() {
                            A.quantity = +this.get(), A.quality = 100 - A.quantity, M = o.default.weight({
                                data: S,
                                balance: A
                            }).slice(0, 100), f.select(".result__quality").text(A.quality + "%"), f.select(".result__quantity").text(A.quantity + "%"), R(), q(), c && O({
                                index: M[0].index
                            }), j(S[0])
                        }), (e = f.selectAll("select")).on("change", function() {
                            var t = {};
                            e.each(function() {
                                var e = d3.select(this).attr("data-col"),
                                    r = this.value;
                                t[e] = r
                            });
                            var r = t.nearby,
                                n = t.dist,
                                a = t.abv;
                            S = o.default.init({
                                cityData: k,
                                breweryData: E,
                                nearby: r,
                                dist: n,
                                abv: a
                            }), M = o.default.weight({
                                data: S,
                                balance: A
                            }).slice(0, 100), R(), q(), i.default.send({
                                category: "explore",
                                action: "filter",
                                once: !0
                            })
                        }), f.selectAll(".explore__toggle li").on("click", L), u = !0, D(), R(), q(), c && T(M[0]), N(M[0])
                }()
        },
        resize: D
    }
}, function(t, e, r) {
    var n, a; /*! nouislider - 11.1.0 - 2018-04-02 11:18:13 */
    void 0 === (a = "function" == typeof(n = function() {
        "use strict";
        var t = "11.1.0";

        function e(t) {
            return null !== t && void 0 !== t
        }

        function r(t) {
            t.preventDefault()
        }

        function n(t) {
            return "number" == typeof t && !isNaN(t) && isFinite(t)
        }

        function a(t, e, r) {
            r > 0 && (c(t, e), setTimeout(function() {
                u(t, e)
            }, r))
        }

        function o(t) {
            return Math.max(Math.min(t, 100), 0)
        }

        function i(t) {
            return Array.isArray(t) ? t : [t]
        }

        function s(t) {
            var e = (t = String(t)).split(".");
            return e.length > 1 ? e[1].length : 0
        }

        function c(t, e) {
            t.classList ? t.classList.add(e) : t.className += " " + e
        }

        function u(t, e) {
            t.classList ? t.classList.remove(e) : t.className = t.className.replace(new RegExp("(^|\\b)" + e.split(" ").join("|") + "(\\b|$)", "gi"), " ")
        }

        function l(t) {
            var e = void 0 !== window.pageXOffset,
                r = "CSS1Compat" === (t.compatMode || "");
            return {
                x: e ? window.pageXOffset : r ? t.documentElement.scrollLeft : t.body.scrollLeft,
                y: e ? window.pageYOffset : r ? t.documentElement.scrollTop : t.body.scrollTop
            }
        }

        function f(t, e) {
            return 100 / (e - t)
        }

        function d(t, e) {
            return 100 * e / (t[1] - t[0])
        }

        function p(t, e) {
            for (var r = 1; t >= e[r];) r += 1;
            return r
        }

        function h(e, r, a) {
            var o;
            if ("number" == typeof r && (r = [r]), !Array.isArray(r)) throw new Error("noUiSlider (" + t + "): 'range' contains invalid value.");
            if (!n(o = "min" === e ? 0 : "max" === e ? 100 : parseFloat(e)) || !n(r[0])) throw new Error("noUiSlider (" + t + "): 'range' value isn't numeric.");
            a.xPct.push(o), a.xVal.push(r[0]), o ? a.xSteps.push(!isNaN(r[1]) && r[1]) : isNaN(r[1]) || (a.xSteps[0] = r[1]), a.xHighestCompleteStep.push(0)
        }

        function m(t, e, r) {
            if (!e) return !0;
            r.xSteps[t] = d([r.xVal[t], r.xVal[t + 1]], e) / f(r.xPct[t], r.xPct[t + 1]);
            var n = (r.xVal[t + 1] - r.xVal[t]) / r.xNumSteps[t],
                a = Math.ceil(Number(n.toFixed(3)) - 1),
                o = r.xVal[t] + r.xNumSteps[t] * a;
            r.xHighestCompleteStep[t] = o
        }

        function y(t, e, r) {
            var n;
            this.xPct = [], this.xVal = [], this.xSteps = [r || !1], this.xNumSteps = [!1], this.xHighestCompleteStep = [], this.snap = e;
            var a = [];
            for (n in t) t.hasOwnProperty(n) && a.push([t[n], n]);
            for (a.length && "object" == typeof a[0][0] ? a.sort(function(t, e) {
                    return t[0][0] - e[0][0]
                }) : a.sort(function(t, e) {
                    return t[0] - e[0]
                }), n = 0; n < a.length; n++) h(a[n][1], a[n][0], this);
            for (this.xNumSteps = this.xSteps.slice(0), n = 0; n < this.xNumSteps.length; n++) m(n, this.xNumSteps[n], this)
        }
        y.prototype.getMargin = function(e) {
            var r = this.xNumSteps[0];
            if (r && e / r % 1 != 0) throw new Error("noUiSlider (" + t + "): 'limit', 'margin' and 'padding' must be divisible by step.");
            return 2 === this.xPct.length && d(this.xVal, e)
        }, y.prototype.toStepping = function(t) {
            return function(t, e, r) {
                if (r >= t.slice(-1)[0]) return 100;
                var n = p(r, t),
                    a = t[n - 1],
                    o = t[n],
                    i = e[n - 1],
                    s = e[n];
                return i + function(t, e) {
                    return d(t, t[0] < 0 ? e + Math.abs(t[0]) : e - t[0])
                }([a, o], r) / f(i, s)
            }(this.xVal, this.xPct, t)
        }, y.prototype.fromStepping = function(t) {
            return function(t, e, r) {
                if (r >= 100) return t.slice(-1)[0];
                var n = p(r, e),
                    a = t[n - 1],
                    o = t[n],
                    i = e[n - 1],
                    s = e[n];
                return function(t, e) {
                    return (r - i) * f(i, s) * (t[1] - t[0]) / 100 + t[0]
                }([a, o])
            }(this.xVal, this.xPct, t)
        }, y.prototype.getStep = function(t) {
            return function(t, e, r, n) {
                if (100 === n) return n;
                var a = p(n, t),
                    o = t[a - 1],
                    i = t[a];
                return r ? n - o > (i - o) / 2 ? i : o : e[a - 1] ? t[a - 1] + function(t, e) {
                    return Math.round(t / e) * e
                }(n - t[a - 1], e[a - 1]) : n
            }(this.xPct, this.xSteps, this.snap, t)
        }, y.prototype.getNearbySteps = function(t) {
            var e = p(t, this.xPct);
            return {
                stepBefore: {
                    startValue: this.xVal[e - 2],
                    step: this.xNumSteps[e - 2],
                    highestStep: this.xHighestCompleteStep[e - 2]
                },
                thisStep: {
                    startValue: this.xVal[e - 1],
                    step: this.xNumSteps[e - 1],
                    highestStep: this.xHighestCompleteStep[e - 1]
                },
                stepAfter: {
                    startValue: this.xVal[e - 0],
                    step: this.xNumSteps[e - 0],
                    highestStep: this.xHighestCompleteStep[e - 0]
                }
            }
        }, y.prototype.countStepDecimals = function() {
            var t = this.xNumSteps.map(s);
            return Math.max.apply(null, t)
        }, y.prototype.convert = function(t) {
            return this.getStep(this.toStepping(t))
        };
        var g = {
            to: function(t) {
                return void 0 !== t && t.toFixed(2)
            },
            from: Number
        };

        function v(e) {
            if (function(t) {
                    return "object" == typeof t && "function" == typeof t.to && "function" == typeof t.from
                }(e)) return !0;
            throw new Error("noUiSlider (" + t + "): 'format' requires 'to' and 'from' methods.")
        }

        function b(e, r) {
            if (!n(r)) throw new Error("noUiSlider (" + t + "): 'step' is not numeric.");
            e.singleStep = r
        }

        function x(e, r) {
            if ("object" != typeof r || Array.isArray(r)) throw new Error("noUiSlider (" + t + "): 'range' is not an object.");
            if (void 0 === r.min || void 0 === r.max) throw new Error("noUiSlider (" + t + "): Missing 'min' or 'max' in 'range'.");
            if (r.min === r.max) throw new Error("noUiSlider (" + t + "): 'range' 'min' and 'max' cannot be equal.");
            e.spectrum = new y(r, e.snap, e.singleStep)
        }

        function w(e, r) {
            if (r = i(r), !Array.isArray(r) || !r.length) throw new Error("noUiSlider (" + t + "): 'start' option is incorrect.");
            e.handles = r.length, e.start = r
        }

        function _(e, r) {
            if (e.snap = r, "boolean" != typeof r) throw new Error("noUiSlider (" + t + "): 'snap' option must be a boolean.")
        }

        function E(e, r) {
            if (e.animate = r, "boolean" != typeof r) throw new Error("noUiSlider (" + t + "): 'animate' option must be a boolean.")
        }

        function k(e, r) {
            if (e.animationDuration = r, "number" != typeof r) throw new Error("noUiSlider (" + t + "): 'animationDuration' option must be a number.")
        }

        function S(e, r) {
            var n, a = [!1];
            if ("lower" === r ? r = [!0, !1] : "upper" === r && (r = [!1, !0]), !0 === r || !1 === r) {
                for (n = 1; n < e.handles; n++) a.push(r);
                a.push(!1)
            } else {
                if (!Array.isArray(r) || !r.length || r.length !== e.handles + 1) throw new Error("noUiSlider (" + t + "): 'connect' option doesn't match handle count.");
                a = r
            }
            e.connect = a
        }

        function M(e, r) {
            switch (r) {
                case "horizontal":
                    e.ort = 0;
                    break;
                case "vertical":
                    e.ort = 1;
                    break;
                default:
                    throw new Error("noUiSlider (" + t + "): 'orientation' option is invalid.")
            }
        }

        function A(e, r) {
            if (!n(r)) throw new Error("noUiSlider (" + t + "): 'margin' option must be numeric.");
            if (0 !== r && (e.margin = e.spectrum.getMargin(r), !e.margin)) throw new Error("noUiSlider (" + t + "): 'margin' option is only supported on linear sliders.")
        }

        function C(e, r) {
            if (!n(r)) throw new Error("noUiSlider (" + t + "): 'limit' option must be numeric.");
            if (e.limit = e.spectrum.getMargin(r), !e.limit || e.handles < 2) throw new Error("noUiSlider (" + t + "): 'limit' option is only supported on linear sliders with 2 or more handles.")
        }

        function P(e, r) {
            if (!n(r) && !Array.isArray(r)) throw new Error("noUiSlider (" + t + "): 'padding' option must be numeric or array of exactly 2 numbers.");
            if (Array.isArray(r) && 2 !== r.length && !n(r[0]) && !n(r[1])) throw new Error("noUiSlider (" + t + "): 'padding' option must be numeric or array of exactly 2 numbers.");
            if (0 !== r) {
                if (Array.isArray(r) || (r = [r, r]), e.padding = [e.spectrum.getMargin(r[0]), e.spectrum.getMargin(r[1])], !1 === e.padding[0] || !1 === e.padding[1]) throw new Error("noUiSlider (" + t + "): 'padding' option is only supported on linear sliders.");
                if (e.padding[0] < 0 || e.padding[1] < 0) throw new Error("noUiSlider (" + t + "): 'padding' option must be a positive number(s).");
                if (e.padding[0] + e.padding[1] >= 100) throw new Error("noUiSlider (" + t + "): 'padding' option must not exceed 100% of the range.")
            }
        }

        function T(e, r) {
            switch (r) {
                case "ltr":
                    e.dir = 0;
                    break;
                case "rtl":
                    e.dir = 1;
                    break;
                default:
                    throw new Error("noUiSlider (" + t + "): 'direction' option was not recognized.")
            }
        }

        function O(e, r) {
            if ("string" != typeof r) throw new Error("noUiSlider (" + t + "): 'behaviour' must be a string containing options.");
            var n = r.indexOf("tap") >= 0,
                a = r.indexOf("drag") >= 0,
                o = r.indexOf("fixed") >= 0,
                i = r.indexOf("snap") >= 0,
                s = r.indexOf("hover") >= 0;
            if (o) {
                if (2 !== e.handles) throw new Error("noUiSlider (" + t + "): 'fixed' behaviour must be used with 2 handles");
                A(e, e.start[1] - e.start[0])
            }
            e.events = {
                tap: n || i,
                drag: a,
                fixed: o,
                snap: i,
                hover: s
            }
        }

        function N(e, r) {
            if (!1 !== r)
                if (!0 === r) {
                    e.tooltips = [];
                    for (var n = 0; n < e.handles; n++) e.tooltips.push(!0)
                } else {
                    if (e.tooltips = i(r), e.tooltips.length !== e.handles) throw new Error("noUiSlider (" + t + "): must pass a formatter for all handles.");
                    e.tooltips.forEach(function(e) {
                        if ("boolean" != typeof e && ("object" != typeof e || "function" != typeof e.to)) throw new Error("noUiSlider (" + t + "): 'tooltips' must be passed a formatter or 'false'.")
                    })
                }
        }

        function j(t, e) {
            t.ariaFormat = e, v(e)
        }

        function L(t, e) {
            t.format = e, v(e)
        }

        function q(e, r) {
            if ("string" != typeof r && !1 !== r) throw new Error("noUiSlider (" + t + "): 'cssPrefix' must be a string or `false`.");
            e.cssPrefix = r
        }

        function I(e, r) {
            if ("object" != typeof r) throw new Error("noUiSlider (" + t + "): 'cssClasses' must be an object.");
            if ("string" == typeof e.cssPrefix)
                for (var n in e.cssClasses = {}, r) r.hasOwnProperty(n) && (e.cssClasses[n] = e.cssPrefix + r[n]);
            else e.cssClasses = r
        }

        function D(r) {
            var n = {
                    margin: 0,
                    limit: 0,
                    padding: 0,
                    animate: !0,
                    animationDuration: 300,
                    ariaFormat: g,
                    format: g
                },
                a = {
                    step: {
                        r: !1,
                        t: b
                    },
                    start: {
                        r: !0,
                        t: w
                    },
                    connect: {
                        r: !0,
                        t: S
                    },
                    direction: {
                        r: !0,
                        t: T
                    },
                    snap: {
                        r: !1,
                        t: _
                    },
                    animate: {
                        r: !1,
                        t: E
                    },
                    animationDuration: {
                        r: !1,
                        t: k
                    },
                    range: {
                        r: !0,
                        t: x
                    },
                    orientation: {
                        r: !1,
                        t: M
                    },
                    margin: {
                        r: !1,
                        t: A
                    },
                    limit: {
                        r: !1,
                        t: C
                    },
                    padding: {
                        r: !1,
                        t: P
                    },
                    behaviour: {
                        r: !0,
                        t: O
                    },
                    ariaFormat: {
                        r: !1,
                        t: j
                    },
                    format: {
                        r: !1,
                        t: L
                    },
                    tooltips: {
                        r: !1,
                        t: N
                    },
                    cssPrefix: {
                        r: !0,
                        t: q
                    },
                    cssClasses: {
                        r: !0,
                        t: I
                    }
                },
                o = {
                    connect: !1,
                    direction: "ltr",
                    behaviour: "tap",
                    orientation: "horizontal",
                    cssPrefix: "noUi-",
                    cssClasses: {
                        target: "target",
                        base: "base",
                        origin: "origin",
                        handle: "handle",
                        handleLower: "handle-lower",
                        handleUpper: "handle-upper",
                        horizontal: "horizontal",
                        vertical: "vertical",
                        background: "background",
                        connect: "connect",
                        connects: "connects",
                        ltr: "ltr",
                        rtl: "rtl",
                        draggable: "draggable",
                        drag: "state-drag",
                        tap: "state-tap",
                        active: "active",
                        tooltip: "tooltip",
                        pips: "pips",
                        pipsHorizontal: "pips-horizontal",
                        pipsVertical: "pips-vertical",
                        marker: "marker",
                        markerHorizontal: "marker-horizontal",
                        markerVertical: "marker-vertical",
                        markerNormal: "marker-normal",
                        markerLarge: "marker-large",
                        markerSub: "marker-sub",
                        value: "value",
                        valueHorizontal: "value-horizontal",
                        valueVertical: "value-vertical",
                        valueNormal: "value-normal",
                        valueLarge: "value-large",
                        valueSub: "value-sub"
                    }
                };
            r.format && !r.ariaFormat && (r.ariaFormat = r.format), Object.keys(a).forEach(function(i) {
                if (!e(r[i]) && void 0 === o[i]) {
                    if (a[i].r) throw new Error("noUiSlider (" + t + "): '" + i + "' is required.");
                    return !0
                }
                a[i].t(n, e(r[i]) ? r[i] : o[i])
            }), n.pips = r.pips;
            var i = document.createElement("div"),
                s = void 0 !== i.style.msTransform,
                c = void 0 !== i.style.transform;
            return n.transformRule = c ? "transform" : s ? "msTransform" : "webkitTransform", n.style = [
                ["left", "top"],
                ["right", "bottom"]
            ][n.dir][n.ort], n
        }

        function R(e, n, s) {
            var f, d, p, h, m, y, g, v, b = window.navigator.pointerEnabled ? {
                    start: "pointerdown",
                    move: "pointermove",
                    end: "pointerup"
                } : window.navigator.msPointerEnabled ? {
                    start: "MSPointerDown",
                    move: "MSPointerMove",
                    end: "MSPointerUp"
                } : {
                    start: "mousedown touchstart",
                    move: "mousemove touchmove",
                    end: "mouseup touchend"
                },
                x = window.CSS && CSS.supports && CSS.supports("touch-action", "none") && function() {
                    var t = !1;
                    try {
                        var e = Object.defineProperty({}, "passive", {
                            get: function() {
                                t = !0
                            }
                        });
                        window.addEventListener("test", null, e)
                    } catch (t) {}
                    return t
                }(),
                w = e,
                _ = [],
                E = [],
                k = 0,
                S = n.spectrum,
                M = [],
                A = {},
                C = e.ownerDocument,
                P = C.documentElement,
                T = C.body,
                O = "rtl" === C.dir || 1 === n.ort ? 0 : 100;
            /*! In this file: Construction of DOM elements; */
            function N(t, e) {
                var r = C.createElement("div");
                return e && c(r, e), t.appendChild(r), r
            }

            function j(t, e) {
                var r = N(t, n.cssClasses.origin),
                    a = N(r, n.cssClasses.handle);
                return a.setAttribute("data-handle", e), a.setAttribute("tabindex", "0"), a.setAttribute("role", "slider"), a.setAttribute("aria-orientation", n.ort ? "vertical" : "horizontal"), 0 === e ? c(a, n.cssClasses.handleLower) : e === n.handles - 1 && c(a, n.cssClasses.handleUpper), r
            }

            function L(t, e) {
                return !!e && N(t, n.cssClasses.connect)
            }

            function q(t, e, r) {
                var a = C.createElement("div"),
                    o = [n.cssClasses.valueNormal, n.cssClasses.valueLarge, n.cssClasses.valueSub],
                    i = [n.cssClasses.markerNormal, n.cssClasses.markerLarge, n.cssClasses.markerSub],
                    s = [n.cssClasses.valueHorizontal, n.cssClasses.valueVertical],
                    u = [n.cssClasses.markerHorizontal, n.cssClasses.markerVertical];

                function l(t, e) {
                    var r = e === n.cssClasses.value,
                        a = r ? o : i;
                    return e + " " + (r ? s : u)[n.ort] + " " + a[t]
                }
                return c(a, n.cssClasses.pips), c(a, 0 === n.ort ? n.cssClasses.pipsHorizontal : n.cssClasses.pipsVertical), Object.keys(t).forEach(function(o) {
                    ! function(t, o) {
                        o[1] = o[1] && e ? e(o[0], o[1]) : o[1];
                        var i = N(a, !1);
                        i.className = l(o[1], n.cssClasses.marker), i.style[n.style] = t + "%", o[1] && ((i = N(a, !1)).className = l(o[1], n.cssClasses.value), i.setAttribute("data-value", o[0]), i.style[n.style] = t + "%", i.innerText = r.to(o[0]))
                    }(o, t[o])
                }), a
            }

            function I() {
                var t;
                m && ((t = m).parentElement.removeChild(t), m = null)
            }

            function R(e) {
                I();
                var r = e.mode,
                    n = e.density || 1,
                    a = e.filter || !1,
                    o = function(e, r, n) {
                        if ("range" === e || "steps" === e) return S.xVal;
                        if ("count" === e) {
                            if (r < 2) throw new Error("noUiSlider (" + t + "): 'values' (>= 2) required for mode 'count'.");
                            var a = r - 1,
                                o = 100 / a;
                            for (r = []; a--;) r[a] = a * o;
                            r.push(100), e = "positions"
                        }
                        return "positions" === e ? r.map(function(t) {
                            return S.fromStepping(n ? S.getStep(t) : t)
                        }) : "values" === e ? n ? r.map(function(t) {
                            return S.fromStepping(S.getStep(S.toStepping(t)))
                        }) : r : void 0
                    }(r, e.values || !1, e.stepped || !1),
                    i = function(t, e, r) {
                        var n, a = {},
                            o = S.xVal[0],
                            i = S.xVal[S.xVal.length - 1],
                            s = !1,
                            c = !1,
                            u = 0;
                        return (n = r.slice().sort(function(t, e) {
                            return t - e
                        }), r = n.filter(function(t) {
                            return !this[t] && (this[t] = !0)
                        }, {}))[0] !== o && (r.unshift(o), s = !0), r[r.length - 1] !== i && (r.push(i), c = !0), r.forEach(function(n, o) {
                            var i, l, f, d, p, h, m, y, g, v = n,
                                b = r[o + 1];
                            if ("steps" === e && (i = S.xNumSteps[o]), i || (i = b - v), !1 !== v && void 0 !== b)
                                for (i = Math.max(i, 1e-7), l = v; l <= b; l = (l + i).toFixed(7) / 1) {
                                    for (m = (p = (d = S.toStepping(l)) - u) / t, g = p / (y = Math.round(m)), f = 1; f <= y; f += 1) a[(u + f * g).toFixed(5)] = ["x", 0];
                                    h = r.indexOf(l) > -1 ? 1 : "steps" === e ? 2 : 0, !o && s && (h = 0), l === b && c || (a[d.toFixed(5)] = [l, h]), u = d
                                }
                        }), a
                    }(n, r, o),
                    s = e.format || {
                        to: Math.round
                    };
                return m = w.appendChild(q(i, a, s))
            }
            /*! In this file: Browser events (not slider events like slide, change); */
            function z() {
                var t = f.getBoundingClientRect(),
                    e = "offset" + ["Width", "Height"][n.ort];
                return 0 === n.ort ? t.width || f[e] : t.height || f[e]
            }

            function U(t, e, r, a) {
                var o = function(o) {
                        return !!(o = function(t, e, r) {
                            var n, a, o = 0 === t.type.indexOf("touch"),
                                i = 0 === t.type.indexOf("mouse"),
                                s = 0 === t.type.indexOf("pointer");
                            if (0 === t.type.indexOf("MSPointer") && (s = !0), o) {
                                var c = function(t) {
                                    return t.target === r || r.contains(t.target)
                                };
                                if ("touchstart" === t.type) {
                                    var u = Array.prototype.filter.call(t.touches, c);
                                    if (u.length > 1) return !1;
                                    n = u[0].pageX, a = u[0].pageY
                                } else {
                                    var f = Array.prototype.find.call(t.changedTouches, c);
                                    if (!f) return !1;
                                    n = f.pageX, a = f.pageY
                                }
                            }
                            return e = e || l(C), (i || s) && (n = t.clientX + e.x, a = t.clientY + e.y), t.pageOffset = e, t.points = [n, a], t.cursor = i || s, t
                        }(o, a.pageOffset, a.target || e)) && !(w.hasAttribute("disabled") && !a.doNotReject) && (i = w, s = n.cssClasses.tap, !((i.classList ? i.classList.contains(s) : new RegExp("\\b" + s + "\\b").test(i.className)) && !a.doNotReject) && !(t === b.start && void 0 !== o.buttons && o.buttons > 1) && (!a.hover || !o.buttons) && (x || o.preventDefault(), o.calcPoint = o.points[n.ort], void r(o, a)));
                        var i, s
                    },
                    i = [];
                return t.split(" ").forEach(function(t) {
                    e.addEventListener(t, o, !!x && {
                        passive: !0
                    }), i.push([t, o])
                }), i
            }

            function H(t) {
                var e, r, a, i, s, c, u = 100 * (t - (e = f, r = n.ort, a = e.getBoundingClientRect(), s = (i = e.ownerDocument).documentElement, c = l(i), /webkit.*Chrome.*Mobile/i.test(navigator.userAgent) && (c.x = 0), r ? a.top + c.y - s.clientTop : a.left + c.x - s.clientLeft)) / z();
                return u = o(u), n.dir ? 100 - u : u
            }

            function V(t, e) {
                "mouseout" === t.type && "HTML" === t.target.nodeName && null === t.relatedTarget && B(t, e)
            }

            function F(t, e) {
                if (-1 === navigator.appVersion.indexOf("MSIE 9") && 0 === t.buttons && 0 !== e.buttonsProperty) return B(t, e);
                var r = (n.dir ? -1 : 1) * (t.calcPoint - e.startCalcPoint);
                K(r > 0, 100 * r / e.baseSize, e.locations, e.handleNumbers)
            }

            function B(t, e) {
                e.handle && (u(e.handle, n.cssClasses.active), k -= 1), e.listeners.forEach(function(t) {
                    P.removeEventListener(t[0], t[1])
                }), 0 === k && (u(w, n.cssClasses.drag), Z(), t.cursor && (T.style.cursor = "", T.removeEventListener("selectstart", r))), e.handleNumbers.forEach(function(t) {
                    X("change", t), X("set", t), X("end", t)
                })
            }

            function W(t, e) {
                var a;
                if (1 === e.handleNumbers.length) {
                    var o = d[e.handleNumbers[0]];
                    if (o.hasAttribute("disabled")) return !1;
                    a = o.children[0], k += 1, c(a, n.cssClasses.active)
                }
                t.stopPropagation();
                var i = [],
                    s = U(b.move, P, F, {
                        target: t.target,
                        handle: a,
                        listeners: i,
                        startCalcPoint: t.calcPoint,
                        baseSize: z(),
                        pageOffset: t.pageOffset,
                        handleNumbers: e.handleNumbers,
                        buttonsProperty: t.buttons,
                        locations: _.slice()
                    }),
                    u = U(b.end, P, B, {
                        target: t.target,
                        handle: a,
                        listeners: i,
                        doNotReject: !0,
                        handleNumbers: e.handleNumbers
                    }),
                    l = U("mouseout", P, V, {
                        target: t.target,
                        handle: a,
                        listeners: i,
                        doNotReject: !0,
                        handleNumbers: e.handleNumbers
                    });
                i.push.apply(i, s.concat(u, l)), t.cursor && (T.style.cursor = getComputedStyle(t.target).cursor, d.length > 1 && c(w, n.cssClasses.drag), T.addEventListener("selectstart", r, !1)), e.handleNumbers.forEach(function(t) {
                    X("start", t)
                })
            }
            /*! In this file: Slider events (not browser events); */
            function G(t, e) {
                A[t] = A[t] || [], A[t].push(e), "update" === t.split(".")[0] && d.forEach(function(t, e) {
                    X("update", e)
                })
            }

            function X(t, e, r) {
                Object.keys(A).forEach(function(a) {
                    var o = a.split(".")[0];
                    t === o && A[a].forEach(function(t) {
                        t.call(h, M.map(n.format.to), e, M.slice(), r || !1, _.slice())
                    })
                })
            }
            /*! In this file: Mechanics for slider operation */
            function Y(t) {
                return t + "%"
            }

            function $(t, e, r, a, i, s) {
                return d.length > 1 && (a && e > 0 && (r = Math.max(r, t[e - 1] + n.margin)), i && e < d.length - 1 && (r = Math.min(r, t[e + 1] - n.margin))), d.length > 1 && n.limit && (a && e > 0 && (r = Math.min(r, t[e - 1] + n.limit)), i && e < d.length - 1 && (r = Math.max(r, t[e + 1] - n.limit))), n.padding && (0 === e && (r = Math.max(r, n.padding[0])), e === d.length - 1 && (r = Math.min(r, 100 - n.padding[1]))), !((r = o(r = S.getStep(r))) === t[e] && !s) && r
            }

            function Q(t, e) {
                var r = n.ort;
                return (r ? e : t) + ", " + (r ? t : e)
            }

            function K(t, e, r, n) {
                var a = r.slice(),
                    o = [!t, t],
                    i = [t, !t];
                n = n.slice(), t && n.reverse(), n.length > 1 ? n.forEach(function(t, r) {
                    var n = $(a, t, a[t] + e, o[r], i[r], !1);
                    !1 === n ? e = 0 : (e = n - a[t], a[t] = n)
                }) : o = i = [!0];
                var s = !1;
                n.forEach(function(t, n) {
                    s = tt(t, r[t] + e, o[n], i[n]) || s
                }), s && n.forEach(function(t) {
                    X("update", t), X("slide", t)
                })
            }

            function J(t, e) {
                return n.dir ? 100 - t - e : t
            }

            function Z() {
                E.forEach(function(t) {
                    var e = _[t] > 50 ? -1 : 1,
                        r = 3 + (d.length + e * t);
                    d[t].style.zIndex = r
                })
            }

            function tt(t, e, r, a) {
                return !1 !== (e = $(_, t, e, r, a, !1)) && (function(t, e) {
                    _[t] = e, M[t] = S.fromStepping(e);
                    var r = "translate(" + Q(Y(J(e, 0) - O), "0") + ")";
                    d[t].style[n.transformRule] = r, et(t), et(t + 1)
                }(t, e), !0)
            }

            function et(t) {
                if (p[t]) {
                    var e = 0,
                        r = 100;
                    0 !== t && (e = _[t - 1]), t !== p.length - 1 && (r = _[t]);
                    var a = r - e,
                        o = "translate(" + Q(Y(J(e, a)), "0") + ")",
                        i = "scale(" + Q(a / 100, "1") + ")";
                    p[t].style[n.transformRule] = o + " " + i
                }
            }
            /*! In this file: All methods eventually exposed in slider.noUiSlider... */
            function rt(t, e) {
                var r = i(t),
                    o = void 0 === _[0];
                e = void 0 === e || !!e, n.animate && !o && a(w, n.cssClasses.tap, n.animationDuration), E.forEach(function(t) {
                    tt(t, function(t, e) {
                        return null === t || !1 === t || void 0 === t ? _[e] : ("number" == typeof t && (t = String(t)), t = n.format.from(t), !1 === (t = S.toStepping(t)) || isNaN(t) ? _[e] : t)
                    }(r[t], t), !0, !1)
                }), E.forEach(function(t) {
                    tt(t, _[t], !0, !0)
                }), Z(), E.forEach(function(t) {
                    X("update", t), null !== r[t] && e && X("set", t)
                })
            }

            function nt() {
                var t = M.map(n.format.to);
                return 1 === t.length ? t[0] : t
            }
            /*! In this file: Calls to functions. All other scope_ files define functions only; */
            return c(v = w, n.cssClasses.target), 0 === n.dir ? c(v, n.cssClasses.ltr) : c(v, n.cssClasses.rtl), 0 === n.ort ? c(v, n.cssClasses.horizontal) : c(v, n.cssClasses.vertical), f = N(v, n.cssClasses.base),
                function(t, e) {
                    var r = N(e, n.cssClasses.connects);
                    d = [], (p = []).push(L(r, t[0]));
                    for (var a = 0; a < n.handles; a++) d.push(j(e, a)), E[a] = a, p.push(L(r, t[a + 1]))
                }(n.connect, f), (g = n.events).fixed || d.forEach(function(t, e) {
                    U(b.start, t.children[0], W, {
                        handleNumbers: [e]
                    })
                }), g.tap && U(b.start, f, function(t) {
                    t.stopPropagation();
                    var e = H(t.calcPoint),
                        r = function(t) {
                            var e = 100,
                                r = !1;
                            return d.forEach(function(n, a) {
                                if (!n.hasAttribute("disabled")) {
                                    var o = Math.abs(_[a] - t);
                                    (o < e || 100 === o && 100 === e) && (r = a, e = o)
                                }
                            }), r
                        }(e);
                    if (!1 === r) return !1;
                    n.events.snap || a(w, n.cssClasses.tap, n.animationDuration), tt(r, e, !0, !0), Z(), X("slide", r, !0), X("update", r, !0), X("change", r, !0), X("set", r, !0), n.events.snap && W(t, {
                        handleNumbers: [r]
                    })
                }, {}), g.hover && U(b.move, f, function(t) {
                    var e = H(t.calcPoint),
                        r = S.getStep(e),
                        n = S.fromStepping(r);
                    Object.keys(A).forEach(function(t) {
                        "hover" === t.split(".")[0] && A[t].forEach(function(t) {
                            t.call(h, n)
                        })
                    })
                }, {
                    hover: !0
                }), g.drag && p.forEach(function(t, e) {
                    if (!1 !== t && 0 !== e && e !== p.length - 1) {
                        var r = d[e - 1],
                            a = d[e],
                            o = [t];
                        c(t, n.cssClasses.draggable), g.fixed && (o.push(r.children[0]), o.push(a.children[0])), o.forEach(function(t) {
                            U(b.start, t, W, {
                                handles: [r, a],
                                handleNumbers: [e - 1, e]
                            })
                        })
                    }
                }), rt(n.start), h = {
                    destroy: function() {
                        for (var t in n.cssClasses) n.cssClasses.hasOwnProperty(t) && u(w, n.cssClasses[t]);
                        for (; w.firstChild;) w.removeChild(w.firstChild);
                        delete w.noUiSlider
                    },
                    steps: function() {
                        return _.map(function(t, e) {
                            var r = S.getNearbySteps(t),
                                n = M[e],
                                a = r.thisStep.step,
                                o = null;
                            !1 !== a && n + a > r.stepAfter.startValue && (a = r.stepAfter.startValue - n), o = n > r.thisStep.startValue ? r.thisStep.step : !1 !== r.stepBefore.step && n - r.stepBefore.highestStep, 100 === t ? a = null : 0 === t && (o = null);
                            var i = S.countStepDecimals();
                            return null !== a && !1 !== a && (a = Number(a.toFixed(i))), null !== o && !1 !== o && (o = Number(o.toFixed(i))), [o, a]
                        })
                    },
                    on: G,
                    off: function(t) {
                        var e = t && t.split(".")[0],
                            r = e && t.substring(e.length);
                        Object.keys(A).forEach(function(t) {
                            var n = t.split(".")[0],
                                a = t.substring(n.length);
                            e && e !== n || r && r !== a || delete A[t]
                        })
                    },
                    get: nt,
                    set: rt,
                    reset: function(t) {
                        rt(n.start, t)
                    },
                    __moveHandles: function(t, e, r) {
                        K(t, e, _, r)
                    },
                    options: s,
                    updateOptions: function(t, e) {
                        var r = nt(),
                            a = ["margin", "limit", "padding", "range", "animate", "snap", "step", "format"];
                        a.forEach(function(e) {
                            void 0 !== t[e] && (s[e] = t[e])
                        });
                        var o = D(s);
                        a.forEach(function(e) {
                            void 0 !== t[e] && (n[e] = o[e])
                        }), S = o.spectrum, n.margin = o.margin, n.limit = o.limit, n.padding = o.padding, n.pips && R(n.pips), _ = [], rt(t.start || r, e)
                    },
                    target: w,
                    removePips: I,
                    pips: R
                }, n.pips && R(n.pips), n.tooltips && (y = d.map(function(t, e) {
                    return !!n.tooltips[e] && N(t.firstChild, n.cssClasses.tooltip)
                }), G("update", function(t, e, r) {
                    if (y[e]) {
                        var a = t[e];
                        !0 !== n.tooltips[e] && (a = n.tooltips[e].to(r[e])), y[e].innerHTML = a
                    }
                })), G("update", function(t, e, r, a, o) {
                    E.forEach(function(t) {
                        var e = d[t],
                            a = $(_, t, 0, !0, !0, !0),
                            i = $(_, t, 100, !0, !0, !0),
                            s = o[t],
                            c = n.ariaFormat.to(r[t]);
                        e.children[0].setAttribute("aria-valuemin", a.toFixed(1)), e.children[0].setAttribute("aria-valuemax", i.toFixed(1)), e.children[0].setAttribute("aria-valuenow", s.toFixed(1)), e.children[0].setAttribute("aria-valuetext", c)
                    })
                }), h
        }
        return {
            version: t,
            create: function(e, r) {
                if (!e || !e.nodeName) throw new Error("noUiSlider (" + t + "): create requires a single element, got: " + e);
                if (e.noUiSlider) throw new Error("noUiSlider (" + t + "): Slider was already initialized.");
                var n = R(e, D(r), r);
                return e.noUiSlider = n, n
            }
        }
    }) ? n.apply(e, []) : n) || (t.exports = a)
}, function(t, e, r) {
    "use strict";
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var n = Object.assign || function(t) {
            for (var e = 1; e < arguments.length; e++) {
                var r = arguments[e];
                for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (t[n] = r[n])
            }
            return t
        },
        a = !0,
        o = !1,
        i = 1997,
        s = 2017,
        c = 1e5,
        u = ["#e8b8a0", "#f2a385", "#f88d69", "#fc764f", "#fe5c34", "#ff3814"],
        l = d3.select("body"),
        f = (d3.select(".graphic__trend"), d3.select(".trend__chart--all")),
        d = d3.select(".trend__chart--state"),
        p = {
            x: d3.scaleLinear(),
            y: d3.scaleLinear(),
            color: d3.scaleQuantize()
        },
        h = {
            x: d3.scaleLinear(),
            y: d3.scaleLinear()
        },
        m = 20,
        y = 12,
        g = 1.5,
        v = 0,
        b = 0,
        x = 0,
        w = 0,
        _ = null,
        E = null,
        k = 0,
        S = null;

    function M(t, e) {
        return +e.find(function(e) {
            return e.state.toLowerCase() === t.toLowerCase()
        }).population
    }

    function A(t) {
        var e = t.population,
            r = t.established;
        _ = r.map(function(t, r) {
            return n({}, t, {
                population: M(t.key, e),
                values: t.values.map(function(r) {
                    return n({}, r, {
                        year: +r.key,
                        population: M(t.key, e)
                    })
                }).filter(function(t) {
                    return t.year >= i && t.year < s
                })
            })
        }).map(function(t) {
            return n({}, t, {
                values: (e = t.values, r = d3.range(i, s), a = e[0].population, r.map(function(t) {
                    return e.find(function(e) {
                        return e.year === t
                    }) || {
                        key: t.toString(),
                        value: 0,
                        year: t,
                        population: a
                    }
                })),
                max: d3.max(t.values, function(t) {
                    return t.value / t.population
                }) * c,
                mean: d3.mean(t.values, function(t) {
                    return t.value / t.population
                }) * c
            });
            var e, r, a
        }).filter(function(t) {
            return "Washington DC" !== t.key
        }).sort(function(t, e) {
            return d3.descending(t.mean, e.mean)
        }), k = d3.max(_, function(t) {
            return t.max
        }), S = d3.extent(_, function(t) {
            return t.mean
        });
        var a = d3.merge(r.map(function(t) {
            return t.values
        }));
        E = d3.nest().key(function(t) {
            return t.key
        }).sortKeys(d3.ascending).rollup(function(t) {
            return d3.sum(t, function(t) {
                return t.value
            })
        }).entries(a).map(function(t) {
            return n({}, t, {
                year: +t.key
            })
        }).filter(function(t) {
            return t.year >= i && t.year < s
        })
    }

    function C() {
        a = l.classed("is-full"), o && (function() {
            v = d.select(".state__svg").node().offsetWidth, b = Math.floor(v / g);
            var t = v - 2 * m,
                e = (b = 100) - 2 * m;
            p.y.range([e, 0]), p.x.range([0, t]);
            var r = d3.area().x(function(t) {
                    return p.x(t.year)
                }).y0(function(t) {
                    return p.y(t.value / t.population * c)
                }).y1(p.y(0)).curve(d3.curveMonotoneX),
                n = d3.area().x(function(t) {
                    return p.x(t.year)
                }).y(function(t) {
                    return p.y(t.value / t.population * c)
                }).curve(d3.curveMonotoneX),
                a = d.selectAll("svg");
            a.attr("width", v).attr("height", b), a.select(".state__area").datum(function(t) {
                return t.values
            }).attr("d", r), a.select(".state__line").datum(function(t) {
                return t.values
            }).attr("d", n);
            var o = d3.axisBottom(p.x).tickFormat(d3.format(" ")).tickValues([1997, 2016]);
            a.select(".axis--x").call(o).attr("transform", "translate(0, " + e + ")");
            var i = d3.axisRight(p.y).tickSizeInner(-t).tickPadding(.25 * y).tickValues([.4, 1]);
            a.select(".axis--y").call(i).attr("transform", "translate(" + t + ", 0)")
        }(), function() {
            var t = d3.line().x(function(t) {
                return h.x(t.year)
            }).y(function(t) {
                return h.y(t.value)
            }).curve(d3.curveMonotoneX);
            x = f.node().offsetWidth, w = window.innerHeight * (a ? .8 : .5);
            var e = x - 4 * m,
                r = w - 2 * m;
            h.y.range([r, 0]), h.x.range([0, e]);
            var n = f.selectAll("svg");
            n.attr("width", x).attr("height", w), n.select(".all__path").datum(E).attr("d", t);
            var o = d3.axisBottom(h.x).tickFormat(d3.format(" "));
            n.select(".axis--x").call(o).attr("transform", "translate(0, " + r + ")");
            var i = d3.axisRight(h.y).tickSizeInner(-e).tickPadding(.5 * y);
            n.select(".axis--y").call(i).attr("transform", "translate(" + e + ", 0)"), n.select(".y-label").attr("transform", "rotate(90)").attr("x", r / 2).attr("y", 1.5 * -m - y)
        }())
    }

    function P() {
        var t, e, r;
        ! function() {
            p.x.domain([i, s - 1]), p.y.domain([0, k]), p.color.domain(S).range(u), h.x.domain([i, s - 1]);
            var t = d3.max(E, function(t) {
                return t.value
            });
            h.y.domain([0, t]).nice()
        }(), e = (t = f.append("svg")).append("g").attr("class", "g-axis").attr("transform", "translate(" + m + ", " + m + ")"), r = t.append("g").attr("class", "g-graphic").attr("transform", "translate(" + m + ", " + m + ")"), e.append("g").attr("class", "axis--x"), e.append("g").attr("class", "axis--y").append("text").attr("class", "y-label").attr("text-anchor", "middle").text("# of Breweries opened"), r.append("path").attr("class", "all__path"),
            function() {
                var t = d.selectAll(".chart__state").data(_).enter().append("div").attr("class", "chart__state");
                t.append("p").attr("class", "state__label").text(function(t) {
                    return t.key
                });
                var e = t.append("div").attr("class", "state__svg").append("svg"),
                    r = e.append("g").attr("class", "g-axis").attr("transform", "translate(" + m + ", " + m + ")"),
                    n = e.append("g").attr("class", "g-graphic").attr("transform", "translate(" + m + ", " + m + ")");
                r.append("g").attr("class", "axis--x"), r.append("g").attr("class", "axis--y"), n.append("path").attr("class", "state__area").style("fill", function(t) {
                    return p.color(t.mean)
                }), n.append("path").attr("class", "state__line").attr("transform", "translate(0, -1)")
            }(), o = !0, C()
    }
    e.default = {
        init: function() {
            new Promise(function(t, e) {
                d3.queue().defer(d3.csv, "assets/population.csv").defer(d3.json, "assets/established.json").await(function(r, n, a) {
                    r ? e(r) : (A({
                        population: n,
                        established: a
                    }), t())
                })
            }).then(P).catch(function(t) {
                return console.log(t)
            })
        },
        resize: C
    }
}, function(t, e, r) {
    "use strict";

    function n(t) {
        if (Array.isArray(t)) {
            for (var e = 0, r = Array(t.length); e < t.length; e++) r[e] = t[e];
            return r
        }
        return Array.from(t)
    }
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.select = function(t) {
        return document.querySelector(t)
    }, e.selectAll = function(t) {
        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : document;
        return [].concat(n(e.querySelectorAll(t)))
    }, e.find = function(t, e) {
        return [].concat(n(t.querySelectorAll(e)))
    }, e.removeClass = function(t, e) {
        t.classList ? t.classList.remove(e) : t.className = t.className.replace(new RegExp("(^|\\b)" + e.split(" ").join("|") + "(\\b|$)", "gi"), " ")
    }, e.addClass = function(t, e) {
        t.classList ? t.classList.add(e) : t.className = t.className + " " + e
    }, e.hasClass = function(t, e) {
        return t.classList ? t.classList.contains(e) : new RegExp("(^| )" + e + "( |$)", "gi").test(t.className)
    }, e.jumpTo = function(t, e) {
        e = e || 0;
        var r = t.getBoundingClientRect().top + e,
            n = (window.pageYOffset || document.documentElement.scrollTop) + r;
        window.scrollTo(0, n)
    }
}]);